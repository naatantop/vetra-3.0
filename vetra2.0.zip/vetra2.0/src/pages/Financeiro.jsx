import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Search, Filter, ArrowUp, ArrowDown, Trash2, X, Calendar as CalendarIcon } from "lucide-react";
import { LancamentoFinanceiro } from "@/api/entities";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { format, subDays } from "date-fns";
import FinanceStats from "../components/financeiro/FinanceStats";
import TabelaLancamentos from "../components/financeiro/TabelaLancamentos";
import LancamentoForm from "../components/financeiro/LancamentoForm";

export default function Financeiro() {
  const [lancamentos, setLancamentos] = useState([]);
  const [filteredLancamentos, setFilteredLancamentos] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [message, setMessage] = useState({ type: "", text: "" });

  const [showModal, setShowModal] = useState(false);
  const [editingLancamento, setEditingLancamento] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  // Filtros
  const [searchTerm, setSearchTerm] = useState('');
  const [tipoFiltro, setTipoFiltro] = useState('todos');
  const [statusFiltro, setStatusFiltro] = useState('todos');
  const [dateRange, setDateRange] = useState({
    from: subDays(new Date(), 30),
    to: new Date(),
  });

  useEffect(() => {
    loadLancamentos();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [lancamentos, searchTerm, tipoFiltro, statusFiltro, dateRange]);

  const loadLancamentos = async () => {
    setIsLoading(true);
    setMessage({ type: "", text: "" });
    try {
      const data = await LancamentoFinanceiro.list('-data_vencimento');
      setLancamentos(data || []);
    } catch (error) {
      console.error("Erro ao carregar lançamentos:", error);
      setMessage({ type: "error", text: "Erro ao carregar lançamentos." });
      setLancamentos([]);
    }
    setIsLoading(false);
  };

  const applyFilters = () => {
    let filtered = lancamentos;

    if (dateRange?.from && dateRange?.to) {
      const rangeFrom = new Date(dateRange.from);
      rangeFrom.setHours(0, 0, 0, 0);

      const rangeTo = new Date(dateRange.to);
      rangeTo.setHours(23, 59, 59, 999);

      filtered = filtered.filter(l => {
        const parts = l.data_vencimento.split('-').map(Number);
        const lancamentoDate = new Date(parts[0], parts[1] - 1, parts[2]);
        return lancamentoDate >= rangeFrom && lancamentoDate <= rangeTo;
      });
    }

    if (tipoFiltro !== 'todos') {
      filtered = filtered.filter(l => l.tipo === tipoFiltro);
    }

    if (statusFiltro !== 'todos') {
      if (statusFiltro === 'atrasado') {
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        filtered = filtered.filter(l => {
          const parts = l.data_vencimento.split('-').map(Number);
          const vencimentoDate = new Date(parts[0], parts[1] - 1, parts[2]);
          return l.status === 'pendente' && vencimentoDate < today;
        });
      } else {
        filtered = filtered.filter(l => l.status === statusFiltro);
      }
    }
    
    if (searchTerm) {
      const lowerCaseSearch = searchTerm.toLowerCase();
      filtered = filtered.filter(l => 
        l.descricao.toLowerCase().includes(lowerCaseSearch) ||
        l.cliente_fornecedor?.toLowerCase().includes(lowerCaseSearch)
      );
    }

    setFilteredLancamentos(filtered);
  };

  const handleCreate = (tipo) => {
    setEditingLancamento({ tipo });
    setShowModal(true);
    setMessage({ type: "", text: "" });
  };
  
  const handleEdit = (lancamento) => {
    setEditingLancamento(lancamento);
    setShowModal(true);
    setMessage({ type: "", text: "" });
  };
  
  const handleDelete = async (lancamento) => {
    if (window.confirm(`Tem certeza que deseja excluir "${lancamento.descricao}"?`)) {
      try {
        await LancamentoFinanceiro.delete(lancamento.id);
        setMessage({ type: "success", text: "Lançamento excluído com sucesso." });
        loadLancamentos();
      } catch (error) {
        setMessage({ type: "error", text: "Erro ao excluir lançamento." });
      }
    }
  };

  const handleToggleStatus = async (lancamento) => {
    if (lancamento.status === 'pago') return;
    try {
      await LancamentoFinanceiro.update(lancamento.id, {
        ...lancamento,
        status: 'pago',
        data_pagamento: new Date().toISOString().split('T')[0]
      });
      setMessage({ type: "success", text: "Lançamento conciliado com sucesso." });
      loadLancamentos();
    } catch (error) {
      setMessage({ type: "error", text: "Erro ao conciliar lançamento." });
    }
  };

  const handleSubmit = async (formData) => {
    setSubmitting(true);
    setMessage({ type: "", text: "" });
    try {
      if (editingLancamento && editingLancamento.id) {
        await LancamentoFinanceiro.update(editingLancamento.id, formData);
        setMessage({ type: "success", text: "Lançamento atualizado." });
      } else {
        await LancamentoFinanceiro.create(formData);
        setMessage({ type: "success", text: "Lançamento criado." });
      }
      setShowModal(false);
      setEditingLancamento(null);
      loadLancamentos();
    } catch (error) {
      console.error('Erro ao salvar lançamento:', error);
      setMessage({ type: "error", text: 'Erro ao salvar. Verifique os dados.' });
    } finally {
      setSubmitting(false);
    }
  };

  const clearFilters = () => {
    setSearchTerm('');
    setTipoFiltro('todos');
    setStatusFiltro('todos');
    setDateRange({ from: subDays(new Date(), 30), to: new Date() });
  };

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-slate-100 min-h-screen">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Financeiro</h1>
          <p className="text-slate-600 mt-1">Controle suas contas a pagar e receber</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => handleCreate('despesa')}>
            <ArrowDown className="w-4 h-4 mr-2 text-red-500" />
            Nova Despesa
          </Button>
          <Button onClick={() => handleCreate('receita')} className="bg-emerald-500 hover:bg-emerald-600">
            <ArrowUp className="w-4 h-4 mr-2" />
            Nova Receita
          </Button>
        </div>
      </div>

      {message.text && (
        <Alert variant={message.type === "error" ? "destructive" : "default"}>
          <AlertDescription>{message.text}</AlertDescription>
        </Alert>
      )}

      <FinanceStats lancamentos={filteredLancamentos} isLoading={isLoading} />

      <Card className="bg-white/80 backdrop-blur-sm shadow-lg">
        <CardHeader>
          <CardTitle>Filtros e Busca</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
              <Input placeholder="Buscar por descrição..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-10" />
            </div>
            
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start text-left font-normal">
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dateRange?.from ? (
                    dateRange.to ? (
                      <>
                        {format(dateRange.from, "dd/MM/yyyy")} -{" "}
                        {format(dateRange.to, "dd/MM/yyyy")}
                      </>
                    ) : (
                      format(dateRange.from, "dd/MM/yyyy")
                    )
                  ) : (
                    <span>Selecione a data</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  initialFocus
                  mode="range"
                  defaultMonth={dateRange?.from}
                  selected={dateRange}
                  onSelect={setDateRange}
                  numberOfMonths={2}
                />
              </PopoverContent>
            </Popover>

            <select value={tipoFiltro} onChange={(e) => setTipoFiltro(e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white">
              <option value="todos">Todos os Tipos</option>
              <option value="receita">Receitas</option>
              <option value="despesa">Despesas</option>
            </select>

            <select value={statusFiltro} onChange={(e) => setStatusFiltro(e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white">
              <option value="todos">Todos os Status</option>
              <option value="pendente">Pendente</option>
              <option value="pago">Pago</option>
              <option value="atrasado">Atrasado</option>
            </select>
          </div>
          <div className="mt-4 flex justify-end">
            <Button variant="ghost" onClick={clearFilters}>
              <X className="w-4 h-4 mr-2" />
              Limpar Filtros
            </Button>
          </div>
        </CardContent>
      </Card>
      
      <TabelaLancamentos
        lancamentos={filteredLancamentos}
        loading={isLoading}
        onEditar={handleEdit}
        onExcluir={handleDelete}
        onConciliar={handleToggleStatus}
      />

      {showModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            <div 
              className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75"
              onClick={() => {
                setShowModal(false);
                setEditingLancamento(null);
              }}
            />
            <div className="inline-block w-full max-w-lg p-6 my-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-xl rounded-lg">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-gray-900">
                  {editingLancamento?.id ? 'Editar Lançamento' : 'Novo Lançamento'}
                </h3>
                <button
                  onClick={() => {
                    setShowModal(false);
                    setEditingLancamento(null);
                  }}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X size={20} />
                </button>
              </div>
              <LancamentoForm
                lancamentoInicial={editingLancamento}
                onSubmit={handleSubmit}
                onCancel={() => {
                  setShowModal(false);
                  setEditingLancamento(null);
                }}
                loading={submitting}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}