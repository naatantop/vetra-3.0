import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Shield, AlertTriangle, UserPlus, Loader2 } from "lucide-react";
import TabelaUsuarios from '../components/usuarios/TabelaUsuarios';
import UsuarioForm from '../components/usuarios/UsuarioForm';
import Modal from '../components/ui/Modal';

export default function Usuarios() {
  const [currentUser, setCurrentUser] = useState(null);
  const [allUsers, setAllUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [message, setMessage] = useState({ type: "", text: "" });

  const [showModal, setShowModal] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    loadInitialData();
  }, []);

  const loadInitialData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const user = await User.me();
      setCurrentUser(user);
      if (user.role === 'admin') {
        const usersList = await User.list();
        setAllUsers(usersList);
      }
    } catch (e) {
      setError("Ocorreu um erro ao carregar os dados. Você pode não ter permissão para acessar esta página.");
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleEditUser = (user) => {
    setEditingUser(user);
    setShowModal(true);
  };
  
  const handleToggleActive = async (user) => {
    try {
        const newStatus = !user.is_active;
        await User.update(user.id, { is_active: newStatus });
        setMessage({ type: "success", text: `Usuário ${user.full_name} foi ${newStatus ? 'ativado' : 'desativado'}.` });
        loadInitialData();
    } catch (error) {
        setMessage({ type: "error", text: "Erro ao alterar o status do usuário." });
        console.error("Erro ao alterar status do usuário:", error);
    }
  };

  const handleSubmit = async (formData) => {
    setIsSubmitting(true);
    setMessage({ type: "", text: "" });
    try {
        const { id, ...dataToUpdate } = formData;
        await User.update(id, dataToUpdate);
        setMessage({ type: "success", text: "Permissões do usuário atualizadas com sucesso." });
        setShowModal(false);
        setEditingUser(null);
        loadInitialData();
    } catch (error) {
        setMessage({ type: "error", text: "Erro ao salvar as permissões do usuário." });
        console.error("Erro ao salvar permissões:", error);
    } finally {
        setIsSubmitting(false);
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full p-8">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (currentUser?.role !== 'admin') {
    return (
      <Alert variant="destructive" className="max-w-2xl mx-auto">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Acesso Negado</AlertTitle>
        <AlertDescription>
          Você não tem permissão para acessar a página de gerenciamento de usuários.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-slate-100 min-h-screen">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Gestão de Usuários</h1>
          <p className="text-slate-600 mt-1">Gerencie as permissões e o acesso dos usuários ao sistema.</p>
        </div>
        <Button onClick={() => alert("A funcionalidade de convidar usuários está disponível no painel de controle do seu app.")}>
          <UserPlus className="w-4 h-4 mr-2" />
          Convidar Usuário
        </Button>
      </div>

      {message.text && (
        <Alert variant={message.type === "error" ? "destructive" : "default"}>
          <AlertDescription>{message.text}</AlertDescription>
        </Alert>
      )}

      <Card className="bg-white/80 backdrop-blur-sm shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-blue-600" />
            Usuários do Sistema
          </CardTitle>
        </CardHeader>
        <CardContent>
          <TabelaUsuarios
            users={allUsers}
            onEdit={handleEditUser}
            onToggleActive={handleToggleActive}
            currentUserEmail={currentUser.email}
          />
        </CardContent>
      </Card>

      {showModal && (
        <Modal
          isOpen={showModal}
          onClose={() => setShowModal(false)}
          title={`Editando Permissões de ${editingUser?.full_name}`}
          size="large"
        >
          <UsuarioForm
            user={editingUser}
            onSubmit={handleSubmit}
            onCancel={() => setShowModal(false)}
            loading={isSubmitting}
          />
        </Modal>
      )}
    </div>
  );
}