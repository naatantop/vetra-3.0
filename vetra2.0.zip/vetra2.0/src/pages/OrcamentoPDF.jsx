
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Orcamento } from '@/api/entities';
import { ConfiguracaoEmpresa } from '@/api/entities';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function OrcamentoPDF() {
  const location = useLocation();
  const [orcamento, setOrcamento] = useState(null);
  const [empresa, setEmpresa] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
    // Auto-print when loaded
    const timer = setTimeout(() => {
      if (!loading) window.print();
    }, 1000);
    return () => clearTimeout(timer);
  }, [loading]);

  const loadData = async () => {
    try {
      const orcamentoId = new URLSearchParams(location.search).get('id');
      if (!orcamentoId) return;

      const [orcamentos, empresaData] = await Promise.all([
        Orcamento.list(),
        ConfiguracaoEmpresa.list()
      ]);

      const orcamentoEncontrado = orcamentos.find(o => o.id === orcamentoId);
      setOrcamento(orcamentoEncontrado);
      setEmpresa(empresaData[0]);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value) => {
    return (value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };
  
  const formatPaymentMethod = (orcamento) => {
    if (!orcamento || !orcamento.metodo_pagamento) return 'N/A';

    const metodos = {
      cartao_credito: "Cartão de Crédito",
      pix: "PIX",
      dinheiro: "Dinheiro",
      boleto: "Boleto",
      a_combinar: "A Combinar"
    };

    let texto = metodos[orcamento.metodo_pagamento] || orcamento.metodo_pagamento;
    
    if (orcamento.metodo_pagamento === 'cartao_credito' && orcamento.parcelas > 1) {
      texto += ` em ${orcamento.parcelas}x`;
    }

    return texto;
  }

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    try {
      return format(new Date(dateString), "dd/MM/yyyy", { locale: ptBR });
    } catch {
      return 'N/A';
    }
  };

  if (loading || !orcamento) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-8 bg-white text-slate-900 print:p-6">
      <style jsx global>{`
        @media print {
          body { -webkit-print-color-adjust: exact; }
          .no-print { display: none !important; }
        }
      `}</style>

      {/* Cabeçalho da Empresa */}
      <div className="border-b-2 border-slate-300 pb-6 mb-8">
        <div className="flex justify-between items-start">
          <div>
            {empresa?.logo_url && (
              <img src={empresa.logo_url} alt="Logo" className="h-16 mb-4" />
            )}
            <h1 className="text-2xl font-bold text-slate-900">{empresa?.nome_empresa || 'Empresa'}</h1>
            {empresa?.razao_social && (
              <p className="text-slate-600">{empresa.razao_social}</p>
            )}
            {empresa?.cnpj && (
              <p className="text-slate-600">CNPJ: {empresa.cnpj}</p>
            )}
          </div>
          <div className="text-right">
            <h2 className="text-3xl font-bold text-blue-600">ORÇAMENTO</h2>
            <p className="text-xl">Nº {orcamento.numero || `ORC-${orcamento.id.slice(-6)}`}</p>
            <p className="text-slate-600">Data: {formatDate(orcamento.data_orcamento)}</p>
            {orcamento.data_validade && (
              <p className="text-slate-600">Válido até: {formatDate(orcamento.data_validade)}</p>
            )}
          </div>
        </div>
      </div>

      {/* Dados do Cliente */}
      <div className="mb-8">
        <h3 className="text-lg font-bold text-slate-900 mb-4">DADOS DO CLIENTE</h3>
        <div className="bg-slate-50 p-4 rounded-lg">
          <p><strong>Cliente:</strong> {orcamento.cliente_nome}</p>
          <p><strong>Vendedor:</strong> {orcamento.vendedor}</p>
          {orcamento.prazo_entrega && (
            <p><strong>Prazo de Entrega:</strong> {orcamento.prazo_entrega}</p>
          )}
        </div>
      </div>

      {/* Itens do Orçamento */}
      {orcamento.itens && orcamento.itens.length > 0 && (
        <div className="mb-8">
          <h3 className="text-lg font-bold text-slate-900 mb-4">ITENS DO ORÇAMENTO</h3>
          <table className="w-full border-collapse border border-slate-300">
            <thead>
              <tr className="bg-slate-100">
                <th className="border border-slate-300 p-3 text-left">Produto</th>
                <th className="border border-slate-300 p-3 text-left">Medidas</th>
                <th className="border border-slate-300 p-3 text-left">Cor/Acabamento</th>
                <th className="border border-slate-300 p-3 text-center">Qtd</th>
                <th className="border border-slate-300 p-3 text-right">Preço Unit.</th>
                <th className="border border-slate-300 p-3 text-right">Subtotal</th>
              </tr>
            </thead>
            <tbody>
              {orcamento.itens.map((item, index) => (
                <tr key={index}>
                  <td className="border border-slate-300 p-3">
                    <div>
                      <p className="font-medium">{item.produto_nome}</p>
                      {item.observacoes && (
                        <p className="text-sm text-slate-600 mt-1">{item.observacoes}</p>
                      )}
                    </div>
                  </td>
                  <td className="border border-slate-300 p-3">
                    {(() => {
                      // Verificar tipo de medida do item
                      const tipoMedida = item.tipo_medida;
                      
                      if (tipoMedida === 'm2' && item.largura_mm && item.altura_mm) {
                        return <span>{item.largura_mm}mm × {item.altura_mm}mm</span>;
                      } else if ((tipoMedida === 'metro_linear' || tipoMedida === 'metro') && item.comprimento_mm) {
                        return <span>{item.comprimento_mm}mm</span>;
                      } else if (tipoMedida === 'unitario' || tipoMedida === 'unidade' || !tipoMedida) {
                        return <span>-</span>;
                      } else if (tipoMedida === 'kit') {
                        return <span>Kit</span>;
                      } else {
                        // Fallback - tentar mostrar qualquer medida disponível
                        if (item.largura_mm && item.altura_mm) {
                          return <span>{item.largura_mm}mm × {item.altura_mm}mm</span>;
                        } else if (item.comprimento_mm) {
                          return <span>{item.comprimento_mm}mm</span>;
                        } else {
                          return <span>-</span>;
                        }
                      }
                    })()}
                  </td>
                  <td className="border border-slate-300 p-3">
                    <div className="text-sm space-y-1">
                      {item.cor_perfil && <div><strong>Cor:</strong> {item.cor_perfil}</div>}
                      {item.acabamento && <div><strong>Acab:</strong> {item.acabamento}</div>}
                      {!item.cor_perfil && !item.acabamento && <span>-</span>}
                    </div>
                  </td>
                  <td className="border border-slate-300 p-3 text-center">{item.quantidade}</td>
                  <td className="border border-slate-300 p-3 text-right">{formatCurrency(item.preco_unitario)}</td>
                  <td className="border border-slate-300 p-3 text-right font-medium">{formatCurrency(item.subtotal)}</td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Totais */}
          <div className="mt-4">
            <div className="flex justify-end">
              <div className="w-80 space-y-2">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>{formatCurrency(orcamento.valor_total)}</span>
                </div>
                {orcamento.desconto_valor > 0 && (
                  <div className="flex justify-between text-red-600">
                    <span>Desconto:</span>
                    <span>-{formatCurrency(orcamento.desconto_valor)}</span>
                  </div>
                )}
                <div className="border-t pt-2">
                  <div className="flex justify-between text-xl font-bold">
                    <span>TOTAL:</span>
                    <span className="text-green-600">{formatCurrency(orcamento.valor_final || orcamento.valor_total)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Condições de Pagamento */}
      <div className="mb-6">
          <h3 className="text-lg font-bold text-slate-900 mb-2">CONDIÇÕES DE PAGAMENTO</h3>
          <div className="bg-slate-50 p-4 rounded-lg">
            <p className="font-semibold">{formatPaymentMethod(orcamento)}</p>
            {orcamento.observacoes_pagamento && (
              <p className="whitespace-pre-line mt-2">{orcamento.observacoes_pagamento}</p>
            )}
          </div>
        </div>

      {/* Observações Gerais */}
      {orcamento.observacoes_gerais && (
        <div className="mb-6">
          <h3 className="text-lg font-bold text-slate-900 mb-2">OBSERVAÇÕES GERAIS</h3>
          <div className="bg-slate-50 p-4 rounded-lg">
            <p className="whitespace-pre-line">{orcamento.observacoes_gerais}</p>
          </div>
        </div>
      )}

      {/* Endereço de Instalação */}
      {orcamento.endereco_instalacao && Object.values(orcamento.endereco_instalacao).some(v => v) && (
        <div className="mb-6">
          <h3 className="text-lg font-bold text-slate-900 mb-2">ENDEREÇO DE INSTALAÇÃO</h3>
          <div className="bg-slate-50 p-4 rounded-lg">
            {orcamento.endereco_instalacao.logradouro && (
              <p>{orcamento.endereco_instalacao.logradouro}{orcamento.endereco_instalacao.numero && `, ${orcamento.endereco_instalacao.numero}`}</p>
            )}
            {orcamento.endereco_instalacao.complemento && <p>{orcamento.endereco_instalacao.complemento}</p>}
            {orcamento.endereco_instalacao.bairro && <p>{orcamento.endereco_instalacao.bairro}</p>}
            {orcamento.endereco_instalacao.cidade && orcamento.endereco_instalacao.uf && (
              <p>{orcamento.endereco_instalacao.cidade} - {orcamento.endereco_instalacao.uf}</p>
            )}
            {orcamento.endereco_instalacao.cep && <p>CEP: {orcamento.endereco_instalacao.cep}</p>}
          </div>
        </div>
      )}

      {/* Rodapé */}
      <div className="border-t pt-6 mt-8 text-center text-sm text-slate-600">
        <p>Orçamento gerado em {format(new Date(), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}</p>
        {empresa?.telefone && <p>Telefone: {empresa.telefone}</p>}
        {empresa?.email && <p>Email: {empresa.email}</p>}
        {empresa?.endereco && (
          <p>
            {empresa.endereco.logradouro && `${empresa.endereco.logradouro}, `}
            {empresa.endereco.numero && `${empresa.endereco.numero} - `}
            {empresa.endereco.bairro && `${empresa.endereco.bairro} - `}
            {empresa.endereco.cidade && empresa.endereco.uf && `${empresa.endereco.cidade}/${empresa.endereco.uf}`}
          </p>
        )}
      </div>
    </div>
  );
}
