
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Settings, Trash2, AlertTriangle, Shield, Download, FileText, Plus, Pencil } from "lucide-react";
import { Produto } from "@/api/entities";
import { Cliente } from "@/api/entities";
import { Orcamento } from "@/api/entities";
import { OrdemServico } from "@/api/entities";
import { LancamentoFinanceiro } from "@/api/entities";
import { Financeiro } from "@/api/entities";
import { User } from "@/api/entities";
import { getAllCategorias, getCustomCategories, saveCustomCategories as saveCustomCategoriesUtil, getCategoriaLabel, getCustomAcabamentos, saveCustomAcabamentos, getAcabamentosPorCategoria } from '../components/utils/CategoriaUtils';

// Categorias padrão do sistema
const getDefaultCategories = () => [
  { value: 'vidro_temperado', label: 'Vidro Temperado' },
  { value: 'vidro_comum', label: 'Vidro Comum' },
  { value: 'esquadria', label: 'Esquadria' },
  { value: 'acessorio', label: 'Acessório' },
  { value: 'espelhos', label: 'Espelhos' },
  { value: 'acm', label: 'ACM' },
  { value: 'forro_pvc', label: 'Forro PVC' },
];

export default function Configuracoes() {
  const [showResetForm, setShowResetForm] = useState(false);
  const [showCategoriesForm, setShowCategoriesForm] = useState(false);
  const [customCategories, setCustomCategories] = useState([]);
  const [newCategory, setNewCategory] = useState({ value: '', label: '', acabamentos: [] });
  const [editingCategory, setEditingCategory] = useState(null); // State to track editing
  const [newAcabamento, setNewAcabamento] = useState(''); // State for new finish input
  const [confirmacao, setConfirmacao] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [message, setMessage] = useState({ type: "", text: "" });
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    loadCurrentUser();
    loadCustomCategories();
  }, []);

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      console.error("Erro ao carregar usuário:", error);
    }
  };

  const loadCustomCategories = () => {
    const customCats = getCustomCategories();
    setCustomCategories(customCats);
  };

  const handleSaveCategory = () => {
    if (!newCategory.value || !newCategory.label) {
      setMessage({ type: "error", text: "Preencha o código e o nome da categoria." });
      return;
    }

    if (editingCategory) {
      // Logic for UPDATING an existing category
      const updatedCategories = customCategories.map(cat => 
        cat.value === editingCategory.value 
          ? { ...cat, label: newCategory.label } // Update only the label
          : cat
      );
      setCustomCategories(updatedCategories);
      saveCustomCategoriesUtil(updatedCategories); // Use the utility function
      
      // Salvar acabamentos personalizados se houver ou se forem removidos
      const customAcabamentosData = getCustomAcabamentos();
      if (newCategory.acabamentos && newCategory.acabamentos.length > 0) {
        customAcabamentosData[editingCategory.value] = newCategory.acabamentos;
      } else {
        // If no custom finishes are provided, remove the entry for this category
        delete customAcabamentosData[editingCategory.value];
      }
      saveCustomAcabamentos(customAcabamentosData);

      setMessage({ type: "success", text: "Categoria atualizada com sucesso!" });
      setEditingCategory(null); // Exit editing mode
      setNewCategory({ value: '', label: '', acabamentos: [] }); // Reset form
      setNewAcabamento('');
    } else {
      // Logic for ADDING a new category
      const allCategories = getAllCategorias(); // Use utility function to get all categories (default + custom)
      if (allCategories.some(cat => cat.value === newCategory.value)) {
        setMessage({ type: "error", text: `Já existe uma categoria com o código '${newCategory.value}'.` });
        return;
      }
      const updatedCategories = [...customCategories, { value: newCategory.value, label: newCategory.label }];
      setCustomCategories(updatedCategories);
      saveCustomCategoriesUtil(updatedCategories); // Use the utility function
      
      // Salvar acabamentos personalizados se houver
      if (newCategory.acabamentos && newCategory.acabamentos.length > 0) {
        const customAcabamentosData = getCustomAcabamentos();
        customAcabamentosData[newCategory.value] = newCategory.acabamentos;
        saveCustomAcabamentos(customAcabamentosData);
      }
      
      setMessage({ type: "success", text: "Categoria adicionada com sucesso!" });
      setNewCategory({ value: '', label: '', acabamentos: [] });
      setNewAcabamento('');
    }
  };
  
  const handleStartEdit = (category) => {
    setEditingCategory(category);
    // Retrieve existing finishes for this category
    const acabamentos = getAcabamentosPorCategoria(category.value);
    setNewCategory({ 
      value: category.value, 
      label: category.label,
      acabamentos: acabamentos // Populate acabamentos for editing
    }); 
    setNewAcabamento('');
    setMessage({ type: "", text: "" }); // Clear any previous messages
  };
  
  const handleCancelEdit = () => {
    setEditingCategory(null);
    setNewCategory({ value: '', label: '', acabamentos: [] });
    setNewAcabamento('');
    setMessage({ type: "", text: "" }); // Clear any previous messages
  };

  const handleAddAcabamento = () => {
    if (!newAcabamento.trim()) {
      setMessage({ type: "error", text: "Digite um acabamento válido." });
      return;
    }
    
    // Ensure uniqueness, case-insensitively
    const normalizedNewAcabamento = newAcabamento.trim().toLowerCase();
    const existingAcabamentosNormalized = (newCategory.acabamentos || []).map(ac => ac.toLowerCase());

    if (existingAcabamentosNormalized.includes(normalizedNewAcabamento)) {
      setMessage({ type: "error", text: "Este acabamento já foi adicionado." });
      return;
    }
    
    setNewCategory(prev => ({
      ...prev,
      acabamentos: [...(prev.acabamentos || []), newAcabamento.trim()]
    }));
    setNewAcabamento('');
    setMessage({ type: "", text: "" });
  };

  const handleRemoveAcabamento = (acabamentoToRemove) => {
    setNewCategory(prev => ({
      ...prev,
      acabamentos: (prev.acabamentos || []).filter(ac => ac !== acabamentoToRemove)
    }));
  };

  const handleRemoveCategory = (valueToRemove) => {
    const updatedCategories = customCategories.filter(cat => cat.value !== valueToRemove);
    setCustomCategories(updatedCategories);
    saveCustomCategoriesUtil(updatedCategories); // Use the utility function

    // Also remove any custom finishes associated with this category
    const customAcabamentosData = getCustomAcabamentos();
    delete customAcabamentosData[valueToRemove];
    saveCustomAcabamentos(customAcabamentosData);

    setMessage({ type: "success", text: "Categoria removida com sucesso!" });
  };

  const exportarProdutosCSV = async () => {
    setIsExporting(true);
    try {
      const produtos = await Produto.list();
      // Use utility function for all available categories and for getting labels
      const dadosExportacao = produtos.map(produto => ({
        'Nome': produto.nome,
        'Código': produto.codigo || '',
        'Categoria': getCategoriaLabel(produto.categoria), // Use utility function
        'Preço de Custo': produto.preco_custo || 0,
        'Preço de Venda': produto.preco_venda || 0,
        'Estoque Atual': produto.estoque_atual || produto.estoque || 0,
        'Estoque Mínimo': produto.estoque_minimo || 0,
        'Status': produto.ativo ? 'Ativo' : 'Inativo',
        'Data de Criação': produto.created_date ? new Date(produto.created_date).toLocaleDateString('pt-BR') : 'N/A',
        'Última Atualização': produto.updated_date ? new Date(produto.updated_date).toLocaleDateString('pt-BR') : 'N/A'
      }));

      const headers = Object.keys(dadosExportacao[0] || {});
      const csvContent = [
        headers.join(','),
        ...dadosExportacao.map(row =>
          headers.map(header => {
            const value = row[header];
            const stringValue = String(value);
            return (stringValue.includes(',') || stringValue.includes('"') || stringValue.includes('\n'))
              ? `"${stringValue.replace(/"/g, '""')}"`
              : stringValue;
          }).join(',')
        )
      ].join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `produtos_${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setMessage({ type: "success", text: "Produtos exportados para CSV com sucesso." });
    } catch (error) {
      console.error("Erro ao exportar CSV:", error);
      setMessage({ type: "error", text: "Erro ao exportar dados para CSV." });
    } finally {
      setIsExporting(false);
    }
  };

  const exportarProdutosJSON = async () => {
    setIsExporting(true);
    try {
      const produtos = await Produto.list();
      // Use utility function for all available categories and for getting labels
      const dadosExportacao = produtos.map(produto => ({
        id: produto.id,
        nome: produto.nome,
        codigo: produto.codigo || '',
        categoria: produto.categoria,
        categoria_nome: getCategoriaLabel(produto.categoria), // Use utility function
        unidade: produto.unidade || 'N/A',
        preco_custo: produto.preco_custo || 0,
        preco_venda: produto.preco_venda || 0,
        estoque_atual: produto.estoque_atual || produto.estoque || 0,
        estoque_minimo: produto.estoque_minimo || 0,
        ativo: produto.ativo,
        created_date: produto.created_date,
        updated_date: produto.updated_date
      }));

      const blob = new Blob([JSON.stringify(dadosExportacao, null, 2)], {
        type: 'application/json;charset=utf-8;'
      });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `produtos_${new Date().toISOString().split('T')[0]}.json`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setMessage({ type: "success", text: "Produtos exportados para JSON com sucesso." });
    } catch (error) {
      console.error("Erro ao exportar JSON:", error);
      setMessage({ type: "error", text: "Erro ao exportar dados para JSON." });
    } finally {
      setIsExporting(false);
    }
  };

  const handleResetSistema = async () => {
    if (confirmacao !== "DELETAR TUDO") {
      setMessage({ type: "error", text: "Digite 'DELETAR TUDO' para confirmar!" });
      return;
    }

    setIsDeleting(true);
    setMessage({ type: "info", text: "Iniciando reset do sistema..." });

    try {
      const entidades = [
        { entity: Produto, name: "Produtos" },
        { entity: Cliente, name: "Clientes" },
        { entity: Orcamento, name: "Orçamentos" },
        { entity: OrdemServico, name: "Ordens de Serviço" },
        { entity: LancamentoFinanceiro, name: "Lançamentos Financeiros" },
        { entity: Financeiro, name: "Registros Financeiros" }
      ];

      let totalDeletados = 0;

      for (const { entity, name } of entidades) {
        try {
          const registros = await entity.list();
          setMessage({ type: "info", text: `Deletando ${registros.length} registros de ${name}...` });

          for (const registro of registros) {
            await entity.delete(registro.id);
            totalDeletados++;
          }
        } catch (error) {
          console.error(`Erro ao deletar ${name}:`, error);
        }
      }

      setMessage({
        type: "success",
        text: `Sistema resetado com sucesso! ${totalDeletados} registros foram deletados.`
      });

      setConfirmacao("");
      setShowResetForm(false);

    } catch (error) {
      console.error("Erro no reset do sistema:", error);
      setMessage({ type: "error", text: "Erro ao resetar sistema. Tente novamente." });
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50/50 via-blue-50/20 to-indigo-50/20 min-h-full">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Configurações do Sistema</h1>
        <p className="text-slate-600">Personalize o sistema e configurações avançadas</p>
      </div>

      {message.text && (
        <Alert variant={message.type === "error" ? "destructive" : message.type === "success" ? "default" : "default"} className="mb-6">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{message.text}</AlertDescription>
        </Alert>
      )}

      {/* Nova seção para Categorias */}
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-slate-900">
            <Settings className="w-5 h-5" />
            Categorias de Produtos
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <p className="text-slate-600 mb-4">
            Gerencie as categorias disponíveis para classificação dos produtos e seus acabamentos.
          </p>

          {!showCategoriesForm ? (
            <Button
              variant="outline"
              onClick={() => {
                setShowCategoriesForm(true);
                setMessage({ type: "", text: "" }); // Clear messages when opening
              }}
            >
              <Settings className="w-4 h-4 mr-2" />
              Gerenciar Categorias
            </Button>
          ) : (
            <div className="space-y-6">
              {/* Categorias Padrão */}
              <div>
                <h4 className="font-medium text-slate-800 mb-3">Categorias Padrão do Sistema</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                  {getDefaultCategories().map(categoria => (
                    <div key={categoria.value} className="p-3 bg-slate-100 rounded-lg">
                      <span className="text-sm font-medium text-slate-700">{categoria.label}</span>
                      <span className="text-xs text-slate-500 block">({categoria.value})</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Categorias Personalizadas */}
              <div>
                <h4 className="font-medium text-slate-800 mb-3">Categorias Personalizadas</h4>
                {customCategories.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 mb-4">
                    {customCategories.map(categoria => (
                      <div key={categoria.value} className="p-3 bg-blue-50 border border-blue-200 rounded-lg flex justify-between items-center">
                        <div>
                          <span className="text-sm font-medium text-blue-800">{categoria.label}</span>
                          <span className="text-xs text-blue-600 block">({categoria.value})</span>
                          <span className="text-xs text-slate-500">
                            {getAcabamentosPorCategoria(categoria.value).length} acabamentos
                          </span>
                        </div>
                        <div className="flex items-center">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleStartEdit(categoria)}
                            className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                            aria-label={`Editar categoria ${categoria.label}`}
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleRemoveCategory(categoria.value)}
                            className="text-red-600 hover:text-red-700 hover:bg-red-50"
                            aria-label={`Remover categoria ${categoria.label}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-slate-500 text-sm mb-4">Nenhuma categoria personalizada adicionada.</p>
                )}

                {/* Adicionar/Editar Categoria Form */}
                <div className={`p-4 rounded-lg border ${editingCategory ? 'bg-yellow-50 border-yellow-200' : 'bg-slate-50 border-slate-200'}`}>
                  <h5 className="font-medium text-slate-700 mb-3">{editingCategory ? 'Editar Categoria' : 'Adicionar Nova Categoria'}</h5>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                    <div>
                      <Label htmlFor="category-code">Código da Categoria</Label>
                      <Input
                        id="category-code"
                        value={newCategory.value}
                        onChange={(e) => setNewCategory(prev => ({ ...prev, value: e.target.value.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '') }))}
                        placeholder="ex: nova_categoria"
                        aria-label="Código da nova categoria"
                        readOnly={!!editingCategory}
                        className={editingCategory ? 'bg-slate-200 cursor-not-allowed' : ''}
                      />
                      {editingCategory && <p className="text-xs text-slate-500 mt-1">O código não pode ser alterado.</p>}
                    </div>
                    <div>
                      <Label htmlFor="category-name">Nome da Categoria</Label>
                      <Input
                        id="category-name"
                        value={newCategory.label}
                        onChange={(e) => setNewCategory(prev => ({ ...prev, label: e.target.value }))}
                        placeholder="ex: Nova Categoria"
                        aria-label="Nome da nova categoria"
                      />
                    </div>
                  </div>

                  {/* Seção de Acabamentos */}
                  <div className="mb-4">
                    <Label className="text-sm font-medium text-slate-700 mb-2 block">Acabamentos da Categoria</Label>
                    
                    {/* Lista de acabamentos atuais */}
                    {newCategory.acabamentos && newCategory.acabamentos.length > 0 && (
                      <div className="flex flex-wrap gap-2 mb-3">
                        {newCategory.acabamentos.map((acabamento, index) => (
                          <div key={index} className="flex items-center gap-1 bg-white border border-slate-300 rounded-lg px-3 py-1">
                            <span className="text-sm">{acabamento}</span>
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => handleRemoveAcabamento(acabamento)}
                              className="h-4 w-4 p-0 text-red-500 hover:text-red-700"
                              aria-label={`Remover acabamento ${acabamento}`}
                            >
                              ×
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Adicionar novo acabamento */}
                    <div className="flex gap-2">
                      <Input
                        value={newAcabamento}
                        onChange={(e) => setNewAcabamento(e.target.value)}
                        placeholder="ex: Fosco, Brilhante..."
                        onKeyPress={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault(); // Prevent form submission
                            handleAddAcabamento();
                          }
                        }}
                        aria-label="Novo acabamento"
                      />
                      <Button
                        type="button"
                        onClick={handleAddAcabamento}
                        size="sm"
                        variant="outline"
                      >
                        <Plus className="w-4 h-4" />
                      </Button>
                    </div>
                    <p className="text-xs text-slate-500 mt-1">
                      Adicione os acabamentos disponíveis para esta categoria. Se não adicionar nenhum, os acabamentos padrão serão usados.
                    </p>
                  </div>

                  <div className="flex gap-3 mt-4">
                    <Button onClick={handleSaveCategory} size="sm">
                      {editingCategory ? <Pencil className="w-4 h-4 mr-2" /> : <Plus className="w-4 h-4 mr-2" />}
                      {editingCategory ? 'Atualizar Categoria' : 'Adicionar Categoria'}
                    </Button>
                    {editingCategory && (
                      <Button onClick={handleCancelEdit} size="sm" variant="outline">
                        Cancelar
                      </Button>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex gap-3 pt-4 border-t border-slate-100">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowCategoriesForm(false);
                    handleCancelEdit(); // Also reset edit form
                    setMessage({ type: "", text: "" });
                  }}
                >
                  Fechar
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-slate-900">
            <FileText className="w-5 h-5" />
            Exportação de Dados
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <p className="text-slate-600 mb-4">
            Exporte os dados dos produtos cadastrados no sistema para backup ou análise externa.
          </p>
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={exportarProdutosCSV}
              disabled={isExporting}
            >
              {isExporting ? (
                <>
                  <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2" />
                  Exportando...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 mr-2" />
                  Exportar Produtos CSV
                </>
              )}
            </Button>
            <Button
              variant="outline"
              onClick={exportarProdutosJSON}
              disabled={isExporting}
            >
              {isExporting ? (
                <>
                  <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2" />
                  Exportando...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 mr-2" />
                  Exportar Produtos JSON
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {currentUser?.role === 'admin' && (
        <Card className="bg-white/80 backdrop-blur-sm border-red-200 shadow-lg">
          <CardHeader className="border-b border-red-100">
            <CardTitle className="flex items-center gap-2 text-red-700">
              <Shield className="w-5 h-5" />
              Zona Perigosa
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-red-800">Atenção: Ação Irreversível</h3>
                  <p className="text-sm text-red-700 mt-1">
                    Esta ação irá deletar permanentemente TODOS os dados do sistema, incluindo:
                    produtos, clientes, orçamentos, ordens de serviço e registros financeiros.
                  </p>
                </div>
              </div>
            </div>

            {!showResetForm ? (
              <Button
                variant="outline"
                className="border-red-300 text-red-700 hover:bg-red-50"
                onClick={() => {
                  setShowResetForm(true);
                  setMessage({ type: "", text: "" }); // Clear messages when opening
                }}
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Resetar Sistema Completo
              </Button>
            ) : (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="confirmacao" className="text-red-700 font-medium">
                    Digite "DELETAR TUDO" para confirmar:
                  </Label>
                  <Input
                    id="confirmacao"
                    value={confirmacao}
                    onChange={(e) => setConfirmacao(e.target.value)}
                    placeholder="DELETAR TUDO"
                    className="border-red-300 focus:border-red-500"
                  />
                </div>

                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setShowResetForm(false);
                      setConfirmacao("");
                      setMessage({ type: "", text: "" });
                    }}
                    disabled={isDeleting}
                  >
                    Cancelar
                  </Button>
                  <Button
                    variant="destructive"
                    onClick={handleResetSistema}
                    disabled={isDeleting || confirmacao !== "DELETAR TUDO"} // Only enable if exact match
                    className="bg-red-600 hover:bg-red-700"
                  >
                    {isDeleting ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                        Deletando...
                      </>
                    ) : (
                      <>
                        <Trash2 className="w-4 h-4 mr-2" />
                        Confirmar Reset
                      </>
                    )}
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
        <CardContent className="p-12">
          <div className="text-center text-slate-500">
            <Settings className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <h3 className="text-lg font-medium mb-2">Outras Configurações</h3>
            <p>Configurações adicionais do sistema serão adicionadas conforme necessário.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
