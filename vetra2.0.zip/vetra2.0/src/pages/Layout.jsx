

import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { User } from "@/api/entities";
import { ConfiguracaoEmpresa } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import {
  LayoutDashboard,
  Users,
  Package,
  ShoppingCart,
  Calculator,
  FileText,
  Settings,
  LogOut,
  ChevronDown,
  Menu,
  X,
  Scissors,
  Building2,
  Truck,
  CheckSquare,
  Calendar,
  FolderOpen,
  BarChart3,
  Shield,
  AlertTriangle,
  Upload,
} from "lucide-react";

const pagePermissions = {
  "Dashboard": "dashboard_view",
  "Produtos": "produtos_view",
  "Clientes": "clientes_view",
  "Orcamentos": "vendas_view",
  "Vendas": "vendas_view",
  "Producao": "producao_view",
  "Financeiro": "financeiro_view",
  "Relatorios": "relatorios_view",
  "Configuracoes": "configuracoes_view",
  "Usuarios": "usuarios_view",
  "ConfiguracaoEmpresa": "configuracoes_view",
  "Importacao": "configuracoes_view",
};

const allNavigationItems = [
  { title: "Dashboard", url: createPageUrl("Dashboard"), icon: LayoutDashboard, pageName: "Dashboard" },
  { title: "Produtos", url: createPageUrl("Produtos"), icon: Package, pageName: "Produtos" },
  { title: "Clientes", url: createPageUrl("Clientes"), icon: Users, pageName: "Clientes" },
  { title: "Orçamentos", url: createPageUrl("Orcamentos"), icon: Calculator, pageName: "Orcamentos" },
  { title: "Vendas", url: createPageUrl("Vendas"), icon: ShoppingCart, pageName: "Vendas" },
  { title: "Produção", url: createPageUrl("Producao"), icon: Scissors, pageName: "Producao" },
  { title: "Financeiro", url: createPageUrl("Financeiro"), icon: FileText, pageName: "Financeiro" },
  { title: "Compras", url: createPageUrl("Compras"), icon: Building2, pageName: "Compras" },
  { title: "Entregas", url: createPageUrl("Entregas"), icon: Truck, pageName: "Entregas" },
  { title: "Instalações", url: createPageUrl("Instalacoes"), icon: CheckSquare, pageName: "Instalacoes" },
  { title: "Agenda", url: createPageUrl("Agenda"), icon: Calendar, pageName: "Agenda" },
  { title: "Documentos", url: createPageUrl("Documentos"), icon: FolderOpen, pageName: "Documentos" },
  { title: "Relatórios", url: createPageUrl("Relatorios"), icon: BarChart3, pageName: "Relatorios" },
  { title: "Importação", url: createPageUrl("Importacao"), icon: Upload, pageName: "Importacao" },
  { title: "Configurações", url: createPageUrl("Configuracoes"), icon: Settings, pageName: "Configuracoes" },
  { title: "Usuários", url: createPageUrl("Usuarios"), icon: Shield, pageName: "Usuarios" },
  { title: "Config. Empresa", url: createPageUrl("ConfiguracaoEmpresa"), icon: Building2, pageName: "ConfiguracaoEmpresa" },
];

function NavLink({ item, isActive, isCollapsed }) {
  return (
    <Link to={item.url}>
      <div
        className={`flex items-center p-3 my-1 rounded-lg transition-colors duration-200 cursor-pointer ${
          isActive
            ? "bg-blue-600 text-white shadow-md"
            : "text-slate-600 hover:bg-blue-100/60 hover:text-blue-700"
        } ${isCollapsed ? "justify-center" : ""}`}
      >
        <item.icon className="h-5 w-5" />
        {!isCollapsed && <span className="ml-4 font-medium">{item.title}</span>}
      </div>
    </Link>
  );
}

export default function Layout({ children, currentPageName }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [configEmpresa, setConfigEmpresa] = useState(null);
  const [navigationItems, setNavigationItems] = useState([]);
  const location = useLocation();

  useEffect(() => {
    loadUserAndConfig();
  }, []);

  const loadUserAndConfig = async () => {
    try {
      const [userData, configData] = await Promise.all([
        User.me().catch(() => null),
        ConfiguracaoEmpresa.list().catch(() => [])
      ]);
      
      setCurrentUser(userData);
      setConfigEmpresa(configData?.[0] || null);
      
      if (userData) {
        const filteredItems = allNavigationItems.filter(item => {
          const requiredPermission = pagePermissions[item.pageName];
          if (!requiredPermission) return true;
          if (userData.role === 'admin') return true;
          return userData.permissions && userData.permissions.includes(requiredPermission);
        });
        setNavigationItems(filteredItems);
      }
    } catch (error) {
      console.error("Erro ao carregar dados do usuário:", error);
    }
  };

  const handleLogout = async () => {
    try {
      await User.logout();
    } catch (error) {
      console.error("Erro ao fazer logout:", error);
    }
  };

  function VetraLogoCustom() {
    return (
      <div className="flex items-center space-x-3">
        <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-blue-800 rounded-lg flex items-center justify-center">
          <span className="text-white font-bold text-sm">V</span>
        </div>
        <div>
          <h2 className="text-lg font-bold text-slate-800">
            {configEmpresa?.nome_empresa || "VETRA 2.0"}
          </h2>
          <p className="text-xs text-slate-500">Sistema de Gestão</p>
        </div>
      </div>
    );
  }

  function SidebarContent() {
    return (
      <div className="flex flex-col h-full">
        <div className={`p-4 border-b border-slate-200 flex items-center ${isSidebarCollapsed ? 'justify-center' : 'justify-between'}`}>
          {!isSidebarCollapsed && <VetraLogoCustom />}
        </div>
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {navigationItems.map((item) => (
            <NavLink
              key={item.title}
              item={item}
              isActive={location.pathname === item.url}
              isCollapsed={isSidebarCollapsed}
            />
          ))}
        </nav>
        <div className="p-4 border-t border-slate-200 flex-shrink-0">
          {currentUser && (
            <div className="flex items-center justify-between">
              {!isSidebarCollapsed && (
                <div className="flex flex-col">
                  <span className="font-semibold text-slate-800 text-sm">{currentUser.full_name}</span>
                  <span className="text-xs text-slate-500">{currentUser.email}</span>
                </div>
              )}
              <Button variant="ghost" size="icon" onClick={handleLogout} className="text-slate-500 hover:text-red-500">
                <LogOut className="h-5 w-5" />
              </Button>
            </div>
          )}
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-slate-50">
      <aside
        className={`hidden lg:flex flex-col bg-white shadow-lg transition-all duration-300 ${
          isSidebarCollapsed ? "w-20" : "w-64"
        }`}
      >
        <SidebarContent />
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
          className="absolute -right-3 top-20 bg-white border border-slate-200 rounded-full shadow-md hover:shadow-lg z-10"
        >
          <ChevronDown className={`h-4 w-4 transition-transform ${isSidebarCollapsed ? "rotate-90" : "-rotate-90"}`} />
        </Button>
      </aside>

      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="lg:hidden bg-white shadow-sm border-b border-slate-200 px-4 py-3">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMobileMenuOpen(true)}
            >
              <Menu className="h-6 w-6" />
            </Button>
            <VetraLogoCustom />
          </div>
        </header>

        <main className="flex-1 overflow-auto">
          {children}
        </main>
      </div>

      {isMobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-50 bg-black bg-opacity-50" onClick={() => setIsMobileMenuOpen(false)}>
          <div className="fixed left-0 top-0 h-full w-80 bg-white shadow-lg" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-4 border-b border-slate-200">
              <VetraLogoCustom />
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <X className="h-6 w-6" />
              </Button>
            </div>
            <nav className="flex-1 p-3 space-y-1 overflow-y-auto" style={{ height: 'calc(100vh - 140px)' }}>
              {navigationItems.map((item) => (
                <div key={item.title} onClick={() => setIsMobileMenuOpen(false)}>
                  <NavLink
                    item={item}
                    isActive={location.pathname === item.url}
                    isCollapsed={false}
                  />
                </div>
              ))}
            </nav>
            <div className="p-4 border-t border-slate-200">
              {currentUser && (
                <div className="flex items-center justify-between">
                  <div className="flex flex-col">
                    <span className="font-semibold text-slate-800 text-sm">{currentUser.full_name}</span>
                    <span className="text-xs text-slate-500">{currentUser.email}</span>
                  </div>
                  <Button variant="ghost" size="icon" onClick={handleLogout} className="text-slate-500 hover:text-red-500">
                    <LogOut className="h-5 w-5" />
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

