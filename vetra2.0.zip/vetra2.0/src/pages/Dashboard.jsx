import React, { useState, useEffect, lazy, Suspense } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Users, 
  Package, 
  FileText, 
  DollarSign, 
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Calendar,
  Clock,
  Target,
  Award,
  BarChart3,
  Zap
} from "lucide-react";
import { Cliente } from "@/api/entities";
import { Produto } from "@/api/entities";
import { Orcamento } from "@/api/entities";
import { OrdemServico } from "@/api/entities";
import { Financeiro } from "@/api/entities";
import { format, subDays, startOfMonth, endOfMonth, subMonths, startOfISOWeek } from "date-fns";
import { ptBR } from "date-fns/locale";

const StatCard = lazy(() => import("../components/dashboard/StatCard"));
const RecentActivity = lazy(() => import("../components/dashboard/RecentActivity"));
const PendingTasks = lazy(() => import("../components/dashboard/PendingTasks"));
const FinancialOverview = lazy(() => import("../components/dashboard/FinancialOverview"));
const SalesChart = lazy(() => import("../components/dashboard/SalesChart"));
const TopProducts = lazy(() => import("../components/dashboard/TopProducts"));
const QuickActions = lazy(() => import("../components/dashboard/QuickActions"));
const ReportsCard = lazy(() => import("../components/dashboard/ReportsCard"));

const DashboardSuspenseLoader = () => (
  <div className="w-full min-h-[50vh] flex items-center justify-center bg-slate-50 rounded-lg">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
  </div>
);

export default function Dashboard() {
  const [stats, setStats] = useState({
    totalClientes: 0,
    totalProdutos: 0,
    valorEstoque: 0,
    orcamentosPendentes: 0,
    ordemServico: 0,
    receitasMes: 0,
    despesasMes: 0,
    receitasMesAnterior: 0,
    ticketMedio: 0,
    taxaConversao: 0,
    clientesNovos: 0,
    metaMensal: 50000,
    progressoMeta: 0
  });
  
  const [recentOrders, setRecentOrders] = useState([]);
  const [lowStock, setLowStock] = useState([]);
  const [pendingFinancials, setPendingFinancials] = useState([]);
  const [salesData, setSalesData] = useState([]);
  const [topProductsData, setTopProductsData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setIsLoading(true);
      
      const hoje = new Date();
      const inicioMesAtual = startOfMonth(hoje);
      const fimMesAtual = endOfMonth(hoje);
      const inicioMesAnterior = startOfMonth(subMonths(hoje, 1));
      const fimMesAnterior = endOfMonth(subMonths(hoje, 1));
      const seteDiasAtras = subDays(hoje, 6);

      const [
        clientes, 
        produtos, 
        orcamentosMesAtual,
        allOrdens, 
        financeiroMesAtual,
        financeiroMesAnterior,
        recentOrdersData,
        pendingFinancialsData,
        financeiroUltimos7Dias
      ] = await Promise.all([
        Cliente.list(),
        Produto.list(),
        Orcamento.filter({ data_orcamento: { $gte: inicioMesAtual.toISOString(), $lte: fimMesAtual.toISOString() }}),
        OrdemServico.list(),
        Financeiro.filter({ data_vencimento: { $gte: inicioMesAtual.toISOString(), $lte: fimMesAtual.toISOString() }}),
        Financeiro.filter({ data_vencimento: { $gte: inicioMesAnterior.toISOString(), $lte: fimMesAnterior.toISOString() }}),
        OrdemServico.list("-created_date", 5),
        Financeiro.filter({ status: 'pendente' }, "-data_vencimento", 5),
        Financeiro.filter({ data_vencimento: { $gte: seteDiasAtras.toISOString(), $lte: hoje.toISOString() }})
      ]);
      
      setRecentOrders(recentOrdersData);
      setPendingFinancials(pendingFinancialsData);
      setLowStock(produtos.filter(p => p.estoque_atual <= p.estoque_minimo).slice(0, 5));

      const receitasMesAtual = financeiroMesAtual.filter(f => f.tipo === 'receita').reduce((sum, f) => sum + f.valor, 0);
      const despesasMesAtual = financeiroMesAtual.filter(f => f.tipo === 'despesa').reduce((sum, f) => sum + f.valor, 0);
      const receitasMesAnterior = financeiroMesAnterior.filter(f => f.tipo === 'receita').reduce((sum, f) => sum + f.valor, 0);

      const produtosAtivos = produtos.filter(p => p.ativo !== false);
      const valorEstoque = produtosAtivos.reduce((sum, p) => (sum + (p.preco_custo || 0) * (p.estoque_atual || 0)), 0);

      const orcamentosAprovados = orcamentosMesAtual.filter(o => o.status === 'aprovado');
      const taxaConversao = orcamentosMesAtual.length > 0 ? (orcamentosAprovados.length / orcamentosMesAtual.length) * 100 : 0;
      const ticketMedio = orcamentosAprovados.length > 0 ? orcamentosAprovados.reduce((sum, o) => sum + o.total, 0) / orcamentosAprovados.length : 0;
      const clientesNovos = clientes.filter(c => new Date(c.created_date) >= inicioMesAtual && new Date(c.created_date) <= fimMesAtual).length;
      
      const metaMensal = 50000;
      const progressoMeta = (receitasMesAtual / metaMensal) * 100;

      const allOrcamentos = await Orcamento.list();

      setStats({
        totalClientes: clientes.length,
        totalProdutos: produtosAtivos.length,
        valorEstoque,
        orcamentosPendentes: allOrcamentos.filter(o => o.status === 'enviado').length,
        ordemServico: allOrdens.filter(o => o.status !== 'concluida' && o.status !== 'cancelada').length,
        receitasMes: receitasMesAtual,
        despesasMes: despesasMesAtual,
        receitasMesAnterior,
        ticketMedio,
        taxaConversao,
        clientesNovos,
        metaMensal,
        progressoMeta
      });

      const salesChartData = [];
      for (let i = 6; i >= 0; i--) {
        const date = subDays(hoje, i);
        const dayRevenue = financeiroUltimos7Dias
          .filter(f => f.tipo === 'receita' && new Date(f.data_vencimento).toDateString() === date.toDateString())
          .reduce((sum, f) => sum + f.valor, 0);
        salesChartData.push({ date: format(date, 'dd/MM', { locale: ptBR }), value: dayRevenue });
      }
      setSalesData(salesChartData);

      const topProducts = produtosAtivos
        .sort((a, b) => (b.estoque_atual || 0) - (a.estoque_atual || 0))
        .slice(0, 5)
        .map(p => ({ ...p, vendas: Math.floor(Math.random() * 50) + 10 }));
      setTopProductsData(topProducts);
      
    } catch (error) {
      console.error('Erro ao carregar dados do dashboard:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const formatCurrency = (value) => {
    return (value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  const getTrendPercentage = () => {
    if (stats.receitasMesAnterior === 0) {
      return stats.receitasMes > 0 ? "+100% vs mês anterior" : "+0% vs mês anterior";
    }
    const percentage = ((stats.receitasMes - stats.receitasMesAnterior) / stats.receitasMesAnterior) * 100;
    return `${percentage >= 0 ? '+' : ''}${percentage.toFixed(1)}% vs mês anterior`;
  };

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-slate-100 min-h-screen">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Dashboard</h1>
          <p className="text-slate-600 mt-1">
            Bem-vindo ao Vetra - {format(new Date(), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <BarChart3 className="w-4 h-4 mr-2" />
            Relatórios
          </Button>
          <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
            <Zap className="w-4 h-4 mr-2" />
            Ações Rápidas
          </Button>
        </div>
      </div>

      <Suspense fallback={<DashboardSuspenseLoader />}>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            title="Meta do Mês"
            value={`${stats.progressoMeta.toFixed(0)}%`}
            icon={Target}
            color="blue"
            trend={`${formatCurrency(stats.receitasMes)} de ${formatCurrency(stats.metaMensal)}`}
            isLoading={isLoading}
            progress={stats.progressoMeta}
          />
          <StatCard
            title="Receita do Mês"
            value={formatCurrency(stats.receitasMes)}
            icon={DollarSign}
            color="green"
            trend={getTrendPercentage()}
            isLoading={isLoading}
          />
          <StatCard
            title="Ticket Médio"
            value={formatCurrency(stats.ticketMedio)}
            icon={Award}
            color="purple"
            trend={`${stats.taxaConversao.toFixed(1)}% taxa de conversão`}
            isLoading={isLoading}
          />
          <StatCard
            title="Clientes Novos"
            value={stats.clientesNovos}
            icon={Users}
            color="blue"
            trend={`${stats.totalClientes} total cadastrados`}
            isLoading={isLoading}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            title="Produtos em Estoque"
            value={stats.totalProdutos}
            icon={Package}
            color="green"
            trend={`${formatCurrency(stats.valorEstoque)} investido`}
            isLoading={isLoading}
          />
          <StatCard
            title="Orçamentos Pendentes"
            value={stats.orcamentosPendentes}
            icon={FileText}
            color="yellow"
            trend="Aguardando resposta"
            isLoading={isLoading}
          />
          <StatCard
            title="OS em Andamento"
            value={stats.ordemServico}
            icon={Clock}
            color="orange"
            trend="3 para hoje" // This is still hardcoded, ideally derived from data
            isLoading={isLoading}
          />
          <StatCard
            title="Saldo do Mês"
            value={formatCurrency(stats.receitasMes - stats.despesasMes)}
            icon={stats.receitasMes - stats.despesasMes >= 0 ? TrendingUp : TrendingDown}
            color={stats.receitasMes - stats.despesasMes >= 0 ? "green" : "red"}
            trend={`${stats.receitasMes > 0 ? ((stats.receitasMes - stats.despesasMes) / stats.receitasMes * 100).toFixed(1) : '0.0'}% margem`}
            isLoading={isLoading}
          />
        </div>

        <div className="grid grid-cols-1 gap-6">
          <SalesChart data={salesData} isLoading={isLoading} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <FinancialOverview 
            receitas={stats.receitasMes}
            despesas={stats.despesasMes}
            isLoading={isLoading}
          />
          <PendingTasks 
            lowStock={lowStock}
            pendingFinancials={pendingFinancials}
            isLoading={isLoading}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <RecentActivity 
            recentOrders={recentOrders}
            isLoading={isLoading}
          />
          <TopProducts 
            products={topProductsData}
            isLoading={isLoading}
          />
        </div>

        {/* Ações Rápidas e Relatórios */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <QuickActions />
          <ReportsCard stats={stats} isLoading={isLoading} />
        </div>

        <Card className="bg-white shadow-sm border-slate-200">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-slate-900">
              <AlertTriangle className="w-5 h-5 text-amber-500" />
              Alertas e Notificações
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {lowStock.length > 0 && (
                <div className="p-3 bg-amber-50 rounded-lg border border-amber-200">
                  <p className="text-sm text-amber-700">
                    {lowStock.length} produtos com estoque abaixo do mínimo.
                  </p>
                </div>
              )}
              {stats.orcamentosPendentes > 0 && (
                <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-700">
                    {stats.orcamentosPendentes} orçamentos aguardando resposta.
                  </p>
                </div>
              )}
              {pendingFinancials.length > 0 && (
                 <div className="p-3 bg-red-50 rounded-lg border border-red-200">
                   <p className="text-sm text-red-700">
                     {pendingFinancials.length} contas a receber em atraso.
                   </p>
                 </div>
              )}
              {stats.progressoMeta >= 100 && (
                <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                  <p className="text-sm text-green-700">
                    Parabéns! Meta do mês superada!
                  </p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </Suspense>
    </div>
  );
}