
import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Printer, User, Phone, Mail, MapPin, Calendar, FileText, DollarSign, Wrench } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Cliente } from "@/api/entities";
import { Orcamento } from "@/api/entities";
import { OrdemServico } from "@/api/entities";
import { LancamentoFinanceiro } from "@/api/entities";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function ClienteDetalhes() {
  const location = useLocation();
  const [cliente, setCliente] = useState(null);
  const [orcamentos, setOrcamentos] = useState([]);
  const [ordensServico, setOrdensServico] = useState([]);
  const [lancamentosFinanceiros, setLancamentosFinanceiros] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const clienteId = new URLSearchParams(location.search).get('id');
    if (clienteId) {
      loadClienteData(clienteId);
    }
  }, [location]);

  const loadClienteData = async (clienteId) => {
    try {
      setLoading(true);
      
      // Carregar dados do cliente
      const clienteData = await Cliente.list();
      const clienteEncontrado = clienteData.find(c => c.id === clienteId);
      setCliente(clienteEncontrado);

      if (clienteEncontrado) {
        // Carregar orçamentos do cliente
        const orcamentosData = await Orcamento.filter({ cliente_id: clienteId });
        setOrcamentos(orcamentosData || []);

        // Carregar ordens de serviço do cliente
        const ordensData = await OrdemServico.filter({ cliente_id: clienteId });
        setOrdensServico(ordensData || []);

        // Carregar lançamentos financeiros do cliente - buscar por nome e ID
        const financeirosData = await LancamentoFinanceiro.list();
        const financeirosCliente = financeirosData.filter(f => 
          f.cliente_fornecedor === clienteEncontrado.nome || 
          f.cliente_id === clienteId ||
          f.cliente_fornecedor?.toLowerCase().includes(clienteEncontrado.nome.toLowerCase())
        );
        setLancamentosFinanceiros(financeirosCliente || []);
      }
    } catch (error) {
      console.error("Erro ao carregar dados do cliente:", error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value) => {
    return (value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    try {
      return format(new Date(dateString), "dd/MM/yyyy", { locale: ptBR });
    } catch {
      return 'N/A';
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const getStatusBadge = (status, tipo = 'default') => {
    const statusConfig = {
      orcamento: {
        em_elaboracao: { color: 'bg-yellow-100 text-yellow-800', label: 'Em Elaboração' },
        enviado: { color: 'bg-blue-100 text-blue-800', label: 'Enviado' },
        aprovado: { color: 'bg-green-100 text-green-800', label: 'Aprovado' },
        rejeitado: { color: 'bg-red-100 text-red-800', label: 'Rejeitado' },
        vencido: { color: 'bg-gray-100 text-gray-800', label: 'Vencido' }
      },
      ordem: {
        agendado: { color: 'bg-blue-100 text-blue-800', label: 'Agendado' },
        em_andamento: { color: 'bg-yellow-100 text-yellow-800', label: 'Em Andamento' },
        concluido: { color: 'bg-green-100 text-green-800', label: 'Concluído' },
        cancelado: { color: 'bg-red-100 text-red-800', label: 'Cancelado' }
      },
      financeiro: {
        pendente: { color: 'bg-yellow-100 text-yellow-800', label: 'Pendente' },
        pago: { color: 'bg-green-100 text-green-800', label: 'Pago' },
        atrasado: { color: 'bg-red-100 text-red-800', label: 'Atrasado' },
        cancelado: { color: 'bg-gray-100 text-gray-800', label: 'Cancelado' }
      }
    };

    const config = statusConfig[tipo]?.[status] || { color: 'bg-gray-100 text-gray-800', label: status };
    return <Badge className={config.color}>{config.label}</Badge>;
  };

  if (loading) {
    return (
      <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50/50 via-blue-50/20 to-indigo-50/20 min-h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
      </div>
    );
  }

  if (!cliente) {
    return (
      <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50/50 via-blue-50/20 to-indigo-50/20 min-h-full">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-slate-900 mb-4">Cliente não encontrado</h1>
          <Link to={createPageUrl("Clientes")}>
            <Button variant="outline">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar para Clientes
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const totalOrcamentos = orcamentos.reduce((sum, orc) => sum + (orc.valor_final || orc.valor_total || 0), 0);
  const orcamentosAprovados = orcamentos.filter(orc => orc.status === 'aprovado');
  const totalVendas = orcamentosAprovados.reduce((sum, orc) => sum + (orc.valor_final || orc.valor_total || 0), 0);

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50/50 via-blue-50/20 to-indigo-50/20 min-h-full print:bg-white print:p-4">
      {/* Header - Oculto na impressão */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6 print:hidden">
        <div className="flex items-center gap-4">
          <Link to={createPageUrl("Clientes")}>
            <Button variant="outline" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Histórico do Cliente</h1>
            <p className="text-slate-600">Informações completas e histórico de relacionamento</p>
          </div>
        </div>
        <Button onClick={handlePrint} className="bg-blue-600 hover:bg-blue-700">
          <Printer className="w-4 h-4 mr-2" />
          Imprimir Relatório
        </Button>
      </div>

      {/* Cabeçalho para impressão */}
      <div className="hidden print:block mb-6">
        <div className="text-center border-b pb-4 mb-6">
          <h1 className="text-2xl font-bold">RELATÓRIO COMPLETO DO CLIENTE</h1>
          <p className="text-sm text-gray-600 mt-2">
            Gerado em {format(new Date(), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
          </p>
        </div>
      </div>

      {/* Informações do Cliente */}
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg print:shadow-none print:border print:border-gray-300">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2">
            <User className="w-5 h-5 text-blue-600" />
            Dados do Cliente
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-slate-700 mb-2">Informações Básicas</h3>
                <div className="space-y-2">
                  <p><span className="font-medium">Nome:</span> {cliente.nome}</p>
                  <p><span className="font-medium">Tipo:</span> {cliente.tipo === 'pessoa_fisica' ? 'Pessoa Física' : 'Pessoa Jurídica'}</p>
                  {cliente.documento && <p><span className="font-medium">Documento:</span> {cliente.documento}</p>}
                  <p><span className="font-medium">Status:</span> 
                    <Badge className={`ml-2 ${cliente.ativo !== false ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                      {cliente.ativo !== false ? 'Ativo' : 'Inativo'}
                    </Badge>
                  </p>
                  <p><span className="font-medium">Cadastrado em:</span> {formatDate(cliente.created_date)}</p>
                </div>
              </div>

              <div>
                <h3 className="font-semibold text-slate-700 mb-2 flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  Contato
                </h3>
                <div className="space-y-2">
                  {cliente.telefone && <p><span className="font-medium">Telefone:</span> {cliente.telefone}</p>}
                  {cliente.telefone_secundario && <p><span className="font-medium">Telefone 2:</span> {cliente.telefone_secundario}</p>}
                  {cliente.email && <p><span className="font-medium">Email:</span> {cliente.email}</p>}
                </div>
              </div>
            </div>

            <div className="space-y-4">
              {cliente.endereco && Object.values(cliente.endereco).some(v => v) && (
                <div>
                  <h3 className="font-semibold text-slate-700 mb-2 flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    Endereço
                  </h3>
                  <div className="space-y-1">
                    {cliente.endereco.logradouro && (
                      <p>{cliente.endereco.logradouro}{cliente.endereco.numero && `, ${cliente.endereco.numero}`}</p>
                    )}
                    {cliente.endereco.complemento && <p>{cliente.endereco.complemento}</p>}
                    {cliente.endereco.bairro && <p>{cliente.endereco.bairro}</p>}
                    {cliente.endereco.cidade && cliente.endereco.uf && (
                      <p>{cliente.endereco.cidade} - {cliente.endereco.uf}</p>
                    )}
                    {cliente.endereco.cep && <p>CEP: {cliente.endereco.cep}</p>}
                  </div>
                </div>
              )}

              {cliente.observacoes && (
                <div>
                  <h3 className="font-semibold text-slate-700 mb-2">Observações</h3>
                  <p className="text-sm text-slate-600 bg-slate-50 p-3 rounded-lg">{cliente.observacoes}</p>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Resumo Financeiro */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg print:shadow-none print:border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Total Orçamentos</p>
                <p className="text-2xl font-bold text-blue-600">{orcamentos.length}</p>
              </div>
              <FileText className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg print:shadow-none print:border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Valor Total Orçado</p>
                <p className="text-2xl font-bold text-orange-600">{formatCurrency(totalOrcamentos)}</p>
              </div>
              <DollarSign className="w-8 h-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg print:shadow-none print:border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Vendas Realizadas</p>
                <p className="text-2xl font-bold text-green-600">{formatCurrency(totalVendas)}</p>
              </div>
              <DollarSign className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg print:shadow-none print:border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Ordens de Serviço</p>
                <p className="text-2xl font-bold text-purple-600">{ordensServico.length}</p>
              </div>
              <Wrench className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Histórico de Orçamentos */}
      {orcamentos.length > 0 && (
        <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg print:shadow-none print:border print:break-after-page">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-600" />
              Histórico de Orçamentos ({orcamentos.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-200">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Número</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Data</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Vendedor</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Valor</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Status</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Validade</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-200">
                  {orcamentos.map((orcamento) => (
                    <tr key={orcamento.id} className="hover:bg-slate-50">
                      <td className="px-4 py-3 text-sm text-slate-900">{orcamento.numero || orcamento.id}</td>
                      <td className="px-4 py-3 text-sm text-slate-600">{formatDate(orcamento.data_orcamento)}</td>
                      <td className="px-4 py-3 text-sm text-slate-600">{orcamento.vendedor}</td>
                      <td className="px-4 py-3 text-sm font-medium text-slate-900">
                        {formatCurrency(orcamento.valor_final || orcamento.valor_total)}
                      </td>
                      <td className="px-4 py-3 text-sm">{getStatusBadge(orcamento.status, 'orcamento')}</td>
                      <td className="px-4 py-3 text-sm text-slate-600">{formatDate(orcamento.data_validade)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Histórico de Ordens de Serviço */}
      {ordensServico.length > 0 && (
        <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg print:shadow-none print:border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Wrench className="w-5 h-5 text-purple-600" />
              Histórico de Ordens de Serviço ({ordensServico.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-200">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Número</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Tipo Serviço</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Data Agendada</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Técnico</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Status</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Prioridade</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-200">
                  {ordensServico.map((ordem) => (
                    <tr key={ordem.id} className="hover:bg-slate-50">
                      <td className="px-4 py-3 text-sm text-slate-900">{ordem.numero}</td>
                      <td className="px-4 py-3 text-sm text-slate-600 capitalize">{ordem.tipo_servico?.replace('_', ' ')}</td>
                      <td className="px-4 py-3 text-sm text-slate-600">{formatDate(ordem.data_agendada)}</td>
                      <td className="px-4 py-3 text-sm text-slate-600">{ordem.tecnico_responsavel}</td>
                      <td className="px-4 py-3 text-sm">{getStatusBadge(ordem.status, 'ordem')}</td>
                      <td className="px-4 py-3 text-sm">
                        <Badge className={`${
                          ordem.prioridade === 'urgente' ? 'bg-red-100 text-red-800' :
                          ordem.prioridade === 'alta' ? 'bg-orange-100 text-orange-800' :
                          ordem.prioridade === 'media' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-blue-100 text-blue-800'
                        }`}>
                          {ordem.prioridade}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Histórico Financeiro */}
      {lancamentosFinanceiros.length > 0 && (
        <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg print:shadow-none print:border print:break-inside-avoid">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-green-600" />
              Histórico Financeiro ({lancamentosFinanceiros.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-200">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Descrição</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Tipo</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Valor</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Vencimento</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Status</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Data Pagamento</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-200">
                  {lancamentosFinanceiros.map((lancamento) => (
                    <tr key={lancamento.id} className="hover:bg-slate-50">
                      <td className="px-4 py-3 text-sm text-slate-900">{lancamento.descricao}</td>
                      <td className="px-4 py-3 text-sm">
                        <Badge className={lancamento.tipo === 'receita' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                          {lancamento.tipo === 'receita' ? 'Receita' : 'Despesa'}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 text-sm font-medium text-slate-900">
                        {formatCurrency(lancamento.valor)}
                      </td>
                      <td className="px-4 py-3 text-sm text-slate-600">{formatDate(lancamento.data_vencimento)}</td>
                      <td className="px-4 py-3 text-sm">{getStatusBadge(lancamento.status, 'financeiro')}</td>
                      <td className="px-4 py-3 text-sm text-slate-600">{formatDate(lancamento.data_pagamento)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Mensagem quando não há histórico */}
      {orcamentos.length === 0 && ordensServico.length === 0 && lancamentosFinanceiros.length === 0 && (
        <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
          <CardContent className="p-12">
            <div className="text-center text-slate-500">
              <Calendar className="w-16 h-16 mx-auto mb-4 text-slate-300" />
              <h3 className="text-lg font-medium mb-2">Nenhum histórico encontrado</h3>
              <p>Este cliente ainda não possui orçamentos, ordens de serviço ou movimentações financeiras registradas.</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Rodapé para impressão */}
      <div className="hidden print:block mt-8 pt-4 border-t text-center text-sm text-gray-600">
        <p>Relatório gerado pelo Sistema VidraçariaOS - {format(new Date(), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}</p>
      </div>
    </div>
  );
}
