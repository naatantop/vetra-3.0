import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Printer, Scissors, FileText, MapPin, Calendar, User, Package } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Orcamento } from "@/api/entities";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function ProducaoDetalhes() {
  const location = useLocation();
  const [ordem, setOrdem] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const ordemId = new URLSearchParams(location.search).get('id');
    if (ordemId) {
      loadOrdemData(ordemId);
    }
  }, [location]);

  const loadOrdemData = async (ordemId) => {
    try {
      setLoading(true);
      const orcamentoData = await Orcamento.list();
      const ordemEncontrada = orcamentoData.find(o => o.id === ordemId);
      setOrdem(ordemEncontrada);
    } catch (error) {
      console.error("Erro ao carregar ordem de produção:", error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return format(new Date(dateString), "dd/MM/yyyy", { locale: ptBR });
  };
  
  const getStatusVendaLabel = (status) => {
    const labels = {
      aguardando_producao: 'Aguardando Produção',
      em_producao: 'Em Produção',
      aguardando_entrega: 'Aguardando Entrega',
      concluida: 'Concluída'
    };
    return labels[status] || status;
  };
  
  const getStatusColor = (status) => {
    const statusConfig = {
      aguardando_producao: 'bg-yellow-100 text-yellow-800',
      em_producao: 'bg-blue-100 text-blue-800',
      aguardando_entrega: 'bg-purple-100 text-purple-800',
      concluida: 'bg-green-100 text-green-800',
    };
    return statusConfig[status] || 'bg-gray-100 text-gray-800';
  };

  const handlePrint = () => {
    window.print();
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
      </div>
    );
  }

  if (!ordem) {
    return (
      <div className="p-6 text-center">
        <h1 className="text-2xl font-bold text-slate-900 mb-4">Ordem de Produção não encontrada</h1>
        <Link to={createPageUrl("Producao")}>
          <Button variant="outline"><ArrowLeft className="w-4 h-4 mr-2" />Voltar para Produção</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 bg-slate-50 min-h-screen">
       <style jsx global>{`
        @media print {
          .no-print { display: none !important; }
          body { -webkit-print-color-adjust: exact; background-color: white !important; }
          .print-container { padding: 0 !important; }
          .print-card { box-shadow: none !important; border: 1px solid #e2e8f0 !important; }
        }
      `}</style>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 no-print">
        <div className="flex items-center gap-4">
          <Link to={createPageUrl("Producao")}>
            <Button variant="outline" size="sm"><ArrowLeft className="w-4 h-4 mr-2" />Voltar</Button>
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">
              Ordem de Produção #{ordem.numero || `OP-${ordem.id?.slice(-6)}`}
            </h1>
            <Badge className={`${getStatusColor(ordem.status_venda)} border mt-1`}>
                {getStatusVendaLabel(ordem.status_venda)}
            </Badge>
          </div>
        </div>
        <div className="flex gap-2 no-print">
           <Button onClick={handlePrint} variant="outline"><Printer className="w-4 h-4 mr-2" />Imprimir Ordem</Button>
           <Link to={`${createPageUrl("OrcamentoDetalhes")}?id=${ordem.id}`} target="_blank">
              <Button className="bg-blue-600 hover:bg-blue-700"><FileText className="w-4 h-4 mr-2" />Ver Orçamento Original</Button>
            </Link>
        </div>
      </div>
      
      {/* Container for printing */}
      <div className="print-container">
        {/* Informações Básicas */}
        <Card className="print-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-xl">
              <Scissors className="w-6 h-6 text-blue-600" />
              Detalhes da Ordem de Produção
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5 text-slate-500" />
                <div>
                  <span className="font-semibold text-slate-700 block">Número da Ordem:</span>
                  <span>{ordem.numero || `OP-${ordem.id?.slice(-6)}`}</span>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <User className="w-5 h-5 text-slate-500" />
                <div>
                  <span className="font-semibold text-slate-700 block">Cliente:</span>
                  <span>{ordem.cliente_nome}</span>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Calendar className="w-5 h-5 text-slate-500" />
                <div>
                  <span className="font-semibold text-slate-700 block">Prazo de Entrega:</span>
                  <span className="text-red-600 font-medium">{ordem.prazo_entrega || 'N/A'}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Itens do Orçamento */}
        {ordem.itens && ordem.itens.length > 0 && (
          <Card className="print-card mt-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="w-5 h-5 text-blue-600" />
                Itens para Produção
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-slate-200">
                  <thead className="bg-slate-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Produto</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Medidas</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Quantidade</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Observações</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-slate-200">
                    {ordem.itens.map((item, index) => (
                      <tr key={index}>
                        <td className="px-4 py-3 text-sm text-slate-900 font-medium">{item.produto_nome}</td>
                        <td className="px-4 py-3 text-sm text-slate-600">
                          {(() => {
                            const tipoMedida = item.tipo_medida;
                            if (tipoMedida === 'm2' && item.largura_mm && item.altura_mm) {
                              return <span>{item.largura_mm}mm × {item.altura_mm}mm</span>;
                            } else if ((tipoMedida === 'metro_linear' || tipoMedida === 'metro') && item.comprimento_mm) {
                              return <span>{item.comprimento_mm}mm</span>;
                            } else {
                              return <span>Unitário</span>;
                            }
                          })()}
                        </td>
                        <td className="px-4 py-3 text-sm text-slate-600 font-bold">{item.quantidade} {item.tipo_medida === 'm2' ? 'm²' : item.tipo_medida === 'metro_linear' ? 'ml' : 'un'}</td>
                        <td className="px-4 py-3 text-sm text-slate-600">{item.observacoes || '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            {/* Endereço de Instalação */}
            {ordem.endereco_instalacao && Object.values(ordem.endereco_instalacao).some(v => v) && (
                <Card className="print-card">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><MapPin className="w-5 h-5 text-blue-600" />Endereço de Instalação</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-1 text-sm">
                    {ordem.endereco_instalacao.logradouro && <p>{ordem.endereco_instalacao.logradouro}{ordem.endereco_instalacao.numero && `, ${ordem.endereco_instalacao.numero}`}</p>}
                    {ordem.endereco_instalacao.complemento && <p>{ordem.endereco_instalacao.complemento}</p>}
                    {ordem.endereco_instalacao.bairro && <p>{ordem.endereco_instalacao.bairro}</p>}
                    {ordem.endereco_instalacao.cidade && ordem.endereco_instalacao.uf && <p>{ordem.endereco_instalacao.cidade} - {ordem.endereco_instalacao.uf}</p>}
                    {ordem.endereco_instalacao.cep && <p>CEP: {ordem.endereco_instalacao.cep}</p>}
                    </div>
                </CardContent>
                </Card>
            )}

            {/* Observações Gerais */}
            {ordem.observacoes_gerais && (
                <Card className="print-card">
                <CardHeader>
                    <CardTitle>Observações Gerais</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-sm text-slate-700 whitespace-pre-line">{ordem.observacoes_gerais}</p>
                </CardContent>
                </Card>
            )}
        </div>
      </div>
    </div>
  );
}