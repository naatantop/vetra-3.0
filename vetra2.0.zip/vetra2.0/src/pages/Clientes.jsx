
import React, { useState, useEffect } from "react";
import { Cliente } from "@/api/entities";
import { User } from "@/api/entities";
import { Plus, Users, Trash2, Search, Filter, AlertTriangle, UserCheck, UserPlus } from "lucide-react";
import { Input } from "@/components/ui/input";
import Button from "../components/ui/Button";
import Modal from "../components/ui/Modal";
import ClienteForm from '../components/clientes/ClienteForm';
import TabelaClientes from '../components/clientes/TabelaClientes';
import { Alert, AlertDescription } from "@/components/ui/alert";
import StatCard from '../components/dashboard/StatCard';

export default function Clientes() {
  const [clientes, setClientes] = useState([]);
  const [filteredClientes, setFilteredClientes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFiltro, setStatusFiltro] = useState('todos');
  const [showModal, setShowModal] = useState(false);
  const [editingCliente, setEditingCliente] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [isDeletingAll, setIsDeletingAll] = useState(false);
  const [message, setMessage] = useState({ type: "", text: "" });
  const [currentUser, setCurrentUser] = useState(null);
  const [hasCreatePermission, setHasCreatePermission] = useState(false);
  const [hasDeletePermission, setHasDeletePermission] = useState(false);

  useEffect(() => {
    loadInitialData();
  }, []);

  useEffect(() => {
    let filtered = clientes;
    
    if (statusFiltro !== 'todos') {
      if (statusFiltro === 'ativo') {
        filtered = filtered.filter(c => c.ativo !== false);
      } else if (statusFiltro === 'inativo') {
        filtered = filtered.filter(c => c.ativo === false);
      }
    }
    
    if (searchTerm) {
      const lowerCaseSearchTerm = searchTerm.toLowerCase();
      filtered = filtered.filter(c => 
        c.nome.toLowerCase().includes(lowerCaseSearchTerm) ||
        (c.documento && c.documento.includes(lowerCaseSearchTerm))
      );
    }
    setFilteredClientes(filtered);
  }, [clientes, searchTerm, statusFiltro]);

  const loadInitialData = async () => {
    try {
      setLoading(true);
      const [user, data] = await Promise.all([
        User.me(),
        Cliente.list('-created_date')
      ]);
      setCurrentUser(user);
      setHasCreatePermission(user?.role === 'admin' || user?.permissions?.includes('clientes_create'));
      setHasDeletePermission(user?.role === 'admin' || user?.permissions?.includes('clientes_delete'));
      setClientes(data);
      setMessage({ type: "", text: "" });
    } catch (error) {
      console.error("Erro ao carregar dados iniciais:", error);
      setMessage({ type: "error", text: "Erro ao carregar clientes." });
    } finally {
      setLoading(false);
    }
  };

  const loadClientes = async () => {
    try {
      setLoading(true);
      const data = await Cliente.list('-created_date');
      setClientes(data);
      setMessage({ type: "", text: "" });
    } catch (error) {
      console.error("Erro ao carregar clientes:", error);
      setMessage({ type: "error", text: "Erro ao carregar clientes." });
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = () => {
    setEditingCliente(null);
    setShowModal(true);
    setMessage({ type: "", text: "" });
  };

  const handleEdit = (cliente) => {
    setEditingCliente(cliente);
    setShowModal(true);
    setMessage({ type: "", text: "" });
  };

  const handleDelete = async (cliente) => {
    if (window.confirm(`Tem certeza que deseja excluir o cliente "${cliente.nome}"?`)) {
      try {
        await Cliente.delete(cliente.id);
        setMessage({ type: "success", text: `Cliente "${cliente.nome}" excluído com sucesso.` });
        loadClientes();
      } catch (error) {
        console.error('Erro ao excluir cliente:', error);
        setMessage({ type: "error", text: 'Erro ao excluir cliente. Tente novamente.' });
      }
    }
  };

  const handleDeleteAll = async () => {
    if (window.confirm(`Tem certeza que deseja excluir TODOS os ${clientes.length} clientes? Esta ação é irreversível!`)) {
      setIsDeletingAll(true);
      setMessage({ type: "", text: "" });
      try {
        for (const cliente of clientes) {
          await Cliente.delete(cliente.id);
        }
        setMessage({ type: "success", text: `${clientes.length} clientes foram excluídos com sucesso.` });
        loadClientes();
      } catch (error) {
        console.error('Erro ao excluir todos os clientes:', error);
        setMessage({ type: "error", text: 'Erro ao excluir todos os clientes. Tente novamente.' });
      } finally {
        setIsDeletingAll(false);
      }
    }
  };

  const handleToggleStatus = async (cliente) => {
    try {
      const novoStatus = !cliente.ativo;
      await Cliente.update(cliente.id, { ...cliente, ativo: novoStatus });
      setMessage({ type: "success", text: `Status do cliente "${cliente.nome}" alterado.` });
      loadClientes();
    } catch (error) {
      console.error('Erro ao alterar status do cliente:', error);
      setMessage({ type: "error", text: 'Erro ao alterar status do cliente. Tente novamente.' });
    }
  };

  const handleSubmit = async (formData) => {
    setSubmitting(true);
    setMessage({ type: "", text: "" });
    try {
      if (editingCliente) {
        await Cliente.update(editingCliente.id, formData);
        setMessage({ type: "success", text: "Cliente atualizado com sucesso." });
      } else {
        await Cliente.create(formData);
        setMessage({ type: "success", text: "Cliente criado com sucesso." });
      }
      setShowModal(false);
      loadClientes();
    } catch (error) {
      console.error('Erro ao salvar cliente:', error);
      setMessage({ type: "error", text: 'Erro ao salvar cliente. Verifique os campos e tente novamente.' });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50/50 via-blue-50/20 to-indigo-50/20 min-h-full">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Gestão de Clientes</h1>
          <p className="text-slate-600">Gerencie o cadastro de clientes</p>
        </div>
        <div className="flex gap-2">
          {clientes.length > 0 && hasDeletePermission && (
            <Button variant="outline" onClick={handleDeleteAll} loading={isDeletingAll} disabled={isDeletingAll} icon={<Trash2 size={16} />} className="border-red-300 text-red-700 hover:bg-red-50 focus:ring-red-500">
              {isDeletingAll ? 'Apagando...' : 'Apagar Todos'}
            </Button>
          )}
          {hasCreatePermission && (
            <Button onClick={handleCreate} icon={<Plus size={16} />}>
              Novo Cliente
            </Button>
          )}
        </div>
      </div>

      {message.text && (
        <Alert variant={message.type === "error" ? "destructive" : "default"} className="mb-6">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{message.text}</AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <StatCard title="Total de Clientes" value={clientes.length} icon={Users} color="blue" isLoading={loading} />
        <StatCard title="Clientes Ativos" value={clientes.filter(c => c.ativo !== false).length} icon={UserCheck} color="green" isLoading={loading} />
        <StatCard title="Clientes Inativos" value={clientes.filter(c => c.ativo === false).length} icon={UserPlus} color="red" isLoading={loading} />
      </div>

      <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm flex flex-col sm:flex-row gap-4 mb-6">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
          <Input placeholder="Buscar por nome ou documento..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-10" />
        </div>
        <div className="flex-1 relative">
          <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
          <select value={statusFiltro} onChange={(e) => setStatusFiltro(e.target.value)} className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white">
            <option value="todos">Todos os Status</option>
            <option value="ativo">Apenas Ativos</option>
            <option value="inativo">Apenas Inativos</option>
          </select>
        </div>
      </div>

      <TabelaClientes
        clientes={filteredClientes}
        onEditar={handleEdit}
        onExcluir={handleDelete}
        onToggleAtivo={handleToggleStatus}
        loading={loading}
        currentUser={currentUser}
      />

      {showModal && (
        <Modal isOpen={showModal} onClose={() => setShowModal(false)} title={editingCliente ? 'Editar Cliente' : 'Novo Cliente'} size="large">
          <ClienteForm clienteInicial={editingCliente} onSubmit={handleSubmit} onCancel={() => setShowModal(false)} loading={submitting} />
        </Modal>
      )}
    </div>
  );
}
