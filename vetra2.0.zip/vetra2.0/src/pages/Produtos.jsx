
import React, { useState, useEffect } from 'react';
import { Produto } from "@/api/entities";
import { User } from "@/api/entities";
import { Plus, Search, Edit, Trash2, Filter, Power, PowerOff, AlertTriangle, Download } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import Button from "../components/ui/Button";
import Modal from "../components/ui/Modal";
import ProdutoForm from '../components/produtos/ProdutoForm';
import TabelaProdutos from '../components/produtos/TabelaProdutos';
import { Alert, AlertDescription } from "@/components/ui/alert";
import { getAllCategorias } from '../components/utils/CategoriaUtils';

export default function Produtos() {
  const [produtos, setProdutos] = useState([]);
  const [filteredProdutos, setFilteredProdutos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoriaFiltro, setCategoriaFiltro] = useState('todos');
  const [statusFiltro, setStatusFiltro] = useState('todos');
  const [showModal, setShowModal] = useState(false);
  const [editingProduto, setEditingProduto] = useState(null);
  const [isDeletingAll, setIsDeletingAll] = useState(false);
  const [message, setMessage] = useState({ type: "", text: "" });
  const [currentUser, setCurrentUser] = useState(null);

  // Usar categorias dinâmicas
  const categorias = getAllCategorias();

  useEffect(() => {
    loadProdutos();
    loadCurrentUser();
  }, []);

  useEffect(() => {
    let filtered = produtos;
    
    if (categoriaFiltro !== 'todos') {
      filtered = filtered.filter(p => p.categoria === categoriaFiltro);
    }

    if (statusFiltro !== 'todos') {
      if (statusFiltro === 'ativo') {
        filtered = filtered.filter(p => p.ativo !== false);
      } else if (statusFiltro === 'inativo') {
        filtered = filtered.filter(p => p.ativo === false);
      }
    }

    if (searchTerm) {
      const lowerCaseSearchTerm = searchTerm.toLowerCase();
      filtered = filtered.filter(p => 
        p.nome.toLowerCase().includes(lowerCaseSearchTerm)
      );
    }
    
    setFilteredProdutos(filtered);
  }, [produtos, searchTerm, categoriaFiltro, statusFiltro]);

  const loadProdutos = async () => {
    try {
      setLoading(true);
      const data = await Produto.list('-created_date');
      
      // Filtrar apenas produtos com IDs válidos e limpar dados corrompidos
      const produtosValidos = (data || []).filter(produto => {
        // Basic check for existence and then regex for ObjectId format
        return produto.id && typeof produto.id === 'string' && /^[0-9a-fA-F]{24}$/.test(produto.id);
      });
      
      setProdutos(produtosValidos);
      
      // Se encontrarmos produtos com IDs inválidos, avisar o usuário
      if (data && data.length > produtosValidos.length) {
        const produtosInvalidos = data.length - produtosValidos.length;
        console.warn(`${produtosInvalidos} produto(s) com dados corrompidos foram filtrados.`);
      }
      
    } catch (error) {
      console.error("Erro ao carregar produtos:", error);
      setMessage({ type: "error", text: "Erro ao carregar produtos." });
      setProdutos([]); // Array vazio para evitar crashes
    } finally {
      setLoading(false);
    }
  };

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      console.error("Erro ao carregar usuário:", error);
    }
  };

  const handleToggleStatus = async (produto) => {
    try {
      const novoStatus = !produto.ativo;
      const dataToSave = { ...produto, ativo: novoStatus };
      await Produto.update(produto.id, dataToSave);
      setMessage({ type: "success", text: `Status do produto "${produto.nome}" alterado.` });
      loadProdutos();
    } catch (error) {
      console.error('Erro ao alterar status do produto:', error);
      setMessage({ type: "error", text: 'Erro ao alterar status do produto. Tente novamente.' });
    }
  };
  
  const handleCreate = () => {
    setEditingProduto(null);
    setShowModal(true);
    setMessage({ type: "", text: "" });
  };

  const handleEdit = (produto) => {
    setEditingProduto(produto);
    setShowModal(true);
    setMessage({ type: "", text: "" });
  };

  const handleDelete = async (produto) => {
    if (window.confirm(`Tem certeza que deseja excluir o produto "${produto.nome}"?`)) {
      try {
        await Produto.delete(produto.id);
        setMessage({ type: "success", text: `Produto "${produto.nome}" excluído com sucesso.` });
        loadProdutos();
      } catch (error) {
        console.error('Erro ao excluir produto:', error);
        setMessage({ type: "error", text: 'Erro ao excluir produto. Tente novamente.' });
      }
    }
  };

  const handleDeleteAll = async () => {
    if (window.confirm(`Tem certeza que deseja excluir TODOS os ${produtos.length} produtos? Esta ação é irreversível!`)) {
      setIsDeletingAll(true);
      setMessage({ type: "", text: "" });
      try {
        const numProdutos = produtos.length;
        for (const produto of produtos) {
          await Produto.delete(produto.id);
        }
        setMessage({ type: "success", text: `${numProdutos} produtos foram excluídos com sucesso.` });
        loadProdutos();
      } catch (error) {
        console.error('Erro ao excluir todos os produtos:', error);
        setMessage({ type: "error", text: 'Erro ao excluir todos os produtos. Tente novamente.' });
      } finally {
        setIsDeletingAll(false);
      }
    }
  };

  const handleFormSuccess = () => {
    setShowModal(false);
    setEditingProduto(null);
    setMessage({ type: "success", text: "Operação realizada com sucesso!" });
    loadProdutos();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Produtos</h2>
          <p className="text-slate-600">Gerencie seu catálogo de produtos</p>
        </div>
        <div className="flex gap-2 flex-wrap justify-end">
          {produtos.length > 0 && currentUser?.role === 'admin' && (
            <Button
              variant="outline"
              onClick={handleDeleteAll}
              loading={isDeletingAll}
              disabled={isDeletingAll}
              icon={<Trash2 size={16} />}
              className="border-red-300 text-red-700 hover:bg-red-50 focus:ring-red-500"
            >
              {isDeletingAll ? 'Apagando...' : 'Apagar Todos'}
            </Button>
          )}
          <Button onClick={handleCreate} icon={<Plus size={16} />}>
            Novo Produto
          </Button>
        </div>
      </div>
      
      {message.text && (
        <Alert variant={message.type === "error" ? "destructive" : (message.type === "warning" ? "default" : "default")} className="mb-6">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{message.text}</AlertDescription>
        </Alert>
      )}

      <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm flex flex-col sm:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
          <Input
            placeholder="Buscar por nome..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <div className="flex-1 relative">
          <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
          <select
            value={categoriaFiltro}
            onChange={(e) => setCategoriaFiltro(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
          >
            <option value="todos">Todas as Categorias</option>
            {categorias.map(cat => (
              <option key={cat.value} value={cat.value}>{cat.label}</option>
            ))}
          </select>
        </div>
        <div className="flex-1 relative">
          <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
          <select
            value={statusFiltro}
            onChange={(e) => setStatusFiltro(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
          >
            <option value="todos">Todos os Status</option>
            <option value="ativo">Apenas Ativos</option>
            <option value="inativo">Apenas Inativos</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm text-center">
            <p className="text-2xl font-bold text-blue-600">{filteredProdutos.length}</p>
            <p className="text-sm text-slate-600">Total de Produtos</p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm text-center">
            <p className="text-2xl font-bold text-green-600">{filteredProdutos.filter(p => p.ativo === true).length}</p>
            <p className="text-sm text-slate-600">Produtos Ativos</p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm text-center">
            <p className="text-2xl font-bold text-red-600">{filteredProdutos.filter(p => (p.estoque_atual || p.estoque || 0) < 5).length}</p>
            <p className="text-sm text-slate-600">Estoque Baixo</p>
        </div>
      </div>
      
      <TabelaProdutos
        produtos={filteredProdutos}
        onEditar={handleEdit}
        onExcluir={handleDelete}
        onToggleAtivo={handleToggleStatus}
        loading={loading}
        userRole={currentUser?.role}
      />

      {showModal && (
        <Modal
          isOpen={showModal}
          onClose={() => setShowModal(false)}
          title={editingProduto ? 'Editar Produto' : 'Novo Produto'}
          size="xl"
        >
          <ProdutoForm
            produtoInicial={editingProduto}
            onSubmitSuccess={handleFormSuccess}
            onCancel={() => setShowModal(false)}
            allProdutos={produtos}
          />
        </Modal>
      )}
    </div>
  );
}
