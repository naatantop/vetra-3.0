
import React, { useState, useEffect } from "react";
import { Orcamento } from "@/api/entities";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { ShoppingCart, MoreHorizontal, Eye, Truck, Scissors, CheckCircle, AlertTriangle, FileText, DollarSign, Plus } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Alert, AlertDescription } from "@/components/ui/alert";
import NfeFormModal from "../components/nfe/NfeFormModal";

const StatCard = ({ icon: Icon, title, value, colorClass }) => (
  <Card className="bg-white/80 backdrop-blur-sm shadow-lg">
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium text-slate-600">{title}</CardTitle>
      <Icon className={`w-5 h-5 ${colorClass}`} />
    </CardHeader>
    <CardContent>
      <p className="text-2xl font-bold text-slate-900">{value}</p>
    </CardContent>
  </Card>
);

const getStatusVendaInfo = (status) => {
  const statuses = {
    aguardando_producao: { label: "Aguardando Produção", color: "bg-yellow-100 text-yellow-800 border-yellow-200", icon: <Scissors className="w-3 h-3" /> },
    em_producao: { label: "Em Produção", color: "bg-blue-100 text-blue-800 border-blue-200", icon: <Scissors className="w-3 h-3" /> },
    aguardando_entrega: { label: "Aguardando Entrega", color: "bg-purple-100 text-purple-800 border-purple-200", icon: <Truck className="w-3 h-3" /> },
    concluida: { label: "Concluída", color: "bg-green-100 text-green-800 border-green-200", icon: <CheckCircle className="w-3 h-3" /> },
  };
  return statuses[status] || { label: status, color: "bg-gray-100 text-gray-800" };
};

const getNfeStatusInfo = (status) => {
  if (!status) return null;
  const statuses = {
    aprovado: { label: "NF-e Aprovada", color: "bg-green-100 text-green-800 border-green-200" },
    rejeitado: { label: "NF-e Rejeitada", color: "bg-red-100 text-red-800 border-red-200" },
    processando_autorizacao: { label: "NF-e Processando", color: "bg-blue-100 text-blue-800 border-blue-200" },
    cancelado: { label: "NF-e Cancelada", color: "bg-gray-100 text-gray-800 border-gray-200" },
  };
  return statuses[status] || { label: `NF-e: ${status}`, color: "bg-yellow-100 text-yellow-800 border-yellow-200" };
};

export default function Vendas() {
  const [vendas, setVendas] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [message, setMessage] = useState({ type: "", text: "" });
  const [isNfeModalOpen, setIsNfeModalOpen] = useState(false);
  const [selectedVenda, setSelectedVenda] = useState(null);

  useEffect(() => {
    loadVendas();
  }, []);

  const loadVendas = async () => {
    setIsLoading(true);
    try {
      const data = await Orcamento.filter({ status: 'aprovado' }, '-data_orcamento');
      
      // Filtrar apenas orçamentos com IDs válidos
      const vendasValidas = (data || []).filter(venda => {
        // Verificar se o ID é um ObjectId válido (24 caracteres hexadecimais)
        return venda.id && /^[0-9a-fA-F]{24}$/.test(venda.id);
      });
      
      setVendas(vendasValidas);
    } catch (error) {
      console.error("Erro ao carregar vendas:", error);
      setMessage({ type: "error", text: "Erro ao carregar vendas. Alguns dados podem estar corrompidos." });
      // Em caso de erro, definir array vazio para evitar crashes
      setVendas([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleStatusChange = async (vendaId, novoStatus) => {
    try {
      await Orcamento.update(vendaId, { status_venda: novoStatus });
      setMessage({ type: "success", text: "Status da venda atualizado." });
      loadVendas();
    } catch (error) {
      console.error("Erro ao atualizar status:", error);
      setMessage({ type: "error", text: "Erro ao atualizar status da venda." });
    }
  };

  const openNfeModal = (venda) => {
    setSelectedVenda(venda);
    setIsNfeModalOpen(true);
  };
  
  const formatCurrency = (value) => (value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  const formatDate = (date) => format(new Date(date), "dd 'de' MMMM, yyyy", { locale: ptBR });

  const totalVendas = vendas.length;
  const valorTotalVendido = vendas.reduce((sum, venda) => sum + (venda.valor_final || 0), 0);
  const emProducao = vendas.filter(v => v.status_venda === 'em_producao').length;
  const aguardandoEntrega = vendas.filter(v => v.status_venda === 'aguardando_entrega').length;

  if (isLoading) {
    return (
      <div className="p-6 text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-slate-100 min-h-screen">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Gestão de Vendas</h1>
          <p className="text-slate-600 mt-1">Acompanhe os pedidos desde a produção até a entrega.</p>
        </div>
        <Link to={createPageUrl("NovoOrcamento")}>
          <Button className="bg-blue-600 hover:bg-blue-700">
            <Plus className="w-4 h-4 mr-2" />
            Criar Orçamento
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          icon={DollarSign} 
          title="Valor Total Vendido"
          value={formatCurrency(valorTotalVendido)}
          colorClass="text-green-600"
        />
        <StatCard 
          icon={ShoppingCart}
          title="Total de Vendas"
          value={totalVendas}
          colorClass="text-blue-600"
        />
        <StatCard 
          icon={Scissors}
          title="Em Produção"
          value={emProducao}
          colorClass="text-blue-600"
        />
        <StatCard 
          icon={Truck}
          title="Aguardando Entrega"
          value={aguardandoEntrega}
          colorClass="text-purple-600"
        />
      </div>

      {message.text && (
        <Alert variant={message.type === "error" ? "destructive" : "default"}>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{message.text}</AlertDescription>
        </Alert>
      )}

      {vendas.length === 0 ? (
        <Card className="bg-white/80 backdrop-blur-sm shadow-lg">
          <CardContent className="p-12 text-center text-slate-500">
            <ShoppingCart className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <h3 className="text-lg font-medium text-slate-800 mb-2">Nenhuma venda registrada</h3>
            <p>Vendas aparecem aqui após um orçamento ser aprovado.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {vendas.map((venda) => {
            const statusInfo = getStatusVendaInfo(venda.status_venda);
            const nfeStatusInfo = getNfeStatusInfo(venda.nfe_status);
            return (
              <Card key={venda.id} className="bg-white/80 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all">
                <CardContent className="p-6">
                  <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2 flex-wrap">
                        <h3 className="text-lg font-semibold text-slate-900">
                          Venda #{venda.numero || venda.id.slice(-6)}
                        </h3>
                        <Badge className={`px-2 py-1 text-xs font-medium border flex items-center gap-1.5 ${statusInfo.color}`}>
                          {statusInfo.icon}
                          {statusInfo.label}
                        </Badge>
                        {nfeStatusInfo && (
                           <Badge className={`px-2 py-1 text-xs font-medium border flex items-center gap-1.5 ${nfeStatusInfo.color}`}>
                            <FileText className="w-3 h-3" />
                            {nfeStatusInfo.label}
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-slate-600">
                        <span className="font-medium">Cliente:</span> {venda.cliente_nome}
                      </p>
                      <p className="text-sm text-slate-500">
                        {formatDate(venda.data_orcamento)}
                      </p>
                    </div>

                    <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                      <div className="text-right">
                        <p className="text-sm text-slate-600">Valor Total</p>
                        <p className="text-xl font-bold text-green-600">
                          {formatCurrency(venda.valor_final)}
                        </p>
                      </div>
                      
                      <div className="flex gap-2 flex-wrap">
                        <Link to={createPageUrl(`OrcamentoDetalhes`)+`?id=${venda.id}`}>
                          <Button variant="outline" size="sm" className="text-slate-600 hover:text-slate-700 hover:bg-slate-50">
                            <Eye className="w-4 h-4 mr-2" />
                            Ver Orçamento
                          </Button>
                        </Link>
                        <Button variant="outline" size="sm" className="text-slate-600 hover:text-slate-700 hover:bg-slate-50" onClick={() => openNfeModal(venda)}>
                          <FileText className="w-4 h-4 mr-2" />
                          Nota Fiscal
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="outline" size="sm">
                              Mudar Status
                              <MoreHorizontal className="w-4 h-4 ml-2" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleStatusChange(venda.id, 'em_producao')}>
                              <Scissors className="w-4 h-4 mr-2" />
                              Mover para Produção
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleStatusChange(venda.id, 'aguardando_entrega')}>
                              <Truck className="w-4 h-4 mr-2" />
                              Enviar para Entrega
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleStatusChange(venda.id, 'concluida')}>
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Marcar como Concluída
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
      {isNfeModalOpen && selectedVenda && (
        <NfeFormModal 
          venda={selectedVenda}
          onClose={() => setIsNfeModalOpen(false)}
          onSuccess={() => {
            setIsNfeModalOpen(false);
            loadVendas();
            setMessage({ type: "success", text: "NF-e processada com sucesso!" });
          }}
        />
      )}
    </div>
  );
}
