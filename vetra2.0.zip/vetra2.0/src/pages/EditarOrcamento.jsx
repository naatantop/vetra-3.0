import React, { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import NovoOrcamento from './NovoOrcamento';

export default function EditarOrcamento() {
  // This component just redirects to NovoOrcamento with the ID parameter
  // NovoOrcamento will handle both creation and editing
  return <NovoOrcamento />;
}