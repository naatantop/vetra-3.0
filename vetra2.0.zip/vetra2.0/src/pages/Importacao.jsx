import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Upload, Users, Package, FileText, ArrowRight } from 'lucide-react';
import ImportacaoWizard from '../components/importacao/ImportacaoWizard';

export default function Importacao() {
  const [tipoImportacao, setTipoImportacao] = useState(null);

  const handleSelectTipo = (tipo) => {
    setTipoImportacao(tipo);
  };

  if (tipoImportacao) {
    return (
      <ImportacaoWizard 
        tipo={tipoImportacao} 
        onCancel={() => setTipoImportacao(null)} 
      />
    );
  }

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-slate-100 min-h-screen">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Importação de Dados</h1>
          <p className="text-slate-600 mt-1">Importe seus clientes e produtos a partir de planilhas (CSV).</p>
        </div>
      </div>

      <Card className="bg-white/80 backdrop-blur-sm shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5 text-blue-600" />
            Selecione o que você deseja importar
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-slate-600 mb-6">
            Escolha uma das opções abaixo para iniciar o processo de importação. Recomendamos baixar nosso modelo de planilha para garantir que seus dados estejam no formato correto.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg font-medium">Clientes</CardTitle>
                <Users className="w-6 h-6 text-blue-500" />
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-500 mb-4">Importe sua lista de clientes.</p>
                <Button className="w-full" onClick={() => handleSelectTipo('clientes')}>
                  Iniciar Importação de Clientes <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
            <Card className="hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg font-medium">Produtos</CardTitle>
                <Package className="w-6 h-6 text-emerald-500" />
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-500 mb-4">Importe seu catálogo de produtos.</p>
                <Button className="w-full" onClick={() => handleSelectTipo('produtos')}>
                  Iniciar Importação de Produtos <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}