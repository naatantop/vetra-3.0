import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { CheckSquare } from "lucide-react";

export default function Instalacoes() {
  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50/50 via-blue-50/20 to-indigo-50/20 min-h-full">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Instalações e Montagem</h1>
        <p className="text-slate-600">Controle checklists e processos de instalação</p>
      </div>

      <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
        <CardContent className="p-12">
          <div className="text-center text-slate-500">
            <CheckSquare className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <h3 className="text-lg font-medium mb-2">Módulo em Configuração</h3>
            <p>O módulo de instalações está aguardando suas especificações para configuração.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}