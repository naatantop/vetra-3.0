import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Plus, Trash2, Calculator, Save, Send, DollarSign, Percent } from 'lucide-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Orcamento } from '@/api/entities';
import { Cliente } from '@/api/entities';
import { Produto } from '@/api/entities';
import { User } from '@/api/entities';
import { ConfiguracaoEmpresa } from '@/api/entities';
import { SendEmail } from '@/api/integrations';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { getAllCategorias, getAcabamentosPorCategoria } from '../components/utils/CategoriaUtils';


export default function NovoOrcamento() {
  const location = useLocation();
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState(false);
  const [orcamentoId, setOrcamentoId] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [clientes, setClientes] = useState([]);
  const [produtos, setProdutos] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [configEmpresa, setConfigEmpresa] = useState(null);
  const [message, setMessage] = useState({ type: "", text: "" });

  const categorias = getAllCategorias(); // Now directly call the utility function

  const [formData, setFormData] = useState({
    cliente_id: '',
    cliente_nome: '',
    vendedor: '',
    numero: '', // Added for sequential numbering
    data_orcamento: new Date().toISOString().split('T')[0],
    data_validade: '',
    prazo_entrega: '', // This will hold either predefined string or custom string
    itens: [{
      produto_id: '', produto_nome: '',
      quantidade: 1, preco_unitario: 0, preco_custo: 0, subtotal: 0, observacoes: '',
      // Campos para cálculo inteligente
      tipo_medida: 'unitario',
      num_pecas: 1,
      largura_mm: '',
      altura_mm: '',
      comprimento_mm: '',
      cor_perfil: '', // Novo campo por item
      acabamento: ''  // Novo campo por item
    }],
    observacoes_gerais: '',
    metodo_pagamento: 'pix',
    parcelas: 1,
    observacoes_pagamento: '',
    desconto_percentual: 0,
    desconto_valor: 0,
    valor_total: 0,
    valor_custo_total: 0,
    valor_lucro: 0,
    margem_lucro_percentual: 0,
    valor_final: 0,
    endereco_instalacao: {
      logradouro: '', numero: '', complemento: '', bairro: '', cidade: '', uf: '', cep: ''
    }
  });

  // Define predefined prazos here
  const predefinedPrazos = [
    "3 dias após confirmação do cliente",
    "7 dias após confirmação do cliente",
    "10 dias após confirmação do cliente",
    "15 dias após confirmação do cliente",
  ];

  // Opções de cores simplificadas
  const coresPerfil = [
    'Preto',
    'Branco',
    'Bronze',
    'Natural Fosco',
    'Rosê',
    'Champagne',
    'Dourado',
    'Prata'
  ];

  const getAcabamentosDisponiveis = (produtoId) => {
    if (!produtoId) return [];

    const produto = produtos.find(p => p.id === produtoId);
    if (!produto || !produto.categoria) return [];

    return getAcabamentosPorCategoria(produto.categoria);
  };

  useEffect(() => {
    loadInitialData();
    const urlParams = new URLSearchParams(location.search);
    const id = urlParams.get('id');
    if (id) {
      setIsEditing(true);
      setOrcamentoId(id);
      loadOrcamento(id);
    } else {
      // Se não estiver editando, gerar número sequencial
      generateNextNumber();
    }
  }, [location]);


  const loadInitialData = async () => {
    try {
      const [clientesData, produtosData, userData, configData] = await Promise.all([
        Cliente.filter({ ativo: true }).catch(() => []),
        Produto.filter({ ativo: true }).catch(() => []),
        User.me().catch(() => null),
        ConfiguracaoEmpresa.list().catch(() => [])
      ]);

      // Filtrar apenas registros com IDs válidos (MongoDB ObjectId pattern)
      const objectIdRegex = /^[0-9a-fA-F]{24}$/;

      const clientesValidos = (clientesData || []).filter(cliente =>
        cliente.id && objectIdRegex.test(cliente.id)
      );

      const produtosValidos = (produtosData || []).filter(produto =>
        produto.id && objectIdRegex.test(produto.id)
      );

      setClientes(clientesValidos);
      setProdutos(produtosValidos);
      setCurrentUser(userData);
      setConfigEmpresa(configData?.[0] || null);

      if (userData?.full_name && !formData.vendedor) {
        setFormData(prev => ({ ...prev, vendedor: userData.full_name }));
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      setMessage({ type: "error", text: "Erro ao carregar dados iniciais. Alguns dados podem estar indisponíveis." });
    }
  };

  const loadOrcamento = async (id) => {
    // Verificar se o ID é válido antes de tentar carregar
    const objectIdRegex = /^[0-9a-fA-F]{24}$/;
    if (!id || !objectIdRegex.test(id)) {
      setMessage({ type: "error", text: "ID do orçamento inválido." });
      return;
    }

    try {
      const orcamentos = await Orcamento.filter({id: id});
      const orcamento = orcamentos?.[0];
      if (orcamento) {
        // Ensure numeric fields loaded from DB are treated as numbers for calculations
        const loadedOrcamento = {
          ...orcamento,
          itens: orcamento.itens.map(item => ({
            ...item,
            quantidade: parseFloat(item.quantidade) || 0,
            preco_unitario: parseFloat(item.preco_unitario) || 0,
            preco_custo: parseFloat(item.preco_custo) || 0,
            subtotal: parseFloat(item.subtotal) || 0,
            // Ensure dimensions are numbers or empty strings for input fields
            largura_mm: item.largura_mm != null ? String(item.largura_mm) : '',
            altura_mm: item.altura_mm != null ? String(item.altura_mm) : '',
            comprimento_mm: item.comprimento_mm != null ? String(item.comprimento_mm) : '',
            cor_perfil: item.cor_perfil || '', // Load per item
            acabamento: item.acabamento || '', // Load per item
          })),
          valor_total: parseFloat(orcamento.valor_total) || 0,
          valor_custo_total: parseFloat(orcamento.valor_custo_total) || 0,
          valor_lucro: parseFloat(orcamento.valor_lucro) || 0,
          margem_lucro_percentual: parseFloat(orcamento.margem_lucro_percentual) || 0,
          valor_final: parseFloat(orcamento.valor_final) || 0,
          desconto_percentual: parseFloat(orcamento.desconto_percentual) || 0,
          desconto_valor: parseFloat(orcamento.desconto_valor) || 0,
          parcelas: parseInt(orcamento.parcelas) || 1,
        };
        setFormData(loadedOrcamento);
        // Recalculate totals after loading to ensure derived fields are correct
        calcularTotais(loadedOrcamento.itens, loadedOrcamento.desconto_percentual);
      } else {
        setMessage({ type: "error", text: "Orçamento não encontrado." });
      }
    } catch (error) {
      console.error('Erro ao carregar orçamento:', error);
      setMessage({ type: "error", text: "Erro ao carregar orçamento." });
    }
  };

  const generateNextNumber = async () => {
    try {
      // Buscar todos os orçamentos para encontrar o próximo número
      const orcamentos = await Orcamento.list();

      // Filtrar apenas orçamentos com números válidos e extrair os números
      const numerosExistentes = orcamentos
        .map(orc => {
          // Tentar extrair número do campo numero ou do formato ORC-XXXX
          if (orc.numero) {
            if (orc.numero.includes('-')) {
              const parts = orc.numero.split('-');
              const num = parseInt(parts[parts.length - 1], 10);
              return isNaN(num) ? 0 : num;
            } else {
              const num = parseInt(orc.numero, 10);
              return isNaN(num) ? 0 : num;
            }
          }
          return 0;
        })
        .filter(num => num > 0);

      // Encontrar o próximo número sequencial
      const proximoNumero = numerosExistentes.length > 0
        ? Math.max(...numerosExistentes) + 1
        : 1;

      // Formatar com zeros à esquerda (01, 02, 03, etc.)
      const numeroFormatado = proximoNumero.toString().padStart(2, '0');

      setFormData(prev => ({
        ...prev,
        numero: numeroFormatado
      }));
    } catch (error) {
      console.error('Erro ao gerar número sequencial:', error);
      // Fallback para formato timestamp se houver erro
      setFormData(prev => ({
        ...prev,
        numero: '01'
      }));
    }
  };

  const handleClienteChange = (clienteId) => {
    const cliente = clientes.find(c => c.id === clienteId);
    if (cliente) {
      setFormData(prev => ({
        ...prev,
        cliente_id: clienteId,
        cliente_nome: cliente.nome,
        endereco_instalacao: cliente.endereco || prev.endereco_instalacao
      }));
    }
  };

  const recalcularItem = (currentItens, index) => {
    const item = { ...currentItens[index] }; // Create a copy to modify
    let quantidadeFinal = parseFloat(item.num_pecas) || 1;

    if (item.tipo_medida === 'm2') {
      const largura = parseFloat(item.largura_mm) || 0;
      const altura = parseFloat(item.altura_mm) || 0;
      if (largura > 0 && altura > 0) {
        const areaPorPeca = (largura * altura) / 1000000; // mm2 to m2
        quantidadeFinal = areaPorPeca * (parseFloat(item.num_pecas) || 1);
      } else {
        quantidadeFinal = 0;
      }
    } else if (item.tipo_medida === 'metro_linear') {
      const comprimento = parseFloat(item.comprimento_mm) || 0;
      if (comprimento > 0) {
        const mlPorPeca = comprimento / 1000; // mm to meter
        quantidadeFinal = mlPorPeca * (parseFloat(item.num_pecas) || 1);
      } else {
        quantidadeFinal = 0;
      }
    }

    // Arredonda para 4 casas decimais para evitar problemas de ponto flutuante
    item.quantidade = parseFloat(quantidadeFinal.toFixed(4));
    item.subtotal = item.quantidade * (parseFloat(item.preco_unitario) || 0);

    currentItens[index] = item; // Update the item in the array
    return currentItens;
  };

  const handleProdutoChange = (index, produtoId) => {
    // Verificar se o produto ID é válido
    const objectIdRegex = /^[0-9a-fA-F]{24}$/;
    if (!produtoId || !objectIdRegex.test(produtoId)) {
      // Optionally, set a message or log an error if an invalid ID is somehow passed
      // setMessage({ type: "error", text: "ID do produto inválido." });
      return;
    }

    const produto = produtos.find(p => p.id === produtoId);
    if (produto) {
      let newItens = [...formData.itens];

      newItens[index] = {
        ...newItens[index],
        produto_id: produtoId,
        produto_nome: produto.nome,
        preco_unitario: produto.preco_venda || 0,
        preco_custo: produto.preco_custo || 0,
        tipo_medida: produto.tipo_medida || 'unitario', // Set type based on product
        largura_mm: produto.largura_mm != null ? String(produto.largura_mm) : '', // Convert to string for input
        altura_mm: produto.altura_mm != null ? String(produto.altura_mm) : '',   // Convert to string for input
        comprimento_mm: produto.comprimento_mm != null ? String(produto.comprimento_mm) : '', // Convert to string for input
        num_pecas: 1, // Reset num_pecas
        // Resetar acabamento quando produto muda
        acabamento: ''
      };

      newItens = recalcularItem(newItens, index);
      const newFormData = { ...formData, itens: newItens };
      setFormData(newFormData);
      calcularTotais(newItens, newFormData.desconto_percentual);
    }
  };

  const handleItemChange = (index, field, value) => {
    let newItens = [...formData.itens];
    newItens[index][field] = value;

    // Garantir que o tipo_medida seja copiado do produto selecionado
    if (field === 'produto_id') {
      const produto = produtos.find(p => p.id === value);
      if (produto) {
        newItens[index] = {
          ...newItens[index],
          produto_nome: produto.nome,
          preco_unitario: produto.preco_venda || 0,
          preco_custo: produto.preco_custo || 0,
          tipo_medida: produto.tipo_medida || 'unitario', // Garantir que o tipo_medida seja salvo
          largura_mm: produto.largura_mm != null ? String(produto.largura_mm) : '',
          altura_mm: produto.altura_mm != null ? String(produto.altura_mm) : '',
          comprimento_mm: produto.comprimento_mm != null ? String(produto.comprimento_mm) : '',
          acabamento: '', // Reset acabamento if product changes via direct item change (not select change)
        };
      }
    }

    newItens = recalcularItem(newItens, index);

    const newFormData = { ...formData, itens: newItens };
    setFormData(newFormData);
    calcularTotais(newItens, newFormData.desconto_percentual);
  };

  const handleDescontoChange = (percentual) => {
      const newFormData = { ...formData, desconto_percentual: percentual };
      setFormData(newFormData);
      calcularTotais(newFormData.itens, percentual);
  }

  const calcularTotais = (itens, descontoPercentual) => {
    const valorTotal = itens.reduce((sum, item) => sum + (item.subtotal || 0), 0);
    const custoTotal = itens.reduce((sum, item) => sum + ((parseFloat(item.preco_custo) || 0) * (parseFloat(item.quantidade) || 0)), 0);

    const descontoValor = (valorTotal * (descontoPercentual / 100));
    const valorFinal = valorTotal - descontoValor;

    const valorLucro = valorFinal - custoTotal;
    // Calculate margin based on final value if cost is zero, otherwise based on cost
    const margemLucro = custoTotal > 0 ? (valorLucro / custoTotal) * 100 : (valorFinal > 0 ? (valorFinal > 0 ? 100 : 0) : 0);

    setFormData(prev => ({
      ...prev,
      valor_total: valorTotal,
      valor_custo_total: custoTotal,
      desconto_valor: descontoValor,
      valor_final: valorFinal,
      valor_lucro: valorLucro,
      margem_lucro_percentual: margemLucro
    }));
  };

  const adicionarItem = () => {
    const novoItem = {
      produto_id: '', produto_nome: '',
      quantidade: 1, preco_unitario: 0, preco_custo: 0, subtotal: 0, observacoes: '',
      tipo_medida: 'unitario',
      num_pecas: 1,
      largura_mm: '',
      altura_mm: '',
      comprimento_mm: '',
      cor_perfil: '', // Novo campo por item
      acabamento: ''  // Novo campo por item
    };

    setFormData(prev => ({
      ...prev,
      itens: [novoItem, ...prev.itens] // Adiciona o novo item no início da lista
    }));
  };

  const removerItem = (index) => {
    if (formData.itens.length > 1) {
      const newItens = formData.itens.filter((_, i) => i !== index);
      const newFormData = { ...formData, itens: newItens };
      setFormData(newFormData);
      calcularTotais(newItens, newFormData.desconto_percentual);
    }
  };

  const handleSubmit = async (status = 'em_elaboracao') => {
    setIsLoading(true);
    setMessage({ type: "", text: "" });

    try {
      if (!formData.cliente_id || !formData.vendedor) {
        setMessage({ type: "error", text: "Preencha os campos obrigatórios (Cliente e Vendedor)." });
        setIsLoading(false);
        return;
      }

      const hasValidItem = formData.itens.some(item => item.produto_id && item.quantidade > 0 && item.preco_unitario > 0);
      if (!hasValidItem && formData.itens.length > 0) {
        setMessage({ type: "error", text: "Adicione pelo menos um item válido ao orçamento com produto, quantidade e preço." });
        setIsLoading(false);
        return;
      }

      // Limpar e validar dados antes de enviar
      const dataToSave = {
        ...formData,
        status,
        // Manter o número gerado automaticamente ou usar o existente se estiver editando
        numero: formData.numero || '01',
        // Limpar itens para garantir que os campos numéricos sejam válidos
        itens: formData.itens.map(item => ({
          ...item,
          quantidade: parseFloat(item.quantidade) || 0,
          preco_unitario: parseFloat(item.preco_unitario) || 0,
          preco_custo: parseFloat(item.preco_custo) || 0,
          subtotal: parseFloat(item.subtotal) || 0,
          // Converter strings vazias para null ou remover campos vazios
          num_pecas: parseFloat(item.num_pecas) || 0, // Ensure num_pecas is parsed
          largura_mm: item.largura_mm !== '' ? parseFloat(item.largura_mm) : null,
          altura_mm: item.altura_mm !== '' ? parseFloat(item.altura_mm) : null,
          comprimento_mm: item.comprimento_mm !== '' ? parseFloat(item.comprimento_mm) : null,
          // New fields (cor_perfil, acabamento) are strings, no special handling needed for saving
        })),
        // Garantir que valores financeiros sejam números
        valor_total: parseFloat(formData.valor_total) || 0,
        valor_custo_total: parseFloat(formData.valor_custo_total) || 0,
        valor_lucro: parseFloat(formData.valor_lucro) || 0,
        margem_lucro_percentual: parseFloat(formData.margem_lucro_percentual) || 0,
        valor_final: parseFloat(formData.valor_final) || 0,
        desconto_percentual: parseFloat(formData.desconto_percentual) || 0,
        desconto_valor: parseFloat(formData.desconto_valor) || 0,
        parcelas: parseInt(formData.parcelas) || 1,
      };

      // Remover campos null dos itens para evitar problemas de validação
      dataToSave.itens = dataToSave.itens.map(item => {
        const cleanItem = { ...item };
        if (cleanItem.largura_mm === null) delete cleanItem.largura_mm;
        if (cleanItem.altura_mm === null) delete cleanItem.altura_mm;
        if (cleanItem.comprimento_mm === null) delete cleanItem.comprimento_mm;
        return cleanItem;
      });

      let savedOrcamento;
      if (isEditing) {
        savedOrcamento = await Orcamento.update(orcamentoId, dataToSave);
      } else {
        savedOrcamento = await Orcamento.create(dataToSave);
      }
      const savedOrcamentoId = isEditing ? orcamentoId : savedOrcamento.id;

      if (status === 'enviado') {
          const cliente = clientes.find(c => c.id === formData.cliente_id);
          if (cliente && cliente.email) {
              try {
                // Primeiro, verificar se o e-mail do cliente corresponde a um usuário do sistema
                const usuarios = await User.list();
                const usuarioCliente = usuarios.find(u => u.email.toLowerCase() === cliente.email.toLowerCase());

                if (!usuarioCliente) {
                  // Cliente não é usuário do sistema - mostrar aviso específico
                  setMessage({
                    type: "warning",
                    text: `Orçamento salvo com sucesso! ATENÇÃO: Não foi possível enviar o e-mail porque "${cliente.email}" não está cadastrado como usuário no sistema. Você pode baixar o PDF do orçamento e enviá-lo manualmente.`
                  });
                } else {
                  // Cliente é usuário do sistema - tentar enviar e-mail
                  const pdfUrl = `${window.location.origin}${createPageUrl('OrcamentoPDF')}?id=${savedOrcamentoId}`;
                  const nomeEmpresa = configEmpresa?.nome_empresa || "VETRA 2.0";

                  const emailBody = `
                      <p>Olá ${cliente.nome},</p>
                      <p>Agradecemos a sua preferência. Conforme solicitado, estamos enviando o seu orçamento.</p>
                      <p>Você pode visualizá-lo e baixá-lo clicando no link abaixo:</p>
                      <p><a href="${pdfUrl}" style="background-color: #3b82f6; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; display: inline-block;">Ver Orçamento</a></p>
                      <br>
                      <p>Qualquer dúvida, estamos à disposição.</p>
                      <br>
                      <p>Atenciosamente,</p>
                      <p><strong>${nomeEmpresa}</strong></p>
                  `;

                  await SendEmail({
                      to: cliente.email,
                      subject: `Seu Orçamento de ${nomeEmpresa} - Nº ${dataToSave.numero}`,
                      body: emailBody,
                  });

                  setMessage({ type: "success", text: "Orçamento salvo e enviado por e-mail com sucesso!" });
                }
              } catch (emailError) {
                console.error("Erro ao enviar e-mail:", emailError);

                // Tratar diferentes tipos de erro
                let errorMessage = "Orçamento salvo com sucesso! ";

                if (emailError.message && emailError.message.includes("Cannot send emails to users outside the app")) {
                  errorMessage += `ATENÇÃO: Não foi possível enviar o e-mail porque "${cliente.email}" não está cadastrado como usuário no sistema. Você pode baixar o PDF do orçamento e enviá-lo manualmente.`;
                } else if (emailError.message && emailError.message.includes("404")) {
                  errorMessage += `Erro no envio do e-mail: Serviço de e-mail temporariamente indisponível. Você pode baixar o PDF do orçamento e enviá-lo manualmente.`;
                } else {
                  errorMessage += `Erro no envio do e-mail: ${emailError.message || "Erro desconhecido"}. Você pode baixar o PDF do orçamento e enviá-lo manualmente.`;
                }

                setMessage({ type: "warning", text: errorMessage });
              }
          } else {
              setMessage({ type: "warning", text: "Orçamento salvo com sucesso! ATENÇÃO: Não foi possível enviar o e-mail pois o cliente não possui e-mail cadastrado. Você pode baixar o PDF do orçamento e enviá-lo manualmente." });
          }
      } else {
         setMessage({ type: "success", text: `Orçamento ${isEditing ? 'atualizado' : 'criado'} com sucesso.` });
      }

      setTimeout(() => {
        navigate(createPageUrl('Orcamentos'));
      }, 3000);

    } catch (error) {
      console.error('Erro ao salvar orçamento:', error);
      setMessage({ type: "error", text: `Erro ao salvar orçamento: ${error.message || "Verifique os dados e tente novamente."}` });
    } finally {
      setIsLoading(false);
    }
  };

  const formatCurrency = (value) => {
    return (value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  // Determine the selected option for the dropdown based on current formData.prazo_entrega
  const selectedPrazoOption = predefinedPrazos.includes(formData.prazo_entrega)
    ? formData.prazo_entrega
    : 'personalizado';

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-slate-100 min-h-screen">
      <div className="flex items-center gap-4 mb-6">
        <Link to={createPageUrl('Orcamentos')}>
          <Button variant="outline" size="sm">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold text-slate-900">
            {isEditing ? 'Editar Orçamento' : 'Novo Orçamento'}
          </h1>
          <p className="text-slate-600">Crie orçamentos detalhados para seus clientes</p>
        </div>
      </div>

      {message.text && (
        <Alert variant={message.type === "error" ? "destructive" : message.type === "warning" ? "default" : "default"}>
          <AlertDescription>{message.text}</AlertDescription>
        </Alert>
      )}

      <div className="flex flex-col lg:flex-row lg:items-start gap-6">
        {/* Coluna Principal - Agora com flex-1 para ocupar espaço disponível */}
        <div className="flex-1 space-y-6">
          {/* Dados do Cliente */}
          <Card>
            <CardHeader>
              <CardTitle>Dados do Cliente</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Número do Orçamento</label>
                  <Input
                    value={formData.numero}
                    onChange={(e) => setFormData(prev => ({ ...prev, numero: e.target.value }))}
                    placeholder="Número automático"
                    className="bg-slate-50"
                    readOnly // Make it read-only as it's auto-generated
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Cliente *</label>
                  <select
                    value={formData.cliente_id}
                    onChange={(e) => handleClienteChange(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Selecione um cliente</option>
                    {clientes.map(cliente => (
                      <option key={cliente.id} value={cliente.id}>{cliente.nome}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Vendedor *</label>
                  <Input
                    value={formData.vendedor}
                    onChange={(e) => setFormData(prev => ({ ...prev, vendedor: e.target.value }))}
                    placeholder="Nome do vendedor"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Data do Orçamento</label>
                  <Input
                    type="date"
                    value={formData.data_orcamento}
                    onChange={(e) => setFormData(prev => ({ ...prev, data_orcamento: e.target.value }))}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Validade</label>
                  <Input
                    type="date"
                    value={formData.data_validade}
                    onChange={(e) => setFormData(prev => ({ ...prev, data_validade: e.target.value }))}
                  />
                </div>
              </div>

            </CardContent>
          </Card>

          {/* Itens do Orçamento */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Itens do Orçamento</CardTitle>
              <Button onClick={adicionarItem} size="sm">
                <Plus className="w-4 h-4 mr-2" />
                Adicionar Item
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {formData.itens.map((item, index) => (
                  <div key={index} className="p-4 border border-slate-200 rounded-lg bg-slate-50/50">
                    <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                      {/* Produto Select */}
                      <div className="md:col-span-12">
                        <label className="block text-sm font-medium text-slate-700 mb-1">Produto</label>
                        <select
                          value={item.produto_id}
                          onChange={(e) => handleProdutoChange(index, e.target.value)}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                        >
                          <option value="">Selecione um produto</option>
                          {produtos.map(produto => (
                            <option key={produto.id} value={produto.id}>{produto.nome}</option>
                          ))}
                        </select>
                      </div>

                      {/* Cor do Perfil e Acabamento */}
                      <div className="md:col-span-6">
                        <label className="block text-sm font-medium text-slate-700 mb-1">Cor do Perfil</label>
                        <select
                          value={item.cor_perfil}
                          onChange={(e) => handleItemChange(index, 'cor_perfil', e.target.value)}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                        >
                          <option value="">Selecione a cor</option>
                          {coresPerfil.map(cor => (
                            <option key={cor} value={cor}>{cor}</option>
                          ))}
                        </select>
                      </div>

                      <div className="md:col-span-6">
                        <label className="block text-sm font-medium text-slate-700 mb-1">Acabamento</label>
                        <select
                          value={item.acabamento}
                          onChange={(e) => handleItemChange(index, 'acabamento', e.target.value)}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                          disabled={!item.produto_id}
                        >
                          <option value="">
                            {!item.produto_id ? 'Selecione um produto primeiro' : 'Selecione o acabamento'}
                          </option>
                          {getAcabamentosDisponiveis(item.produto_id).map(acabamento => (
                            <option key={acabamento} value={acabamento}>{acabamento}</option>
                          ))}
                        </select>
                        {!item.produto_id && (
                          <p className="text-xs text-slate-500 mt-1">
                            Os acabamentos disponíveis dependem do produto selecionado
                          </p>
                        )}
                      </div>

                      {/* Campos de Medida Condicionais */}
                      {item.tipo_medida === 'm2' && (
                        <>
                          <div className="md:col-span-3">
                            <label className="block text-sm font-medium text-slate-700 mb-1">Largura (mm)</label>
                            <Input
                              type="number"
                              placeholder="mm"
                              value={item.largura_mm}
                              onChange={(e) => handleItemChange(index, 'largura_mm', e.target.value)}
                            />
                          </div>
                          <div className="md:col-span-3">
                            <label className="block text-sm font-medium text-slate-700 mb-1">Altura (mm)</label>
                            <Input
                              type="number"
                              placeholder="mm"
                              value={item.altura_mm}
                              onChange={(e) => handleItemChange(index, 'altura_mm', e.target.value)}
                            />
                          </div>
                        </>
                      )}

                      {item.tipo_medida === 'metro_linear' && (
                        <div className="md:col-span-6">
                          <label className="block text-sm font-medium text-slate-700 mb-1">Comprimento (mm)</label>
                          <Input
                            type="number"
                            placeholder="mm"
                            value={item.comprimento_mm}
                            onChange={(e) => handleItemChange(index, 'comprimento_mm', e.target.value)}
                          />
                        </div>
                      )}

                      {/* Quantidade de Peças */}
                      <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-slate-700 mb-1">Peças</label>
                        <Input
                          type="number"
                          value={item.num_pecas}
                          onChange={(e) => handleItemChange(index, 'num_pecas', parseFloat(e.target.value) || 0)}
                          min="0"
                        />
                      </div>

                      {/* Preço Unitário */}
                      <div className="md:col-span-4">
                        <label className="block text-sm font-medium text-slate-700 mb-1">Preço Unit. (p/ {item.tipo_medida === 'm2' ? 'm²' : item.tipo_medida === 'metro_linear' ? 'ml' : 'pç'})</label>
                        <Input
                          type="number"
                          value={item.preco_unitario}
                          onChange={(e) => handleItemChange(index, 'preco_unitario', parseFloat(e.target.value) || 0)}
                          min="0"
                          step="0.01"
                        />
                      </div>

                      {/* Total Calculado */}
                      <div className="md:col-span-4">
                        <label className="block text-sm font-medium text-slate-700 mb-1">Qtd. Calculada</label>
                        <div className="px-3 py-2 bg-slate-200 rounded-lg text-sm font-medium">
                          {item.quantidade} {item.tipo_medida === 'm2' ? 'm²' : item.tipo_medida === 'metro_linear' ? 'ml' : 'pç'}
                        </div>
                      </div>

                      {/* Subtotal */}
                      <div className="md:col-span-4">
                        <label className="block text-sm font-medium text-slate-700 mb-1">Subtotal</label>
                        <div className="px-3 py-2 bg-green-100 border border-green-200 rounded-lg text-lg font-bold text-green-800">
                          {formatCurrency(item.subtotal)}
                        </div>
                      </div>

                      {/* Botão Remover and Observações */}
                      <div className="md:col-span-8 flex items-end">
                        <div className="w-full">
                          <label className="block text-sm font-medium text-slate-700 mb-1">Observações do Item</label>
                          <Input
                            value={item.observacoes}
                            onChange={(e) => handleItemChange(index, 'observacoes', e.target.value)}
                            placeholder="Observações específicas deste item"
                          />
                        </div>
                      </div>

                      <div className="md:col-span-4 flex items-end">
                        {formData.itens.length > 1 && (
                          <Button
                            onClick={() => removerItem(index)}
                            size="sm"
                            variant="outline"
                            className="w-full text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Remover Item
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Observações e Condições */}
          <Card>
            <CardHeader>
              <CardTitle>Condições de Pagamento</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Método de Pagamento</label>
                     <select
                        value={formData.metodo_pagamento}
                        onChange={(e) => setFormData(prev => ({ ...prev, metodo_pagamento: e.target.value, parcelas: e.target.value === 'cartao_credito' ? prev.parcelas : 1 }))}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="pix">PIX</option>
                        <option value="dinheiro">Dinheiro</option>
                        <option value="cartao_credito">Cartão de Crédito</option>
                        <option value="boleto">Boleto</option>
                        <option value="a_combinar">A Combinar</option>
                      </select>
                  </div>
                  {formData.metodo_pagamento === 'cartao_credito' && (
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Parcelas</label>
                      <Input
                        type="number"
                        min="1"
                        value={formData.parcelas}
                        onChange={(e) => setFormData(prev => ({ ...prev, parcelas: parseInt(e.target.value, 10) || 1 }))}
                        placeholder="Nº de parcelas"
                      />
                    </div>
                  )}
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Prazo de Entrega</label>
                <select
                  value={selectedPrazoOption}
                  onChange={(e) => {
                    const value = e.target.value;
                    if (value === 'personalizado') {
                      setFormData(prev => ({ ...prev, prazo_entrega: '' })); // Clear for new custom input
                    } else {
                      setFormData(prev => ({ ...prev, prazo_entrega: value }));
                    }
                  }}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Selecione o prazo</option>
                  {predefinedPrazos.map(prazo => (
                    <option key={prazo} value={prazo}>{prazo}</option>
                  ))}
                  <option value="personalizado">Personalizado</option>
                </select>

                {selectedPrazoOption === 'personalizado' && (
                  <Input
                    className="mt-2"
                    value={formData.prazo_entrega} // This will show the actual custom value
                    onChange={(e) => setFormData(prev => ({ ...prev, prazo_entrega: e.target.value }))}
                    placeholder="Digite o prazo personalizado"
                  />
                )}
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Observações de Pagamento</label>
                <Textarea
                  value={formData.observacoes_pagamento}
                  onChange={(e) => setFormData(prev => ({ ...prev, observacoes_pagamento: e.target.value }))}
                  placeholder="Ex: Sinal de 30% na assinatura do contrato..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Observações Gerais</label>
                <Textarea
                  value={formData.observacoes_gerais}
                  onChange={(e) => setFormData(prev => ({ ...prev, observacoes_gerais: e.target.value }))}
                  placeholder="Informações adicionais sobre o orçamento"
                />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar com Totais e Ações - Agora com a coluna inteira sticky */}
        <div className="w-full lg:w-80 lg:sticky lg:top-6 space-y-6">
          {/* Resumo Financeiro */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calculator className="w-5 h-5" />
                Resumo Financeiro
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center text-sm">
                <span className="text-slate-600">Subtotal:</span>
                <span className="font-medium">{formatCurrency(formData.valor_total)}</span>
              </div>

               <div className="flex justify-between items-center text-sm">
                <span className="text-slate-600">Custo Total:</span>
                <span className="font-medium text-amber-600">{formatCurrency(formData.valor_custo_total)}</span>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-slate-700">Desconto (%)</label>
                <Input
                  type="number"
                  value={formData.desconto_percentual}
                  onChange={(e) => handleDescontoChange(parseFloat(e.target.value) || 0)}
                  min="0"
                  max="100"
                  step="0.1"
                />
              </div>

              {formData.desconto_valor > 0 && (
                <div className="flex justify-between items-center text-sm">
                  <span className="text-slate-600">Desconto:</span>
                  <span className="font-medium text-red-600">-{formatCurrency(formData.desconto_valor)}</span>
                </div>
              )}

              <div className="border-t pt-4 space-y-3">
                 <div className="flex justify-between items-center text-base">
                  <span className="font-semibold text-slate-800">Total:</span>
                  <span className="text-lg font-bold text-green-600">{formatCurrency(formData.valor_final)}</span>
                </div>
                <div className="p-3 bg-green-50 rounded-lg border border-green-200 space-y-2">
                   <div className="flex justify-between items-center text-sm">
                      <span className="font-medium text-green-800 flex items-center gap-1.5"><DollarSign size={14}/> Lucro (R$):</span>
                      <span className="font-bold text-green-800">{formatCurrency(formData.valor_lucro)}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                      <span className="font-medium text-green-800 flex items-center gap-1.5"><Percent size={14}/> Margem:</span>
                      <span className="font-bold text-green-800">{formData.margem_lucro_percentual.toFixed(2)}%</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Ações */}
          <Card>
            <CardHeader>
              <CardTitle>Ações</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button
                onClick={() => handleSubmit('em_elaboracao')}
                disabled={isLoading}
                className="w-full"
                variant="outline"
              >
                <Save className="w-4 h-4 mr-2" />
                {isLoading ? 'Salvando...' : 'Salvar Rascunho'}
              </Button>

              <Button
                onClick={() => handleSubmit('enviado')}
                disabled={isLoading}
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                <Send className="w-4 h-4 mr-2" />
                {isLoading ? 'Enviando...' : 'Salvar e Enviar'}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}