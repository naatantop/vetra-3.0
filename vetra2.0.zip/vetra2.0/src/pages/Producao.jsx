
import React, { useState, useEffect } from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Orcamento } from '@/api/entities';
import { User } from '@/api/entities';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Scissors, Clock, Truck, CheckCircle, AlertTriangle, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from '@/components/ui/button'; // Added Button component import

const columnsConfig = {
  aguardando_producao: {
    id: 'aguardando_producao',
    title: 'Aguardando Produção',
    icon: <Clock className="w-5 h-5 text-yellow-600" />,
    color: 'bg-yellow-100',
  },
  em_producao: {
    id: 'em_producao',
    title: 'Em Produção',
    icon: <Scissors className="w-5 h-5 text-blue-600" />,
    color: 'bg-blue-100',
  },
  aguardando_entrega: {
    id: 'aguardando_entrega',
    title: 'Aguardando Entrega',
    icon: <Truck className="w-5 h-5 text-purple-600" />,
    color: 'bg-purple-100',
  },
  concluida: {
    id: 'concluida',
    title: 'Concluído',
    icon: <CheckCircle className="w-5 h-5 text-green-600" />,
    color: 'bg-green-100',
  },
};

const OrdemCard = ({ ordem, index, onStatusChange }) => (
  <Draggable draggableId={ordem.id} index={index}>
    {(provided, snapshot) => (
      <div
        ref={provided.innerRef}
        {...provided.draggableProps}
        {...provided.dragHandleProps}
        className={`mb-4 p-4 rounded-lg shadow-md bg-white border-l-4 cursor-pointer hover:shadow-lg transition-all ${
          snapshot.isDragging ? 'shadow-xl scale-105' : 'shadow-sm hover:shadow-md'
        } ${
          {
            aguardando_producao: 'border-yellow-500 hover:border-yellow-600',
            em_producao: 'border-blue-500 hover:border-blue-600',
            aguardando_entrega: 'border-purple-500 hover:border-purple-600',
            concluida: 'border-green-500 hover:border-green-600',
          }[ordem.status_venda] || 'border-gray-300 hover:border-gray-400'
        }`}
      >
        <Link 
          to={`${createPageUrl("ProducaoDetalhes")}?id=${ordem.id}`}
          className="block mb-3"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between mb-2">
            <h4 className="font-bold text-slate-800 hover:text-blue-600 transition-colors">
              #{ordem.numero || ordem.id.slice(-6)}
            </h4>
            <div className="flex items-center gap-2">
              <span className="text-xs px-2 py-1 bg-slate-100 rounded-full text-slate-600">
                {ordem.status_venda === 'aguardando_producao' ? 'Aguardando' : 
                 ordem.status_venda === 'em_producao' ? 'Produzindo' :
                 ordem.status_venda === 'aguardando_entrega' ? 'Pronto' :
                 'Concluído'}
              </span>
            </div>
          </div>
          
          <p className="text-sm text-slate-700 font-medium mb-1">{ordem.cliente_nome}</p>
          
          <div className="text-xs text-slate-500 space-y-1">
            <div className="flex items-center justify-between">
              <span>Venda: {format(new Date(ordem.data_orcamento), 'dd/MM/yy', { locale: ptBR })}</span>
              {/* Informação de valor removida */}
            </div>
            {ordem.prazo_entrega && (
              <p className="text-orange-600">
                📅 Prazo: {ordem.prazo_entrega}
              </p>
            )}
            {ordem.itens && ordem.itens.length > 0 && (
              <p className="text-slate-600">
                📦 {ordem.itens.length} item(s) • {ordem.itens.reduce((total, item) => total + (item.quantidade || 0), 0)} unid.
              </p>
            )}
          </div>
          
          <div className="mt-2 pt-2 border-t border-slate-100">
            <p className="text-xs text-blue-600 hover:text-blue-800 font-medium">
              → Clique para ver detalhes de produção
            </p>
          </div>
        </Link>

        {/* Botões de Ação */}
        <div className="flex gap-2 mt-3" onClick={(e) => e.stopPropagation()}>
          {ordem.status_venda === 'aguardando_producao' && (
            <Button
              size="sm"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onStatusChange(ordem.id, 'em_producao');
              }}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white text-xs py-1"
            >
              Iniciar Produção
            </Button>
          )}
          
          {ordem.status_venda === 'em_producao' && (
            <Button
              size="sm"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onStatusChange(ordem.id, 'aguardando_entrega');
              }}
              className="flex-1 bg-purple-600 hover:bg-purple-700 text-white text-xs py-1"
            >
              Pronto p/ Entrega
            </Button>
          )}
          
          {ordem.status_venda === 'aguardando_entrega' && (
            <Button
              size="sm"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onStatusChange(ordem.id, 'concluida');
              }}
              className="flex-1 bg-green-600 hover:bg-green-700 text-white text-xs py-1"
            >
              Marcar Concluído
            </Button>
          )}
          
          {ordem.status_venda === 'concluida' && (
            <div className="flex-1 text-center py-1">
              <span className="text-xs text-green-600 font-medium">✓ Concluído</span>
            </div>
          )}
        </div>
      </div>
    )}
  </Draggable>
);

const ProducaoColumn = ({ column, ordens, onStatusChange }) => (
  <div className={`flex flex-col w-full md:w-1/4 rounded-lg p-2 ${column.color}`}>
    <div className="flex items-center gap-2 p-3 mb-2">
      {column.icon}
      <h3 className="font-bold text-slate-800">{column.title}</h3>
      <Badge variant="secondary" className="ml-auto">{ordens.length}</Badge>
    </div>
    <Droppable droppableId={column.id}>
      {(provided, snapshot) => (
        <div
          ref={provided.innerRef}
          {...provided.droppableProps}
          className={`flex-grow p-2 rounded-lg transition-colors ${
            snapshot.isDraggingOver ? 'bg-gray-200/50' : ''
          }`}
          style={{ minHeight: '400px' }}
        >
          {ordens.map((ordem, index) => (
            <OrdemCard 
              key={ordem.id} 
              ordem={ordem} 
              index={index} 
              onStatusChange={onStatusChange}
            />
          ))}
          {provided.placeholder}
        </div>
      )}
    </Droppable>
  </div>
);

export default function Producao() {
  const [ordens, setOrdens] = useState([]);
  const [columns, setColumns] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [user, orcamentosAprovados] = await Promise.all([
        User.me(),
        Orcamento.filter({ status: 'aprovado' }, '-data_orcamento')
      ]);
      setCurrentUser(user);
      setOrdens(orcamentosAprovados || []);
      
      const initialColumns = Object.keys(columnsConfig).reduce((acc, key) => {
        acc[key] = [];
        return acc;
      }, {});

      (orcamentosAprovados || []).forEach(ordem => {
        const status = ordem.status_venda || 'aguardando_producao';
        if (initialColumns[status]) {
          initialColumns[status].push(ordem);
        } else {
            // Fallback for orders with old or invalid status
            initialColumns['aguardando_producao'].push(ordem);
        }
      });
      setColumns(initialColumns);

    } catch (error) {
      console.error("Erro ao carregar dados de produção:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const onDragEnd = async (result) => {
    const { source, destination, draggableId } = result;

    if (!destination || (source.droppableId === destination.droppableId)) {
      return;
    }
    
    // Check for edit permissions
    if (currentUser?.role !== 'admin' && !currentUser?.permissions?.includes('producao_edit')) {
        alert("Você não tem permissão para alterar o status de produção.");
        return;
    }

    const startColumn = columns[source.droppableId];
    const endColumn = columns[destination.droppableId];

    const newStartOrdens = Array.from(startColumn);
    const [movedOrdem] = newStartOrdens.splice(source.index, 1);
    const newEndOrdens = Array.from(endColumn);
    newEndOrdens.splice(destination.index, 0, movedOrdem);
    
    const newColumns = {
      ...columns,
      [source.droppableId]: newStartOrdens,
      [destination.droppableId]: newEndOrdens,
    };
    setColumns(newColumns);
    
    try {
      await Orcamento.update(draggableId, { status_venda: destination.droppableId });
      
      // Mostrar notificação de sucesso
      const statusNames = {
        aguardando_producao: 'Aguardando Produção',
        em_producao: 'Em Produção',
        aguardando_entrega: 'Aguardando Entrega',
        concluida: 'Concluída'
      };
      
      console.log(`Ordem movida para: ${statusNames[destination.droppableId]}`);
      
    } catch(error) {
      console.error("Erro ao atualizar status da ordem:", error);
      // Revert state on error
      setColumns(columns);
      alert("Ocorreu um erro ao atualizar o status. Tente novamente.");
    }
  };

  const handleStatusChange = async (ordemId, novoStatus) => {
    // Check for edit permissions
    if (currentUser?.role !== 'admin' && !currentUser?.permissions?.includes('producao_edit')) {
        alert("Você não tem permissão para alterar o status de produção.");
        return;
    }

    try {
      await Orcamento.update(ordemId, { status_venda: novoStatus });
      
      // Mostrar notificação de sucesso
      const statusNames = {
        aguardando_producao: 'Aguardando Produção',
        em_producao: 'Em Produção',
        aguardando_entrega: 'Aguardando Entrega',
        concluida: 'Concluída'
      };
      
      console.log(`Ordem movida para: ${statusNames[novoStatus]}`);
      
      // Recarregar dados para atualizar a interface
      loadData();
      
    } catch(error) {
      console.error("Erro ao atualizar status da ordem:", error);
      alert("Ocorreu um erro ao atualizar o status. Tente novamente.");
    }
  };
  
  if (isLoading) {
      return <div className="flex justify-center items-center h-64"><Loader2 className="w-8 h-8 animate-spin text-blue-600"/></div>
  }

  if (currentUser?.role !== 'admin' && !currentUser?.permissions?.includes('producao_view')) {
      return (
        <Alert variant="destructive" className="max-w-2xl mx-auto">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Acesso Negado</AlertTitle>
            <AlertDescription>Você não tem permissão para visualizar o controle de produção.</AlertDescription>
        </Alert>
      );
  }

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-slate-100 min-h-screen">
       <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Controle de Produção</h1>
          <p className="text-slate-600 mt-1">Gerencie o fluxo de trabalho dos pedidos aprovados.</p>
        </div>
      </div>
      
      <DragDropContext onDragEnd={onDragEnd}>
        <div className="flex flex-col md:flex-row gap-4 overflow-x-auto">
          {Object.values(columnsConfig).map(column => (
            <ProducaoColumn 
              key={column.id} 
              column={column}
              ordens={columns[column.id] || []}
              onStatusChange={handleStatusChange}
            />
          ))}
        </div>
      </DragDropContext>
    </div>
  );
}
