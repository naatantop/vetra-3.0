import React, { useState, Suspense, lazy } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar as CalendarIcon, Download } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { format, subDays } from "date-fns";
import { ptBR } from "date-fns/locale";

const RelatorioVendas = lazy(() => import('../components/relatorios/RelatorioVendas'));
const RelatorioFinanceiro = lazy(() => import('../components/relatorios/RelatorioFinanceiro'));
const RelatorioEstoque = lazy(() => import('../components/relatorios/RelatorioEstoque'));
const RelatorioClientes = lazy(() => import('../components/relatorios/RelatorioClientes'));

const ReportSuspenseLoader = () => (
    <div className="flex items-center justify-center h-96 bg-slate-50 rounded-lg">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
    </div>
);

export default function Relatorios() {
    const [dateRange, setDateRange] = useState({
        from: subDays(new Date(), 30),
        to: new Date(),
    });

    return (
        <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-slate-100 min-h-screen">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-slate-900">Central de Relatórios</h1>
                    <p className="text-slate-600 mt-1">Analise o desempenho do seu negócio</p>
                </div>
                <div className="flex gap-2">
                    <Popover>
                        <PopoverTrigger asChild>
                            <Button variant="outline" className="w-full md:w-auto justify-start text-left font-normal bg-white">
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {dateRange?.from ? (
                                    dateRange.to ? (
                                        <>
                                            {format(dateRange.from, "dd/MM/yy", { locale: ptBR })} - {format(dateRange.to, "dd/MM/yy", { locale: ptBR })}
                                        </>
                                    ) : (
                                        format(dateRange.from, "dd/MM/yy", { locale: ptBR })
                                    )
                                ) : (
                                    <span>Selecione a data</span>
                                )}
                            </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="end">
                            <Calendar
                                initialFocus
                                mode="range"
                                defaultMonth={dateRange?.from}
                                selected={dateRange}
                                onSelect={setDateRange}
                                numberOfMonths={2}
                                locale={ptBR}
                            />
                        </PopoverContent>
                    </Popover>
                    <Button>
                        <Download className="w-4 h-4 mr-2" />
                        Exportar
                    </Button>
                </div>
            </div>

            <Tabs defaultValue="vendas">
                <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 bg-white/80 backdrop-blur-sm shadow-sm">
                    <TabsTrigger value="vendas">Vendas</TabsTrigger>
                    <TabsTrigger value="financeiro">Financeiro</TabsTrigger>
                    <TabsTrigger value="estoque">Estoque</TabsTrigger>
                    <TabsTrigger value="clientes">Clientes</TabsTrigger>
                </TabsList>
                <Suspense fallback={<ReportSuspenseLoader />}>
                    <TabsContent value="vendas">
                        <RelatorioVendas dateRange={dateRange} />
                    </TabsContent>
                    <TabsContent value="financeiro">
                        <RelatorioFinanceiro dateRange={dateRange} />
                    </TabsContent>
                    <TabsContent value="estoque">
                        <RelatorioEstoque dateRange={dateRange} />
                    </TabsContent>
                    <TabsContent value="clientes">
                        <RelatorioClientes dateRange={dateRange} />
                    </TabsContent>
                </Suspense>
            </Tabs>
        </div>
    );
}