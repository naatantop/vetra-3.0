import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Building2, 
  Save, 
  Upload, 
  Phone, 
  Mail, 
  MapPin, 
  User as UserIcon,
  CheckCircle,
  AlertTriangle
} from "lucide-react";
import { ConfiguracaoEmpresa } from "@/api/entities";
import { UploadFile } from "@/api/integrations";
import { User } from "@/api/entities";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function CadastroInicial() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState({ type: "", text: "" });
  
  const [dadosEmpresa, setDadosEmpresa] = useState({
    nome_empresa: '',
    razao_social: '',
    cnpj: '',
    inscricao_estadual: '',
    endereco: {
      logradouro: '',
      numero: '',
      complemento: '',
      bairro: '',
      cidade: '',
      uf: '',
      cep: ''
    },
    telefone: '',
    telefone_secundario: '',
    email: '',
    website: '',
    logo_url: '',
    cor_primaria: '#3b82f6',
    cor_secundaria: '#1e40af'
  });

  const [dadosUsuario, setDadosUsuario] = useState({
    nome_completo: '',
    email: '',
    telefone: '',
    cargo: '',
    departamento: 'gerencia'
  });

  useEffect(() => {
    verificarCadastroExistente();
  }, []);

  const verificarCadastroExistente = async () => {
    try {
      const [configData, userData] = await Promise.all([
        ConfiguracaoEmpresa.list(),
        User.me().catch(() => null)
      ]);
      
      // Se já existe configuração da empresa, redireciona para dashboard
      if (configData && configData.length > 0) {
        navigate(createPageUrl("Dashboard"));
      }
    } catch (error) {
      console.error("Erro ao verificar cadastro:", error);
    }
  };

  const handleEmpresaChange = (field, value) => {
    if (field.includes('.')) {
      const [parent, child] = field.split('.');
      setDadosEmpresa(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent],
          [child]: value
        }
      }));
    } else {
      setDadosEmpresa(prev => ({ ...prev, [field]: value }));
    }
  };

  const handleUsuarioChange = (field, value) => {
    setDadosUsuario(prev => ({ ...prev, [field]: value }));
  };

  const handleLogoUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setMessage({ type: "error", text: "Por favor, selecione apenas arquivos de imagem." });
      return;
    }

    if (file.size > 5 * 1024 * 1024) { // 5MB
      setMessage({ type: "error", text: "A imagem deve ter no máximo 5MB." });
      return;
    }

    setUploading(true);
    try {
      const { file_url } = await UploadFile({ file });
      setDadosEmpresa(prev => ({ ...prev, logo_url: file_url }));
      setMessage({ type: "success", text: "Logo enviado com sucesso!" });
    } catch (error) {
      console.error("Erro ao fazer upload:", error);
      setMessage({ type: "error", text: "Erro ao enviar logo. Tente novamente." });
    } finally {
      setUploading(false);
    }
  };

  const validarStep1 = () => {
    if (!dadosEmpresa.nome_empresa.trim()) {
      setMessage({ type: "error", text: "Nome da empresa é obrigatório." });
      return false;
    }
    if (!dadosEmpresa.cnpj.trim()) {
      setMessage({ type: "error", text: "CNPJ é obrigatório." });
      return false;
    }
    if (!dadosEmpresa.telefone.trim()) {
      setMessage({ type: "error", text: "Telefone é obrigatório." });
      return false;
    }
    if (!dadosEmpresa.email.trim()) {
      setMessage({ type: "error", text: "Email da empresa é obrigatório." });
      return false;
    }
    return true;
  };

  const validarStep2 = () => {
    if (!dadosEmpresa.endereco.logradouro.trim()) {
      setMessage({ type: "error", text: "Endereço é obrigatório." });
      return false;
    }
    if (!dadosEmpresa.endereco.cidade.trim()) {
      setMessage({ type: "error", text: "Cidade é obrigatória." });
      return false;
    }
    if (!dadosEmpresa.endereco.uf.trim()) {
      setMessage({ type: "error", text: "UF é obrigatório." });
      return false;
    }
    return true;
  };

  const proximoStep = () => {
    setMessage({ type: "", text: "" });
    
    if (currentStep === 1 && !validarStep1()) return;
    if (currentStep === 2 && !validarStep2()) return;
    
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    }
  };

  const stepAnterior = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
    setMessage({ type: "", text: "" });
  };

  const finalizarCadastro = async () => {
    setSaving(true);
    setMessage({ type: "", text: "" });

    try {
      // Salvar configuração da empresa
      await ConfiguracaoEmpresa.create(dadosEmpresa);
      
      // Atualizar dados do usuário atual
      try {
        await User.updateMyUserData({
          phone: dadosUsuario.telefone,
          department: dadosUsuario.departamento,
          permissions: ['all'] // Admin inicial com todas as permissões
        });
      } catch (error) {
        console.log("Erro ao atualizar usuário:", error);
        // Continua mesmo se não conseguir atualizar o usuário
      }
      
      setMessage({ type: "success", text: "Cadastro realizado com sucesso! Redirecionando..." });
      
      setTimeout(() => {
        navigate(createPageUrl("Dashboard"));
      }, 2000);
      
    } catch (error) {
      console.error("Erro ao finalizar cadastro:", error);
      setMessage({ type: "error", text: "Erro ao salvar dados. Tente novamente." });
    } finally {
      setSaving(false);
    }
  };

  const formatCNPJ = (value) => {
    const numbers = value.replace(/\D/g, '');
    return numbers.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
  };

  const formatCEP = (value) => {
    const numbers = value.replace(/\D/g, '');
    return numbers.replace(/(\d{5})(\d{3})/, '$1-$2');
  };

  const formatPhone = (value) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length === 11) {
      return numbers.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
    }
    return numbers.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="h-16 w-16 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center text-white font-bold text-2xl shadow-lg">
              V
            </div>
          </div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Bem-vindo ao VETRA 2.0</h1>
          <p className="text-slate-600">Para começar, precisamos de algumas informações sobre sua empresa</p>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-center space-x-8">
            {[1, 2, 3].map((step) => (
              <div key={step} className="flex items-center">
                <div className={`h-10 w-10 rounded-full flex items-center justify-center font-semibold ${
                  currentStep >= step 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-200 text-gray-600'
                }`}>
                  {currentStep > step ? <CheckCircle className="w-5 h-5" /> : step}
                </div>
                {step < 3 && (
                  <div className={`w-16 h-1 mx-2 ${
                    currentStep > step ? 'bg-blue-600' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-2 px-5">
            <span className="text-sm text-slate-600">Dados da Empresa</span>
            <span className="text-sm text-slate-600">Endereço</span>
            <span className="text-sm text-slate-600">Finalização</span>
          </div>
        </div>

        {message.text && (
          <Alert variant={message.type === "error" ? "destructive" : "default"} className="mb-6">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>{message.text}</AlertDescription>
          </Alert>
        )}

        {/* Step 1: Dados da Empresa */}
        {currentStep === 1 && (
          <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-blue-600" />
                Informações da Empresa
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="nome_empresa">Nome da Empresa *</Label>
                  <Input
                    id="nome_empresa"
                    value={dadosEmpresa.nome_empresa}
                    onChange={(e) => handleEmpresaChange('nome_empresa', e.target.value)}
                    placeholder="Digite o nome da empresa"
                    className="h-12"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="razao_social">Razão Social</Label>
                  <Input
                    id="razao_social"
                    value={dadosEmpresa.razao_social}
                    onChange={(e) => handleEmpresaChange('razao_social', e.target.value)}
                    placeholder="Digite a razão social"
                    className="h-12"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="cnpj">CNPJ *</Label>
                  <Input
                    id="cnpj"
                    value={dadosEmpresa.cnpj}
                    onChange={(e) => handleEmpresaChange('cnpj', formatCNPJ(e.target.value))}
                    placeholder="00.000.000/0001-00"
                    maxLength={18}
                    className="h-12"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="inscricao_estadual">Inscrição Estadual</Label>
                  <Input
                    id="inscricao_estadual"
                    value={dadosEmpresa.inscricao_estadual}
                    onChange={(e) => handleEmpresaChange('inscricao_estadual', e.target.value)}
                    placeholder="123.456.789.012"
                    className="h-12"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="telefone">Telefone Principal *</Label>
                  <Input
                    id="telefone"
                    value={dadosEmpresa.telefone}
                    onChange={(e) => handleEmpresaChange('telefone', formatPhone(e.target.value))}
                    placeholder="(11) 1234-5678"
                    maxLength={15}
                    className="h-12"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email da Empresa *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={dadosEmpresa.email}
                    onChange={(e) => handleEmpresaChange('email', e.target.value)}
                    placeholder="contato@empresa.com.br"
                    className="h-12"
                  />
                </div>
              </div>

              {/* Logo Upload */}
              <div className="space-y-2">
                <Label>Logo da Empresa (opcional)</Label>
                <div className="flex items-center gap-4">
                  {dadosEmpresa.logo_url ? (
                    <img src={dadosEmpresa.logo_url} alt="Logo" className="h-16 w-auto border rounded" />
                  ) : (
                    <div className="h-16 w-16 bg-gray-100 border rounded flex items-center justify-center text-gray-400">
                      <Upload className="w-6 h-6" />
                    </div>
                  )}
                  <div>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleLogoUpload}
                      className="hidden"
                      id="logo-upload"
                    />
                    <Button
                      variant="outline"
                      onClick={() => document.getElementById('logo-upload').click()}
                      disabled={uploading}
                    >
                      {uploading ? (
                        <>
                          <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2" />
                          Enviando...
                        </>
                      ) : (
                        <>
                          <Upload className="w-4 h-4 mr-2" />
                          Escolher Logo
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </div>

              <div className="flex justify-end">
                <Button onClick={proximoStep} className="bg-blue-600 hover:bg-blue-700 px-8">
                  Próximo
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 2: Endereço */}
        {currentStep === 2 && (
          <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-green-600" />
                Endereço da Empresa
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="col-span-2 space-y-2">
                  <Label htmlFor="logradouro">Logradouro *</Label>
                  <Input
                    id="logradouro"
                    value={dadosEmpresa.endereco.logradouro}
                    onChange={(e) => handleEmpresaChange('endereco.logradouro', e.target.value)}
                    placeholder="Rua, Avenida..."
                    className="h-12"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="numero">Número</Label>
                  <Input
                    id="numero"
                    value={dadosEmpresa.endereco.numero}
                    onChange={(e) => handleEmpresaChange('endereco.numero', e.target.value)}
                    placeholder="123"
                    className="h-12"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="complemento">Complemento</Label>
                <Input
                  id="complemento"
                  value={dadosEmpresa.endereco.complemento}
                  onChange={(e) => handleEmpresaChange('endereco.complemento', e.target.value)}
                  placeholder="Sala, Andar..."
                  className="h-12"
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="bairro">Bairro</Label>
                  <Input
                    id="bairro"
                    value={dadosEmpresa.endereco.bairro}
                    onChange={(e) => handleEmpresaChange('endereco.bairro', e.target.value)}
                    placeholder="Centro"
                    className="h-12"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="cidade">Cidade *</Label>
                  <Input
                    id="cidade"
                    value={dadosEmpresa.endereco.cidade}
                    onChange={(e) => handleEmpresaChange('endereco.cidade', e.target.value)}
                    placeholder="São Paulo"
                    className="h-12"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="uf">UF *</Label>
                  <Input
                    id="uf"
                    value={dadosEmpresa.endereco.uf}
                    onChange={(e) => handleEmpresaChange('endereco.uf', e.target.value.toUpperCase())}
                    placeholder="SP"
                    maxLength={2}
                    className="h-12"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="cep">CEP</Label>
                <Input
                  id="cep"
                  value={dadosEmpresa.endereco.cep}
                  onChange={(e) => handleEmpresaChange('endereco.cep', formatCEP(e.target.value))}
                  placeholder="12345-678"
                  maxLength={9}
                  className="h-12"
                />
              </div>

              <div className="flex justify-between">
                <Button variant="outline" onClick={stepAnterior}>
                  Anterior
                </Button>
                <Button onClick={proximoStep} className="bg-blue-600 hover:bg-blue-700 px-8">
                  Próximo
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 3: Finalização */}
        {currentStep === 3 && (
          <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                Revisão e Finalização
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Resumo dos dados */}
              <div className="bg-slate-50 p-6 rounded-lg space-y-4">
                <h3 className="font-semibold text-slate-900">Resumo dos Dados</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium text-slate-800 mb-2">Empresa</h4>
                    <div className="space-y-1 text-sm text-slate-600">
                      <p><strong>Nome:</strong> {dadosEmpresa.nome_empresa}</p>
                      <p><strong>CNPJ:</strong> {dadosEmpresa.cnpj}</p>
                      <p><strong>Telefone:</strong> {dadosEmpresa.telefone}</p>
                      <p><strong>Email:</strong> {dadosEmpresa.email}</p>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-slate-800 mb-2">Endereço</h4>
                    <div className="space-y-1 text-sm text-slate-600">
                      <p>{dadosEmpresa.endereco.logradouro} {dadosEmpresa.endereco.numero}</p>
                      <p>{dadosEmpresa.endereco.bairro}</p>
                      <p>{dadosEmpresa.endereco.cidade} - {dadosEmpresa.endereco.uf}</p>
                      <p>CEP: {dadosEmpresa.endereco.cep}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Cores personalizadas */}
              <div className="space-y-4">
                <h3 className="font-semibold text-slate-900">Personalização Visual (opcional)</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="cor_primaria">Cor Primária</Label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        id="cor_primaria"
                        value={dadosEmpresa.cor_primaria}
                        onChange={(e) => handleEmpresaChange('cor_primaria', e.target.value)}
                        className="w-12 h-10 border rounded cursor-pointer"
                      />
                      <Input
                        value={dadosEmpresa.cor_primaria}
                        onChange={(e) => handleEmpresaChange('cor_primaria', e.target.value)}
                        placeholder="#3b82f6"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="cor_secundaria">Cor Secundária</Label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        id="cor_secundaria"
                        value={dadosEmpresa.cor_secundaria}
                        onChange={(e) => handleEmpresaChange('cor_secundaria', e.target.value)}
                        className="w-12 h-10 border rounded cursor-pointer"
                      />
                      <Input
                        value={dadosEmpresa.cor_secundaria}
                        onChange={(e) => handleEmpresaChange('cor_secundaria', e.target.value)}
                        placeholder="#1e40af"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-between">
                <Button variant="outline" onClick={stepAnterior}>
                  Anterior
                </Button>
                <Button 
                  onClick={finalizarCadastro} 
                  disabled={saving}
                  className="bg-green-600 hover:bg-green-700 px-8"
                >
                  {saving ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                      Finalizando...
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4 mr-2" />
                      Finalizar Cadastro
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}