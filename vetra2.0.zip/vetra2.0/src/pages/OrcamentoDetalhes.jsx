
import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Printer, FileDown, Calculator, FileText, MapPin, User, Calendar, CheckCircle, X, Scissors } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Orcamento } from "@/api/entities";
import { OrdemServico } from "@/api/entities";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function OrcamentoDetalhes() {
  const location = useLocation();
  const [orcamento, setOrcamento] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const orcamentoId = new URLSearchParams(location.search).get('id');
    if (orcamentoId) {
      loadOrcamentoData(orcamentoId);
    }
  }, [location]);

  const loadOrcamentoData = async (orcamentoId) => {
    try {
      setLoading(true);
      const orcamentoData = await Orcamento.list();
      const orcamentoEncontrado = orcamentoData.find(o => o.id === orcamentoId);
      setOrcamento(orcamentoEncontrado);
    } catch (error) {
      console.error("Erro ao carregar orçamento:", error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value) => {
    return (value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    try {
      return format(new Date(dateString), "dd/MM/yyyy", { locale: ptBR });
    } catch {
      return 'N/A';
    }
  };

  const formatPaymentMethod = (orcamento) => {
    if (!orcamento || !orcamento.metodo_pagamento) return 'N/A';

    const metodos = {
      cartao_credito: "Cartão de Crédito",
      pix: "PIX",
      dinheiro: "Dinheiro",
      boleto: "Boleto",
      a_combinar: "A Combinar"
    };

    let texto = metodos[orcamento.metodo_pagamento] || orcamento.metodo_pagamento;
    
    if (orcamento.metodo_pagamento === 'cartao_credito' && orcamento.parcelas > 1) {
      texto += ` em ${orcamento.parcelas}x`;
    }

    return texto;
  }

  const handlePrint = () => {
    window.print();
  };

  const handleApprovarOrcamento = async () => {
    if (window.confirm(`Aprovar orçamento ${orcamento.numero || `ORC-${orcamento.id?.slice(-6)}`}?`)) {
      try {
        // 1. Atualizar status do orçamento para aprovado
        await Orcamento.update(orcamento.id, { 
          status: 'aprovado',
          status_venda: 'aguardando_producao' 
        });

        // 2. Criar Ordem de Serviço automaticamente
        const novaOS = {
          numero: `OS-${Date.now()}`, // Simple unique number
          cliente_id: orcamento.cliente_id,
          cliente_nome: orcamento.cliente_nome,
          tipo_servico: 'instalacao', // Assuming default type
          status: 'agendado', // Default status for new OS
          data_agendada: new Date().toISOString().split('T')[0], // Today's date
          orcamento_origem_id: orcamento.id,
          endereco_servico: orcamento.endereco_instalacao || {}, // Copy installation address
          observacoes: `OS criada automaticamente a partir do orçamento ${orcamento.numero || `ORC-${orcamento.id?.slice(-6)}`}`,
          prioridade: 'media' // Default priority
        };

        await OrdemServico.create(novaOS);

        // Atualizar o orçamento na tela
        setOrcamento(prev => ({ ...prev, status: 'aprovado', status_venda: 'aguardando_producao' }));
        
        alert("Orçamento aprovado e Ordem de Serviço criada automaticamente!");
      } catch (error) {
        console.error('Erro ao aprovar orçamento:', error);
        alert('Erro ao aprovar orçamento. Tente novamente.');
      }
    }
  };

  const handleRejeitarOrcamento = async () => {
    if (window.confirm(`Rejeitar orçamento ${orcamento.numero || `ORC-${orcamento.id?.slice(-6)}`}?`)) {
      try {
        await Orcamento.update(orcamento.id, { status: 'rejeitado' });
        setOrcamento(prev => ({ ...prev, status: 'rejeitado' }));
        alert("Orçamento rejeitado.");
      } catch (error) {
        console.error('Erro ao rejeitar orçamento:', error);
        alert('Erro ao rejeitar orçamento. Tente novamente.');
      }
    }
  };

  if (loading) {
    return (
      <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50/50 via-blue-50/20 to-indigo-50/20 min-h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
      </div>
    );
  }

  if (!orcamento) {
    return (
      <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50/50 via-blue-50/20 to-indigo-50/20 min-h-full">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-slate-900 mb-4">Orçamento não encontrado</h1>
          <Link to={createPageUrl("Orcamentos")}>
            <Button variant="outline">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar para Orçamentos
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-slate-100 min-h-screen">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-4">
          <Link to={createPageUrl("Orcamentos")}>
            <Button variant="outline" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">
              Orçamento {orcamento.numero || `ORC-${orcamento.id?.slice(-6)}`}
            </h1>
            <div className="flex items-center gap-3 mt-1">
              <Badge className={`${getStatusColor(orcamento.status)} border`}>
                {getStatusLabel(orcamento.status)}
              </Badge>
              {orcamento.status_venda && (
                <Badge className="bg-blue-100 text-blue-800 border-blue-200">
                  {getStatusVendaLabel(orcamento.status_venda)}
                </Badge>
              )}
              {orcamento.status === 'aprovado' && (
                <Link to={createPageUrl("Producao")}>
                  <Button variant="outline" size="sm" className="text-blue-600 hover:text-blue-700">
                    <Scissors className="w-4 h-4 mr-2" />
                    Ver na Produção
                  </Button>
                </Link>
              )}
            </div>
          </div>
        </div>

        <div className="flex gap-2">
           <Button onClick={handlePrint} variant="outline">
              <Printer className="w-4 h-4 mr-2" />
              Imprimir
            </Button>
            <Link to={`${createPageUrl("OrcamentoPDF")}?id=${orcamento.id}`} target="_blank">
              <Button className="bg-blue-600 hover:bg-blue-700">
                <FileDown className="w-4 h-4 mr-2" />
                Gerar PDF
              </Button>
            </Link>
            
            {/* Botões de Aprovação - só aparecem se o status for 'enviado' */}
            {orcamento.status === 'enviado' && (
              <>
                <Button 
                  onClick={handleApprovarOrcamento}
                  className="bg-green-600 hover:bg-green-700 text-white"
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Aprovar
                </Button>
                <Button 
                  variant="outline" 
                  onClick={handleRejeitarOrcamento}
                  className="text-red-600 hover:text-red-700 hover:bg-red-50 border-red-300"
                >
                  <X className="w-4 h-4 mr-2" />
                  Rejeitar
                </Button>
              </>
            )}
        </div>
      </div>

      {/* Cabeçalho para impressão */}
      <div className="hidden print:block mb-6">
        <div className="text-center border-b pb-4 mb-6">
          <h1 className="text-2xl font-bold">ORÇAMENTO</h1>
          <p className="text-lg">Nº {orcamento.numero || `ORC-${orcamento.id?.slice(-6)}`}</p>
          <p className="text-sm text-gray-600 mt-2">
            Gerado em {format(new Date(), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
          </p>
        </div>
      </div>

      {/* Informações Básicas */}
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg print:shadow-none print:border print:border-gray-300">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            Informações do Orçamento
          </CardTitle>
        </CardHeader>
        <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <div>
                  <span className="font-semibold text-slate-700">Número:</span>
                  <span className="ml-2">{orcamento.numero || `ORC-${orcamento.id?.slice(-6)}`}</span>
                </div>
                <div>
                  <span className="font-semibold text-slate-700">Cliente:</span>
                  <span className="ml-2">{orcamento.cliente_nome}</span>
                </div>
                <div>
                  <span className="font-semibold text-slate-700">Vendedor:</span>
                  <span className="ml-2">{orcamento.vendedor}</span>
                </div>
                <div>
                  <span className="font-semibold text-slate-700">Status:</span>
                  <span className="ml-2">
                      <Badge className={getStatusColor(orcamento.status)}>{getStatusLabel(orcamento.status)}</Badge>
                  </span>
                </div>
              </div>
              <div className="space-y-3">
                <div>
                  <span className="font-semibold text-slate-700">Data do Orçamento:</span>
                  <span className="ml-2">{formatDate(orcamento.data_orcamento)}</span>
                </div>
                <div>
                  <span className="font-semibold text-slate-700">Data de Validade:</span>
                  <span className="ml-2">{formatDate(orcamento.data_validade)}</span>
                </div>
                <div>
                  <span className="font-semibold text-slate-700">Prazo de Entrega:</span>
                  <span className="ml-2">{orcamento.prazo_entrega || 'N/A'}</span>
                </div>
                <div>
                  <span className="font-semibold text-slate-700">Valor Total:</span>
                  <span className="ml-2 text-xl font-bold text-green-600">
                    {formatCurrency(orcamento.valor_final || orcamento.valor_total)}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
      </Card>

      {/* Itens do Orçamento */}
      {orcamento.itens && orcamento.itens.length > 0 && (
        <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg print:shadow-none print:border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="w-5 h-5 text-blue-600" />
              Itens do Orçamento
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-200">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Produto</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Medidas</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Cor/Acabamento</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Quantidade</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Preço Unit.</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Subtotal</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase">Observações</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-200">
                  {orcamento.itens.map((item, index) => (
                    <tr key={index}>
                      <td className="px-4 py-3 text-sm text-slate-900">{item.produto_nome}</td>
                      <td className="px-4 py-3 text-sm text-slate-600">
                        {(() => {
                          // Verificar tipo de medida do item
                          const tipoMedida = item.tipo_medida;
                          
                          if (tipoMedida === 'm2' && item.largura_mm && item.altura_mm) {
                            return <span>{item.largura_mm}mm × {item.altura_mm}mm</span>;
                          } else if ((tipoMedida === 'metro_linear' || tipoMedida === 'metro') && item.comprimento_mm) {
                            return <span>{item.comprimento_mm}mm</span>;
                          } else if (tipoMedida === 'unitario' || tipoMedida === 'unidade' || !tipoMedida) {
                            return <span>-</span>;
                          } else if (tipoMedida === 'kit') {
                            return <span>Kit</span>;
                          } else {
                            // Fallback - tentar mostrar qualquer medida disponível
                            if (item.largura_mm && item.altura_mm) {
                              return <span>{item.largura_mm}mm × {item.altura_mm}mm</span>;
                            } else if (item.comprimento_mm) {
                              return <span>{item.comprimento_mm}mm</span>;
                            } else {
                              return <span>-</span>;
                            }
                          }
                        })()}
                      </td>
                      <td className="px-4 py-3 text-sm text-slate-600">
                        <div className="space-y-1">
                          {item.cor_perfil && <div className="text-xs"><strong>Cor:</strong> {item.cor_perfil}</div>}
                          {item.acabamento && <div className="text-xs"><strong>Acab:</strong> {item.acabamento}</div>}
                          {!item.cor_perfil && !item.acabamento && <span>-</span>}
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-slate-600">{item.quantidade}</td>
                      <td className="px-4 py-3 text-sm text-slate-600">{formatCurrency(item.preco_unitario)}</td>
                      <td className="px-4 py-3 text-sm font-medium text-slate-900">{formatCurrency(item.subtotal)}</td>
                      <td className="px-4 py-3 text-sm text-slate-600">{item.observacoes || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            {/* Resumo Financeiro */}
            <div className="mt-6 border-t pt-4">
              <div className="flex justify-end">
                <div className="w-80 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Subtotal:</span>
                    <span className="font-medium">{formatCurrency(orcamento.valor_total)}</span>
                  </div>
                  {orcamento.desconto_valor > 0 && (
                    <div className="flex justify-between">
                      <span className="text-slate-600">Desconto:</span>
                      <span className="font-medium text-red-600">-{formatCurrency(orcamento.desconto_valor)}</span>
                    </div>
                  )}
                  <div className="border-t pt-2">
                    <div className="flex justify-between text-lg font-bold">
                      <span>Total:</span>
                      <span className="text-green-600">{formatCurrency(orcamento.valor_final || orcamento.valor_total)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Endereço de Instalação */}
      {orcamento.endereco_instalacao && Object.values(orcamento.endereco_instalacao).some(v => v) && (
        <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg print:shadow-none print:border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-blue-600" />
              Endereço de Instalação
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-1">
              {orcamento.endereco_instalacao.logradouro && (
                <p>{orcamento.endereco_instalacao.logradouro}{orcamento.endereco_instalacao.numero && `, ${orcamento.endereco_instalacao.numero}`}</p>
              )}
              {orcamento.endereco_instalacao.complemento && <p>{orcamento.endereco_instalacao.complemento}</p>}
              {orcamento.endereco_instalacao.bairro && <p>{orcamento.endereco_instalacao.bairro}</p>}
              {orcamento.endereco_instalacao.cidade && orcamento.endereco_instalacao.uf && (
                <p>{orcamento.endereco_instalacao.cidade} - {orcamento.endereco_instalacao.uf}</p>
              )}
              {orcamento.endereco_instalacao.cep && <p>CEP: {orcamento.endereco_instalacao.cep}</p>}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Condições e Observações */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg print:shadow-none print:border">
            <CardHeader>
              <CardTitle>Condições de Pagamento</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-semibold text-slate-800">{formatPaymentMethod(orcamento)}</p>
              {orcamento.observacoes_pagamento && (
                <p className="text-slate-700 whitespace-pre-line mt-2">{orcamento.observacoes_pagamento}</p>
              )}
            </CardContent>
          </Card>

        {orcamento.observacoes_gerais && (
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg print:shadow-none print:border">
            <CardHeader>
              <CardTitle>Observações Gerais</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-700 whitespace-pre-line">{orcamento.observacoes_gerais}</p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Rodapé para impressão */}
      <div className="hidden print:block mt-8 pt-4 border-t text-center text-sm text-gray-600">
        <p>Orçamento gerado pelo Sistema VETRA 2.0 - {format(new Date(), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}</p>
      </div>
    </div>
  );

  // Helper functions
  function getStatusLabel(status) {
    const statusConfig = {
      em_elaboracao: 'Em Elaboração',
      enviado: 'Enviado',
      aprovado: 'Aprovado',
      rejeitado: 'Rejeitado',
      vencido: 'Vencido'
    };
    return statusConfig[status] || status;
  }

  function getStatusColor(status) {
    const statusConfig = {
      em_elaboracao: 'bg-yellow-100 text-yellow-800',
      enviado: 'bg-blue-100 text-blue-800',
      aprovado: 'bg-green-100 text-green-800',
      rejeitado: 'bg-red-100 text-red-800',
      vencido: 'bg-gray-100 text-gray-800'
    };
    return statusConfig[status] || 'bg-gray-100 text-gray-800';
  }

  function getStatusVendaLabel(status) {
    const labels = {
      aguardando_producao: 'Aguardando Produção',
      em_producao: 'Em Produção',
      aguardando_entrega: 'Aguardando Entrega',
      concluida: 'Concluída'
    };
    return labels[status] || status;
  }
}
