
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Calculator, Search, Edit, Trash2, Eye, FileText, AlertTriangle, Filter, X, CheckCircle } from "lucide-react";
import { Orcamento } from "@/api/entities";
import { Cliente } from "@/api/entities";
import { User } from "@/api/entities";
import { OrdemServico } from "@/api/entities"; // Import the OrdemServico entity
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function Orcamentos() {
  const [orcamentos, setOrcamentos] = useState([]);
  const [filteredOrcamentos, setFilteredOrcamentos] = useState([]);
  const [clientes, setClientes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFiltro, setStatusFiltro] = useState('todos');
  const [showFilters, setShowFilters] = useState(false);
  const [message, setMessage] = useState({ type: "", text: "" });
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [orcamentos, searchTerm, statusFiltro]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [orcamentosData, clientesData, userData] = await Promise.all([
        Orcamento.list('-data_orcamento'),
        Cliente.list(),
        User.me().catch(() => null)
      ]);
      
      setOrcamentos(orcamentosData || []);
      setClientes(clientesData || []);
      setCurrentUser(userData);
      setMessage({ type: "", text: "" });
    } catch (error) {
      console.error("Erro ao carregar dados:", error);
      setMessage({ type: "error", text: "Erro ao carregar dados." });
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = orcamentos;
    
    if (statusFiltro !== 'todos') {
      filtered = filtered.filter(o => o.status === statusFiltro);
    }
    
    if (searchTerm) {
      const lowerCaseSearchTerm = searchTerm.toLowerCase();
      filtered = filtered.filter(o => 
        o.cliente_nome?.toLowerCase().includes(lowerCaseSearchTerm) ||
        o.numero?.toLowerCase().includes(lowerCaseSearchTerm) ||
        o.vendedor?.toLowerCase().includes(lowerCaseSearchTerm)
      );
    }
    
    setFilteredOrcamentos(filtered);
  };

  const handleDelete = async (orcamento) => {
    if (window.confirm(`Excluir orçamento ${orcamento.numero || `ORC-${orcamento.id.slice(-6)}`}?`)) {
      try {
        await Orcamento.delete(orcamento.id);
        setMessage({ type: "success", text: "Orçamento excluído com sucesso." });
        loadData();
      } catch (error) {
        console.error('Erro ao excluir:', error);
        setMessage({ type: "error", text: 'Erro ao excluir orçamento.' });
      }
    }
  };

  const handleApprovarOrcamento = async (orcamento) => {
    if (window.confirm(`Aprovar orçamento ${orcamento.numero || `ORC-${orcamento.id.slice(-6)}`}?`)) {
      try {
        // 1. Atualizar status do orçamento para aprovado
        await Orcamento.update(orcamento.id, { 
          status: 'aprovado',
          status_venda: 'aguardando_producao' 
        });

        // 2. Criar Ordem de Serviço automaticamente
        const novaOS = {
          numero: `OS-${Date.now()}`,
          cliente_id: orcamento.cliente_id,
          cliente_nome: orcamento.cliente_nome,
          tipo_servico: 'instalacao',
          status: 'agendado',
          data_agendada: new Date().toISOString().split('T')[0], // Data de hoje como placeholder
          orcamento_origem_id: orcamento.id,
          endereco_servico: orcamento.endereco_instalacao || {},
          observacoes: `OS criada automaticamente a partir do orçamento ${orcamento.numero || `ORC-${orcamento.id.slice(-6)}`}`,
          prioridade: 'media'
        };

        await OrdemServico.create(novaOS);

        setMessage({ type: "success", text: "Orçamento aprovado e Ordem de Serviço criada automaticamente!" });
        loadData();
      } catch (error) {
        console.error('Erro ao aprovar orçamento:', error);
        setMessage({ type: "error", text: 'Erro ao aprovar orçamento. Tente novamente.' });
      }
    }
  };

  const handleRejeitarOrcamento = async (orcamento) => {
    if (window.confirm(`Rejeitar orçamento ${orcamento.numero || `ORC-${orcamento.id.slice(-6)}`}?`)) {
      try {
        await Orcamento.update(orcamento.id, { status: 'rejeitado' });
        setMessage({ type: "success", text: "Orçamento rejeitado." });
        loadData();
      } catch (error) {
        console.error('Erro ao rejeitar orçamento:', error);
        setMessage({ type: "error", text: 'Erro ao rejeitar orçamento. Tente novamente.' });
      }
    }
  };

  const clearFilters = () => {
    setSearchTerm('');
    setStatusFiltro('todos');
    setShowFilters(false);
  };

  const formatCurrency = (value) => {
    return (value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    try {
      return format(new Date(dateString), "dd/MM/yyyy", { locale: ptBR });
    } catch {
      return 'N/A';
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      em_elaboracao: 'bg-amber-100 text-amber-800 border-amber-200',
      enviado: 'bg-blue-100 text-blue-800 border-blue-200',
      aprovado: 'bg-green-100 text-green-800 border-green-200',
      rejeitado: 'bg-red-100 text-red-800 border-red-200',
      vencido: 'bg-gray-100 text-gray-800 border-gray-200'
    };
    return colors[status] || 'bg-gray-100 text-gray-800 border-gray-200';
  };

  const getStatusLabel = (status) => {
    const labels = {
      em_elaboracao: 'Em Elaboração',
      enviado: 'Enviado',
      aprovado: 'Aprovado',
      rejeitado: 'Rejeitado',
      vencido: 'Vencido'
    };
    return labels[status] || status;
  };

  const totalOrcamentos = filteredOrcamentos.length;
  const valorTotal = filteredOrcamentos.reduce((sum, orc) => sum + (orc.valor_final || orc.valor_total || 0), 0);
  const aprovados = filteredOrcamentos.filter(orc => orc.status === 'aprovado');

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header Simplificado */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Orçamentos</h1>
          <p className="text-slate-600 text-sm">{totalOrcamentos} orçamentos encontrados</p>
        </div>
        <Link to={createPageUrl("NovoOrcamento")}>
          <Button className="bg-blue-600 hover:bg-blue-700 text-white shadow-md">
            <Plus className="w-4 h-4 mr-2" />
            Novo Orçamento
          </Button>
        </Link>
      </div>

      {/* Mensagem de Feedback */}
      {message.text && (
        <Alert variant={message.type === "error" ? "destructive" : "default"} className="border-l-4">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{message.text}</AlertDescription>
        </Alert>
      )}

      {/* Cards de Resumo Compactos */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-white shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Total</p>
                <p className="text-xl font-semibold text-slate-900">{totalOrcamentos}</p>
              </div>
              <Calculator className="w-8 h-8 text-blue-500 opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Valor Total</p>
                <p className="text-xl font-semibold text-green-600">{formatCurrency(valorTotal)}</p>
              </div>
              <FileText className="w-8 h-8 text-green-500 opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Aprovados</p>
                <p className="text-xl font-semibold text-purple-600">{aprovados.length}</p>
              </div>
              <Badge className="bg-purple-100 text-purple-800">{formatCurrency(aprovados.reduce((sum, orc) => sum + (orc.valor_final || orc.valor_total || 0), 0))}</Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Barra de Busca e Filtros */}
      <Card className="bg-white shadow-sm">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
              <Input
                placeholder="Buscar por cliente, número ou vendedor..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 border-slate-200"
              />
            </div>
            
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setShowFilters(!showFilters)}
                className={`${showFilters ? 'bg-blue-50 border-blue-200' : ''}`}
              >
                <Filter className="w-4 h-4 mr-2" />
                Filtros
              </Button>
              
              {(searchTerm || statusFiltro !== 'todos') && (
                <Button variant="outline" onClick={clearFilters} className="text-red-600 hover:text-red-700">
                  <X className="w-4 h-4 mr-2" />
                  Limpar
                </Button>
              )}
            </div>
          </div>
          
          {/* Filtros Expandidos */}
          {showFilters && (
            <div className="mt-4 pt-4 border-t border-slate-200">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Status</label>
                  <select
                    value={statusFiltro}
                    onChange={(e) => setStatusFiltro(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                  >
                    <option value="todos">Todos os Status</option>
                    <option value="em_elaboracao">Em Elaboração</option>
                    <option value="enviado">Enviado</option>
                    <option value="aprovado">Aprovado</option>
                    <option value="rejeitado">Rejeitado</option>
                    <option value="vencido">Vencido</option>
                  </select>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Lista de Orçamentos Simplificada */}
      <div className="space-y-4">
        {filteredOrcamentos.length === 0 ? (
          <Card className="bg-white shadow-sm">
            <CardContent className="p-12 text-center">
              <Calculator className="w-16 h-16 mx-auto mb-4 text-slate-300" />
              <h3 className="text-lg font-medium text-slate-900 mb-2">Nenhum orçamento encontrado</h3>
              <p className="text-slate-500 mb-6">
                {searchTerm || statusFiltro !== 'todos' 
                  ? 'Tente ajustar os filtros de busca.' 
                  : 'Crie seu primeiro orçamento para começar.'
                }
              </p>
              {!searchTerm && statusFiltro === 'todos' && (
                <Link to={createPageUrl("NovoOrcamento")}>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Criar Primeiro Orçamento
                  </Button>
                </Link>
              )}
            </CardContent>
          </Card>
        ) : (
          filteredOrcamentos.map((orcamento) => (
            <Card key={orcamento.id} className="bg-white shadow-sm hover:shadow-md transition-all duration-200 border-l-4 border-l-blue-500">
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold text-slate-900">
                        {orcamento.numero || `ORC-${orcamento.id.slice(-6)}`}
                      </h3>
                      <Badge className={`px-2 py-1 text-xs font-medium border ${getStatusColor(orcamento.status)}`}>
                        {getStatusLabel(orcamento.status)}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm text-slate-600">
                      <div>
                        <span className="font-medium">Cliente:</span>
                        <p className="text-slate-900">{orcamento.cliente_nome}</p>
                      </div>
                      <div>
                        <span className="font-medium">Vendedor:</span>
                        <p className="text-slate-900">{orcamento.vendedor}</p>
                      </div>
                      <div>
                        <span className="font-medium">Data:</span>
                        <p className="text-slate-900">{formatDate(orcamento.data_orcamento)}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                    <div className="text-right">
                      <p className="text-sm text-slate-600">Valor</p>
                      <p className="text-xl font-bold text-green-600">
                        {formatCurrency(orcamento.valor_final || orcamento.valor_total)}
                      </p>
                    </div>
                    
                    <div className="flex gap-2">
                      <Link to={`${createPageUrl("OrcamentoDetalhes")}?id=${orcamento.id}`}>
                        <Button variant="outline" size="sm" className="text-blue-600 hover:text-blue-700 hover:bg-blue-50">
                          <Eye className="w-4 h-4" />
                        </Button>
                      </Link>
                      <Link to={`${createPageUrl("EditarOrcamento")}?id=${orcamento.id}`}>
                        <Button variant="outline" size="sm" className="text-slate-600 hover:text-slate-700 hover:bg-slate-50">
                          <Edit className="w-4 h-4" />
                        </Button>
                      </Link>
                      
                      {/* Botões de Aprovação - só aparecem se o status for 'enviado' */}
                      {orcamento.status === 'enviado' && (
                        <>
                          <Button 
                            size="sm" 
                            onClick={() => handleApprovarOrcamento(orcamento)}
                            className="bg-green-600 hover:bg-green-700 text-white"
                          >
                            <CheckCircle className="w-4 h-4" />
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={() => handleRejeitarOrcamento(orcamento)}
                            className="text-red-600 hover:text-red-700 hover:bg-red-50 border-red-300"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </>
                      )}
                      
                      {currentUser?.role === 'admin' && (
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => handleDelete(orcamento)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
