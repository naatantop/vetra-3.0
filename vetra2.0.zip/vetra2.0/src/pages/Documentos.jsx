import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FolderOpen, FileText, Upload, Search, Download, Eye } from "lucide-react";
import { UploadFile } from "@/api/integrations";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function Documentos() {
  const [documentos, setDocumentos] = useState([
    // Documentos de exemplo
    {
      id: '1',
      nome: 'Catálogo de Produtos 2024.pdf',
      tipo: 'catalogo',
      tamanho: '2.5 MB',
      dataUpload: '2024-01-15',
      url: '#'
    },
    {
      id: '2',
      nome: 'Manual de Instalação Vidros.pdf',
      tipo: 'manual',
      tamanho: '1.8 MB',
      dataUpload: '2024-01-10',
      url: '#'
    },
    {
      id: '3',
      nome: 'Certificados de Qualidade.zip',
      tipo: 'certificado',
      tamanho: '5.2 MB',
      dataUpload: '2024-01-08',
      url: '#'
    }
  ]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [message, setMessage] = useState({ type: "", text: "" });

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const result = await UploadFile({ file });
      const novoDocumento = {
        id: Date.now().toString(),
        nome: file.name,
        tipo: 'documento',
        tamanho: (file.size / (1024 * 1024)).toFixed(1) + ' MB',
        dataUpload: new Date().toISOString().split('T')[0],
        url: result.file_url
      };
      setDocumentos(prev => [novoDocumento, ...prev]);
      setMessage({ type: "success", text: "Documento carregado com sucesso!" });
    } catch (error) {
      setMessage({ type: "error", text: "Erro ao carregar documento." });
    } finally {
      setIsUploading(false);
    }
  };

  const filteredDocumentos = documentos.filter(doc =>
    doc.nome.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getTipoIcon = (tipo) => {
    const icons = {
      catalogo: <FileText className="w-8 h-8 text-blue-500" />,
      manual: <FileText className="w-8 h-8 text-green-500" />,
      certificado: <FileText className="w-8 h-8 text-purple-500" />,
      documento: <FileText className="w-8 h-8 text-gray-500" />
    };
    return icons[tipo] || <FileText className="w-8 h-8 text-gray-500" />;
  };

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-slate-100 min-h-screen">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Central de Documentos</h1>
          <p className="text-slate-600 mt-1">Organize catálogos, manuais e certificados</p>
        </div>
        <div className="relative">
          <input
            type="file"
            onChange={handleFileUpload}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            disabled={isUploading}
          />
          <Button disabled={isUploading}>
            <Upload className="w-4 h-4 mr-2" />
            {isUploading ? 'Carregando...' : 'Novo Documento'}
          </Button>
        </div>
      </div>

      {message.text && (
        <Alert variant={message.type === "error" ? "destructive" : "default"}>
          <AlertDescription>{message.text}</AlertDescription>
        </Alert>
      )}

      <Card className="bg-white shadow-sm">
        <CardHeader>
          <CardTitle>Buscar Documentos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
            <Input
              placeholder="Buscar por nome do documento..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {filteredDocumentos.length === 0 ? (
        <Card className="bg-white shadow-sm">
          <CardContent className="p-12 text-center">
            <FolderOpen className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <h3 className="text-lg font-medium text-slate-900 mb-2">Nenhum documento encontrado</h3>
            <p className="text-slate-500">
              {searchTerm ? 'Tente ajustar os termos de busca.' : 'Faça upload do primeiro documento para começar.'}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDocumentos.map(documento => (
            <Card key={documento.id} className="bg-white shadow-sm hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  {getTipoIcon(documento.tipo)}
                  <div className="flex gap-2">
                    <Button variant="ghost" size="sm">
                      <Eye className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Download className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                <h3 className="font-medium text-slate-900 mb-2">{documento.nome}</h3>
                <div className="text-sm text-slate-500 space-y-1">
                  <p>Tamanho: {documento.tamanho}</p>
                  <p>Upload: {documento.dataUpload}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Card className="bg-white shadow-sm">
        <CardHeader>
          <CardTitle>Estatísticas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <p className="text-2xl font-bold text-blue-600">{documentos.length}</p>
              <p className="text-sm text-slate-600">Total de Documentos</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-green-600">
                {documentos.filter(d => d.tipo === 'catalogo').length}
              </p>
              <p className="text-sm text-slate-600">Catálogos</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-purple-600">
                {documentos.filter(d => d.tipo === 'manual').length}
              </p>
              <p className="text-sm text-slate-600">Manuais</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-orange-600">
                {documentos.filter(d => d.tipo === 'certificado').length}
              </p>
              <p className="text-sm text-slate-600">Certificados</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}