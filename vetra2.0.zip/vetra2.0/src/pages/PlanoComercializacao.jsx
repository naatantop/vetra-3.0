import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Rocket, FileText, ShoppingCart, DollarSign, CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const FeatureCard = ({ icon, title, description, status, linkTo, linkText }) => (
  <Card className="hover:shadow-lg transition-shadow">
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-lg font-medium">{title}</CardTitle>
      {icon}
    </CardHeader>
    <CardContent>
      <p className="text-sm text-slate-600 mb-4">{description}</p>
      <div className="flex items-center justify-between">
        <span className={`text-xs font-semibold px-2 py-1 rounded-full ${
          status === 'Pronto' 
            ? 'bg-green-100 text-green-800' 
            : 'bg-blue-100 text-blue-800'
        }`}>
          {status}
        </span>
        {linkTo && (
          <Link to={linkTo}>
            <Button variant="link" className="p-0 h-auto text-sm">{linkText}</Button>
          </Link>
        )}
      </div>
    </CardContent>
  </Card>
);

export default function PlanoComercializacao() {
  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-slate-100 min-h-screen">
      <div className="text-center mb-10">
        <Rocket className="w-16 h-16 mx-auto mb-4 text-blue-600" />
        <h1 className="text-4xl font-bold text-slate-900">Plano de Comercialização</h1>
        <p className="text-lg text-slate-600 mt-2 max-w-2xl mx-auto">
          Com os dados fiscais configurados, seu sistema está pronto para decolar. Aqui estão os próximos passos para automatizar seu processo de vendas.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
        <FeatureCard
          icon={<FileText className="w-6 h-6 text-slate-500" />}
          title="Fase 1: Nota Fiscal"
          description="Emita Notas Fiscais (NF-e) diretamente do sistema a partir de uma venda aprovada. Automatize a comunicação com a SEFAZ."
          status="Pronto"
          linkTo={createPageUrl("Vendas")}
          linkText="Ir para Vendas"
        />
        <FeatureCard
          icon={<ShoppingCart className="w-6 h-6 text-slate-500" />}
          title="Fase 2: Ciclo de Venda"
          description="Acompanhe o status de cada venda, desde a aprovação do orçamento, passando pela produção, até a entrega final ao cliente."
          status="Pronto"
          linkTo={createPageUrl("Vendas")}
          linkText="Ver Vendas"
        />
        <FeatureCard
          icon={<DollarSign className="w-6 h-6 text-slate-500" />}
          title="Fase 3: Financeiro"
          description="Integre as vendas ao financeiro. Cada venda aprovada gera automaticamente uma conta a receber, facilitando o controle de caixa."
          status="Próximo Passo"
        />
        <FeatureCard
          icon={<CheckCircle className="w-6 h-6 text-slate-500" />}
          title="Fase 4: Pós-Venda"
          description="Gerencie instalações, ordens de serviço e garantias vinculadas a cada venda, completando o ciclo de vida do cliente."
          status="Próximo Passo"
        />
      </div>
      
      <Card className="mt-8 bg-blue-600 text-white shadow-xl">
        <CardContent className="p-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h3 className="text-2xl font-bold">A Fase 1 já está implementada!</h3>
            <p className="opacity-90 mt-1">
              Você já pode emitir Notas Fiscais a partir da sua tela de Vendas.
            </p>
          </div>
          <Link to={createPageUrl("Vendas")}>
            <Button variant="secondary" size="lg" className="bg-white text-blue-700 hover:bg-blue-50">
              Vamos Começar!
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}