import React, { useState, useEffect } from "react";
import { OrdemServico } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, MapPin, User, Plus, Filter } from "lucide-react";
import { format, startOfWeek, addDays, isSameDay, parseISO } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Alert, AlertDescription } from "@/components/ui/alert";

const getStatusColor = (status) => {
  const colors = {
    agendado: 'bg-blue-100 text-blue-800 border-blue-200',
    em_andamento: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    concluido: 'bg-green-100 text-green-800 border-green-200',
    cancelado: 'bg-red-100 text-red-800 border-red-200'
  };
  return colors[status] || 'bg-gray-100 text-gray-800 border-gray-200';
};

const getStatusLabel = (status) => {
  const labels = {
    agendado: 'Agendado',
    em_andamento: 'Em Andamento',
    concluido: 'Concluído',
    cancelado: 'Cancelado'
  };
  return labels[status] || status;
};

export default function Agenda() {
  const [ordensServico, setOrdensServico] = useState([]);
  const [currentWeek, setCurrentWeek] = useState(new Date());
  const [isLoading, setIsLoading] = useState(true);
  const [message, setMessage] = useState({ type: "", text: "" });
  const [filtroStatus, setFiltroStatus] = useState('todos');

  useEffect(() => {
    loadOrdensServico();
  }, []);

  const loadOrdensServico = async () => {
    setIsLoading(true);
    try {
      const data = await OrdemServico.list('-data_agendada');
      setOrdensServico(data || []);
    } catch (error) {
      console.error("Erro ao carregar ordens de serviço:", error);
      setMessage({ type: "error", text: "Erro ao carregar agenda." });
    } finally {
      setIsLoading(false);
    }
  };

  const handleStatusChange = async (ordemId, novoStatus) => {
    try {
      await OrdemServico.update(ordemId, { status: novoStatus });
      setMessage({ type: "success", text: "Status atualizado com sucesso." });
      loadOrdensServico();
    } catch (error) {
      console.error("Erro ao atualizar status:", error);
      setMessage({ type: "error", text: "Erro ao atualizar status." });
    }
  };

  const getWeekDays = () => {
    const start = startOfWeek(currentWeek, { locale: ptBR });
    return Array.from({ length: 7 }, (_, i) => addDays(start, i));
  };

  const getOrdensForDay = (day) => {
    return ordensServico.filter(ordem => {
      const ordemDate = parseISO(ordem.data_agendada);
      const statusMatch = filtroStatus === 'todos' || ordem.status === filtroStatus;
      return isSameDay(ordemDate, day) && statusMatch;
    });
  };

  const previousWeek = () => {
    setCurrentWeek(prev => addDays(prev, -7));
  };

  const nextWeek = () => {
    setCurrentWeek(prev => addDays(prev, 7));
  };

  const weekDays = getWeekDays();

  if (isLoading) {
    return (
      <div className="p-6 text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-slate-100 min-h-screen">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Agenda de Serviços</h1>
          <p className="text-slate-600 mt-1">Gerencie instalações, medições e manutenções</p>
        </div>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          Nova OS
        </Button>
      </div>

      {message.text && (
        <Alert variant={message.type === "error" ? "destructive" : "default"}>
          <AlertDescription>{message.text}</AlertDescription>
        </Alert>
      )}

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div className="flex items-center gap-4">
          <Button variant="outline" onClick={previousWeek}>←</Button>
          <h2 className="text-xl font-semibold text-slate-800">
            {format(weekDays[0], "dd MMM", { locale: ptBR })} - {format(weekDays[6], "dd MMM yyyy", { locale: ptBR })}
          </h2>
          <Button variant="outline" onClick={nextWeek}>→</Button>
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-500" />
          <select 
            value={filtroStatus} 
            onChange={(e) => setFiltroStatus(e.target.value)}
            className="px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
          >
            <option value="todos">Todos os Status</option>
            <option value="agendado">Agendado</option>
            <option value="em_andamento">Em Andamento</option>
            <option value="concluido">Concluído</option>
            <option value="cancelado">Cancelado</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
        {weekDays.map((day, index) => {
          const ordensDay = getOrdensForDay(day);
          const isToday = isSameDay(day, new Date());

          return (
            <Card key={index} className={`bg-white shadow-sm ${isToday ? 'ring-2 ring-blue-500' : ''}`}>
              <CardHeader className="pb-3">
                <CardTitle className={`text-center ${isToday ? 'text-blue-600' : 'text-slate-700'}`}>
                  <div className="text-xs font-medium">
                    {format(day, "E", { locale: ptBR }).toUpperCase()}
                  </div>
                  <div className="text-lg font-bold">
                    {format(day, "dd", { locale: ptBR })}
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {ordensDay.length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-4">Sem agendamentos</p>
                ) : (
                  ordensDay.map(ordem => (
                    <div key={ordem.id} className="p-2 bg-slate-50 rounded-lg text-xs">
                      <div className="flex items-center justify-between mb-1">
                        <Badge className={`text-xs ${getStatusColor(ordem.status)}`}>
                          {getStatusLabel(ordem.status)}
                        </Badge>
                        <span className="font-medium text-slate-600">
                          {ordem.hora_agendada || '08:00'}
                        </span>
                      </div>
                      <p className="font-medium text-slate-800">{ordem.cliente_nome}</p>
                      <p className="text-slate-600">{ordem.tipo_servico}</p>
                      {ordem.tecnico_responsavel && (
                        <div className="flex items-center gap-1 mt-1">
                          <User className="w-3 h-3 text-slate-400" />
                          <span className="text-slate-500">{ordem.tecnico_responsavel}</span>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="bg-white shadow-sm">
        <CardHeader>
          <CardTitle>Resumo da Semana</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <p className="text-2xl font-bold text-blue-600">
                {ordensServico.filter(o => filtroStatus === 'todos' || o.status === filtroStatus).length}
              </p>
              <p className="text-sm text-slate-600">Total de OS</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-yellow-600">
                {ordensServico.filter(o => o.status === 'agendado').length}
              </p>
              <p className="text-sm text-slate-600">Agendadas</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-green-600">
                {ordensServico.filter(o => o.status === 'concluido').length}
              </p>
              <p className="text-sm text-slate-600">Concluídas</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-red-600">
                {ordensServico.filter(o => o.status === 'cancelado').length}
              </p>
              <p className="text-sm text-slate-600">Canceladas</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}