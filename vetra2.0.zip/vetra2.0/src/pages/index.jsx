import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Produtos from "./Produtos";

import Clientes from "./Clientes";

import Orcamentos from "./Orcamentos";

import Vendas from "./Vendas";

import Producao from "./Producao";

import Financeiro from "./Financeiro";

import Compras from "./Compras";

import Entregas from "./Entregas";

import Instalacoes from "./Instalacoes";

import Agenda from "./Agenda";

import Documentos from "./Documentos";

import Relatorios from "./Relatorios";

import Configuracoes from "./Configuracoes";

import Usuarios from "./Usuarios";

import ClienteDetalhes from "./ClienteDetalhes";

import OrcamentoDetalhes from "./OrcamentoDetalhes";

import OrcamentoPDF from "./OrcamentoPDF";

import NovoOrcamento from "./NovoOrcamento";

import ConfiguracaoEmpresa from "./ConfiguracaoEmpresa";

import CadastroInicial from "./CadastroInicial";

import PlanoComercializacao from "./PlanoComercializacao";

import EditarOrcamento from "./EditarOrcamento";

import Importacao from "./Importacao";

import ProducaoDetalhes from "./ProducaoDetalhes";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Produtos: Produtos,
    
    Clientes: Clientes,
    
    Orcamentos: Orcamentos,
    
    Vendas: Vendas,
    
    Producao: Producao,
    
    Financeiro: Financeiro,
    
    Compras: Compras,
    
    Entregas: Entregas,
    
    Instalacoes: Instalacoes,
    
    Agenda: Agenda,
    
    Documentos: Documentos,
    
    Relatorios: Relatorios,
    
    Configuracoes: Configuracoes,
    
    Usuarios: Usuarios,
    
    ClienteDetalhes: ClienteDetalhes,
    
    OrcamentoDetalhes: OrcamentoDetalhes,
    
    OrcamentoPDF: OrcamentoPDF,
    
    NovoOrcamento: NovoOrcamento,
    
    ConfiguracaoEmpresa: ConfiguracaoEmpresa,
    
    CadastroInicial: CadastroInicial,
    
    PlanoComercializacao: PlanoComercializacao,
    
    EditarOrcamento: EditarOrcamento,
    
    Importacao: Importacao,
    
    ProducaoDetalhes: ProducaoDetalhes,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Produtos" element={<Produtos />} />
                
                <Route path="/Clientes" element={<Clientes />} />
                
                <Route path="/Orcamentos" element={<Orcamentos />} />
                
                <Route path="/Vendas" element={<Vendas />} />
                
                <Route path="/Producao" element={<Producao />} />
                
                <Route path="/Financeiro" element={<Financeiro />} />
                
                <Route path="/Compras" element={<Compras />} />
                
                <Route path="/Entregas" element={<Entregas />} />
                
                <Route path="/Instalacoes" element={<Instalacoes />} />
                
                <Route path="/Agenda" element={<Agenda />} />
                
                <Route path="/Documentos" element={<Documentos />} />
                
                <Route path="/Relatorios" element={<Relatorios />} />
                
                <Route path="/Configuracoes" element={<Configuracoes />} />
                
                <Route path="/Usuarios" element={<Usuarios />} />
                
                <Route path="/ClienteDetalhes" element={<ClienteDetalhes />} />
                
                <Route path="/OrcamentoDetalhes" element={<OrcamentoDetalhes />} />
                
                <Route path="/OrcamentoPDF" element={<OrcamentoPDF />} />
                
                <Route path="/NovoOrcamento" element={<NovoOrcamento />} />
                
                <Route path="/ConfiguracaoEmpresa" element={<ConfiguracaoEmpresa />} />
                
                <Route path="/CadastroInicial" element={<CadastroInicial />} />
                
                <Route path="/PlanoComercializacao" element={<PlanoComercializacao />} />
                
                <Route path="/EditarOrcamento" element={<EditarOrcamento />} />
                
                <Route path="/Importacao" element={<Importacao />} />
                
                <Route path="/ProducaoDetalhes" element={<ProducaoDetalhes />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}