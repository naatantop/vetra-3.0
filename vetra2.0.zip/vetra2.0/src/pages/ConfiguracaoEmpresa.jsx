import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { 
  Building2, 
  Save, 
  Upload, 
  Phone, 
  Mail, 
  MapPin, 
  Globe, 
  Palette,
  FileText,
  Eye,
  Settings
} from "lucide-react";
import { ConfiguracaoEmpresa } from "@/api/entities";
import { UploadFile } from "@/api/integrations";
import { User } from "@/api/entities";

export default function ConfiguracaoEmpresaPage() {
  const [config, setConfig] = useState({
    nome_empresa: '',
    razao_social: '',
    cnpj: '',
    inscricao_estadual: '',
    endereco: {
      logradouro: '',
      numero: '',
      complemento: '',
      bairro: '',
      cidade: '',
      uf: '',
      cep: ''
    },
    telefone: '',
    telefone_secundario: '',
    email: '',
    website: '',
    logo_url: '',
    cor_primaria: '#3b82f6',
    cor_secundaria: '#1e40af'
  });

  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState({ type: "", text: "" });
  const [currentUser, setCurrentUser] = useState(null);
  const [previewMode, setPreviewMode] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [configData, userData] = await Promise.all([
        ConfiguracaoEmpresa.list(),
        User.me().catch(() => null)
      ]);
      
      if (configData?.[0]) {
        setConfig(configData[0]);
      }
      setCurrentUser(userData);
    } catch (error) {
      console.error("Erro ao carregar configuração:", error);
      setMessage({ type: "error", text: "Erro ao carregar configurações da empresa." });
    }
  };

  const handleInputChange = (field, value) => {
    if (field.includes('.')) {
      const [parent, child] = field.split('.');
      setConfig(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent],
          [child]: value
        }
      }));
    } else {
      setConfig(prev => ({ ...prev, [field]: value }));
    }
  };

  const handleLogoUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setMessage({ type: "error", text: "Por favor, selecione apenas arquivos de imagem." });
      return;
    }

    if (file.size > 5 * 1024 * 1024) { // 5MB
      setMessage({ type: "error", text: "A imagem deve ter no máximo 5MB." });
      return;
    }

    setUploading(true);
    try {
      const { file_url } = await UploadFile({ file });
      setConfig(prev => ({ ...prev, logo_url: file_url }));
      setMessage({ type: "success", text: "Logo enviado com sucesso!" });
    } catch (error) {
      console.error("Erro ao fazer upload:", error);
      setMessage({ type: "error", text: "Erro ao enviar logo. Tente novamente." });
    } finally {
      setUploading(false);
    }
  };

  const handleSave = async () => {
    if (!config.nome_empresa.trim()) {
      setMessage({ type: "error", text: "Nome da empresa é obrigatório." });
      return;
    }

    setSaving(true);
    setMessage({ type: "", text: "" });

    try {
      const existingConfig = await ConfiguracaoEmpresa.list();
      
      if (existingConfig?.[0]) {
        await ConfiguracaoEmpresa.update(existingConfig[0].id, config);
      } else {
        await ConfiguracaoEmpresa.create(config);
      }
      
      setMessage({ type: "success", text: "Configurações salvas com sucesso!" });
    } catch (error) {
      console.error("Erro ao salvar:", error);
      setMessage({ type: "error", text: "Erro ao salvar configurações. Tente novamente." });
    } finally {
      setSaving(false);
    }
  };

  const formatCNPJ = (value) => {
    const numbers = value.replace(/\D/g, '');
    return numbers.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
  };

  const formatCEP = (value) => {
    const numbers = value.replace(/\D/g, '');
    return numbers.replace(/(\d{5})(\d{3})/, '$1-$2');
  };

  const formatPhone = (value) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length === 11) {
      return numbers.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
    }
    return numbers.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
  };

  if (!currentUser || currentUser.role !== 'admin') {
    return (
      <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-slate-100 min-h-screen">
        <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
          <CardContent className="p-12">
            <div className="text-center text-slate-500">
              <Settings className="w-16 h-16 mx-auto mb-4 text-slate-300" />
              <h3 className="text-lg font-medium mb-2">Acesso Restrito</h3>
              <p>Apenas administradores podem acessar as configurações da empresa.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-50 to-slate-100 min-h-screen">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Configuração da Empresa</h1>
          <p className="text-slate-600 mt-1">
            Personalize as informações da sua empresa e customize o sistema
          </p>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={() => setPreviewMode(!previewMode)}
          >
            <Eye className="w-4 h-4 mr-2" />
            {previewMode ? 'Editar' : 'Visualizar'}
          </Button>
          <Button 
            onClick={handleSave} 
            disabled={saving}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {saving ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                Salvando...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                Salvar Configurações
              </>
            )}
          </Button>
        </div>
      </div>

      {message.text && (
        <Alert variant={message.type === "error" ? "destructive" : "default"}>
          <AlertDescription>{message.text}</AlertDescription>
        </Alert>
      )}

      {previewMode ? (
        // Preview Mode
        <Card className="bg-white shadow-lg">
          <CardHeader className="border-b" style={{ backgroundColor: config.cor_primaria + '10' }}>
            <CardTitle className="flex items-center gap-3">
              {config.logo_url ? (
                <img src={config.logo_url} alt="Logo" className="h-12 w-auto" />
              ) : (
                <div 
                  className="h-12 w-12 rounded-lg flex items-center justify-center text-white font-bold"
                  style={{ backgroundColor: config.cor_primaria }}
                >
                  {config.nome_empresa?.charAt(0) || 'E'}
                </div>
              )}
              <div>
                <h2 className="text-xl font-bold">{config.nome_empresa || 'Nome da Empresa'}</h2>
                <p className="text-sm text-slate-600">{config.razao_social || 'Razão Social'}</p>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <Building2 className="w-4 h-4" style={{ color: config.cor_primaria }} />
                  Dados Corporativos
                </h3>
                <div className="space-y-2 text-sm">
                  {config.cnpj && <p><strong>CNPJ:</strong> {config.cnpj}</p>}
                  {config.inscricao_estadual && <p><strong>I.E.:</strong> {config.inscricao_estadual}</p>}
                </div>
              </div>
              
              <div>
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <Phone className="w-4 h-4" style={{ color: config.cor_primaria }} />
                  Contato
                </h3>
                <div className="space-y-2 text-sm">
                  {config.telefone && <p><strong>Tel:</strong> {config.telefone}</p>}
                  {config.telefone_secundario && <p><strong>Tel 2:</strong> {config.telefone_secundario}</p>}
                  {config.email && <p><strong>Email:</strong> {config.email}</p>}
                  {config.website && <p><strong>Site:</strong> {config.website}</p>}
                </div>
              </div>
              
              <div>
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <MapPin className="w-4 h-4" style={{ color: config.cor_primaria }} />
                  Endereço
                </h3>
                <div className="space-y-1 text-sm">
                  {config.endereco.logradouro && (
                    <p>{config.endereco.logradouro} {config.endereco.numero}</p>
                  )}
                  {config.endereco.complemento && <p>{config.endereco.complemento}</p>}
                  {config.endereco.bairro && <p>{config.endereco.bairro}</p>}
                  {config.endereco.cidade && config.endereco.uf && (
                    <p>{config.endereco.cidade} - {config.endereco.uf}</p>
                  )}
                  {config.endereco.cep && <p>CEP: {config.endereco.cep}</p>}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        // Edit Mode
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Informações Básicas */}
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-blue-600" />
                Informações da Empresa
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="nome_empresa">Nome da Empresa *</Label>
                <Input
                  id="nome_empresa"
                  value={config.nome_empresa}
                  onChange={(e) => handleInputChange('nome_empresa', e.target.value)}
                  placeholder="Digite o nome da empresa"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="razao_social">Razão Social</Label>
                <Input
                  id="razao_social"
                  value={config.razao_social}
                  onChange={(e) => handleInputChange('razao_social', e.target.value)}
                  placeholder="Digite a razão social"
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="cnpj">CNPJ</Label>
                  <Input
                    id="cnpj"
                    value={config.cnpj}
                    onChange={(e) => handleInputChange('cnpj', formatCNPJ(e.target.value))}
                    placeholder="00.000.000/0001-00"
                    maxLength={18}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="inscricao_estadual">Inscrição Estadual</Label>
                  <Input
                    id="inscricao_estadual"
                    value={config.inscricao_estadual}
                    onChange={(e) => handleInputChange('inscricao_estadual', e.target.value)}
                    placeholder="123.456.789.012"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Logo e Cores */}
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Palette className="w-5 h-5 text-purple-600" />
                Visual e Identidade
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Logo da Empresa</Label>
                <div className="flex items-center gap-4">
                  {config.logo_url ? (
                    <img src={config.logo_url} alt="Logo" className="h-16 w-auto border rounded" />
                  ) : (
                    <div className="h-16 w-16 bg-gray-100 border rounded flex items-center justify-center text-gray-400">
                      <Upload className="w-6 h-6" />
                    </div>
                  )}
                  <div>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleLogoUpload}
                      className="hidden"
                      id="logo-upload"
                    />
                    <Button
                      variant="outline"
                      onClick={() => document.getElementById('logo-upload').click()}
                      disabled={uploading}
                    >
                      {uploading ? (
                        <>
                          <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2" />
                          Enviando...
                        </>
                      ) : (
                        <>
                          <Upload className="w-4 h-4 mr-2" />
                          Escolher Logo
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="cor_primaria">Cor Primária</Label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      id="cor_primaria"
                      value={config.cor_primaria}
                      onChange={(e) => handleInputChange('cor_primaria', e.target.value)}
                      className="w-12 h-10 border rounded cursor-pointer"
                    />
                    <Input
                      value={config.cor_primaria}
                      onChange={(e) => handleInputChange('cor_primaria', e.target.value)}
                      placeholder="#3b82f6"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="cor_secundaria">Cor Secundária</Label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      id="cor_secundaria"
                      value={config.cor_secundaria}
                      onChange={(e) => handleInputChange('cor_secundaria', e.target.value)}
                      className="w-12 h-10 border rounded cursor-pointer"
                    />
                    <Input
                      value={config.cor_secundaria}
                      onChange={(e) => handleInputChange('cor_secundaria', e.target.value)}
                      placeholder="#1e40af"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Contato */}
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Phone className="w-5 h-5 text-green-600" />
                Informações de Contato
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="telefone">Telefone Principal</Label>
                  <Input
                    id="telefone"
                    value={config.telefone}
                    onChange={(e) => handleInputChange('telefone', formatPhone(e.target.value))}
                    placeholder="(11) 1234-5678"
                    maxLength={15}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="telefone_secundario">Telefone Secundário</Label>
                  <Input
                    id="telefone_secundario"
                    value={config.telefone_secundario}
                    onChange={(e) => handleInputChange('telefone_secundario', formatPhone(e.target.value))}
                    placeholder="(11) 9876-5432"
                    maxLength={15}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={config.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  placeholder="contato@empresa.com.br"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="website">Website</Label>
                <Input
                  id="website"
                  value={config.website}
                  onChange={(e) => handleInputChange('website', e.target.value)}
                  placeholder="www.empresa.com.br"
                />
              </div>
            </CardContent>
          </Card>

          {/* Endereço */}
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-red-600" />
                Endereço da Empresa
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="col-span-2 space-y-2">
                  <Label htmlFor="logradouro">Logradouro</Label>
                  <Input
                    id="logradouro"
                    value={config.endereco.logradouro}
                    onChange={(e) => handleInputChange('endereco.logradouro', e.target.value)}
                    placeholder="Rua, Avenida..."
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="numero">Número</Label>
                  <Input
                    id="numero"
                    value={config.endereco.numero}
                    onChange={(e) => handleInputChange('endereco.numero', e.target.value)}
                    placeholder="123"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="complemento">Complemento</Label>
                <Input
                  id="complemento"
                  value={config.endereco.complemento}
                  onChange={(e) => handleInputChange('endereco.complemento', e.target.value)}
                  placeholder="Sala, Andar..."
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="bairro">Bairro</Label>
                  <Input
                    id="bairro"
                    value={config.endereco.bairro}
                    onChange={(e) => handleInputChange('endereco.bairro', e.target.value)}
                    placeholder="Centro"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="cep">CEP</Label>
                  <Input
                    id="cep"
                    value={config.endereco.cep}
                    onChange={(e) => handleInputChange('endereco.cep', formatCEP(e.target.value))}
                    placeholder="12345-678"
                    maxLength={9}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div className="col-span-2 space-y-2">
                  <Label htmlFor="cidade">Cidade</Label>
                  <Input
                    id="cidade"
                    value={config.endereco.cidade}
                    onChange={(e) => handleInputChange('endereco.cidade', e.target.value)}
                    placeholder="São Paulo"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="uf">UF</Label>
                  <Input
                    id="uf"
                    value={config.endereco.uf}
                    onChange={(e) => handleInputChange('endereco.uf', e.target.value.toUpperCase())}
                    placeholder="SP"
                    maxLength={2}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Informações sobre impacto */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-6">
          <div className="flex items-start gap-3">
            <FileText className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <h3 className="font-semibold text-blue-900 mb-2">Como essas informações são usadas</h3>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• <strong>Orçamentos:</strong> Logo, nome e dados da empresa aparecem automaticamente</li>
                <li>• <strong>Dashboard:</strong> Cores e logo personalizam a interface</li>
                <li>• <strong>Documentos:</strong> Informações de contato no rodapé</li>
                <li>• <strong>Sistema:</strong> Identidade visual aplicada em todo o sistema</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}