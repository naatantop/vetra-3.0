import React, { useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Upload, FileText, CheckCircle, AlertTriangle, Loader2, ArrowLeft, ArrowRight, Download } from 'lucide-react';
import { useDropzone } from 'react-dropzone';
import Papa from 'papaparse';
import { Cliente } from '@/api/entities';
import { Produto } from '@/api/entities';

const entityConfig = {
  clientes: {
    name: 'Clientes',
    entity: Cliente,
    template: 'nome,tipo,documento,email,telefone,logradouro,numero,complemento,bairro,cidade,uf,cep,observacoes\n',
    requiredFields: ['nome', 'tipo'],
  },
  produtos: {
    name: 'Produtos',
    entity: Produto,
    template: 'codigo,nome,categoria,unidade,preco_custo,preco_venda,estoque_atual,estoque_minimo\n',
    requiredFields: ['codigo', 'nome', 'categoria', 'unidade'],
  },
};

export default function ImportacaoWizard({ tipo, onCancel }) {
  const [step, setStep] = useState(1);
  const [file, setFile] = useState(null);
  const [headers, setHeaders] = useState([]);
  const [data, setData] = useState([]);
  const [mapping, setMapping] = useState({});
  const [systemFields, setSystemFields] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [importResult, setImportResult] = useState(null);

  const config = entityConfig[tipo];

  const onDrop = useCallback((acceptedFiles) => {
    const uploadedFile = acceptedFiles[0];
    setFile(uploadedFile);
    Papa.parse(uploadedFile, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        setHeaders(results.meta.fields);
        setData(results.data);
        fetchSystemFields();
        setStep(2);
      },
    });
  }, [tipo]);

  const fetchSystemFields = async () => {
    const schema = await config.entity.schema();
    setSystemFields(Object.keys(schema.properties));
  };
  
  const handleMappingChange = (header, field) => {
    setMapping(prev => ({ ...prev, [header]: field }));
  };

  const handleNextToPreview = () => {
    // Validação do mapeamento
    const mappedSystemFields = Object.values(mapping);
    const missingFields = config.requiredFields.filter(f => !mappedSystemFields.includes(f));
    if (missingFields.length > 0) {
      alert(`Os seguintes campos obrigatórios não foram mapeados: ${missingFields.join(', ')}`);
      return;
    }
    setStep(3);
  };
  
  const handleImport = async () => {
    setIsLoading(true);
    setImportResult(null);

    const dataToImport = data.map(row => {
      const newRow = {};
      for (const header in mapping) {
        const systemField = mapping[header];
        if (systemField) {
          newRow[systemField] = row[header];
        }
      }
      return newRow;
    });

    try {
      // Usar bulkCreate quando disponível, por enquanto, iterar
      let successCount = 0;
      let errorCount = 0;
      
      for(const record of dataToImport) {
          try {
              // Limpeza e conversão de tipos
              if(record.preco_custo) record.preco_custo = parseFloat(record.preco_custo.replace(',', '.'));
              if(record.preco_venda) record.preco_venda = parseFloat(record.preco_venda.replace(',', '.'));
              if(record.estoque_atual) record.estoque_atual = parseInt(record.estoque_atual, 10);
              if(record.estoque_minimo) record.estoque_minimo = parseInt(record.estoque_minimo, 10);
              
              await config.entity.create(record);
              successCount++;
          } catch (e) {
              console.error("Erro ao importar registro:", record, e);
              errorCount++;
          }
      }
      
      setImportResult({ success: successCount, error: errorCount });
    } catch (error) {
      console.error("Erro na importação em massa:", error);
      setImportResult({ success: 0, error: dataToImport.length });
    }
    
    setIsLoading(false);
    setStep(4);
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop, accept: { 'text/csv': ['.csv'] } });
  
  const downloadTemplate = () => {
    const blob = new Blob([config.template], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `modelo_${tipo}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <Card className="bg-white/90 backdrop-blur-sm shadow-xl">
      <CardHeader>
        <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
                <Upload className="w-5 h-5 text-blue-600" />
                Importar {config.name}
            </CardTitle>
            <Button variant="ghost" onClick={onCancel}><ArrowLeft className="w-4 h-4 mr-2" /> Voltar</Button>
        </div>
      </CardHeader>
      <CardContent>
        {/* Step 1: Upload */}
        {step === 1 && (
            <div>
                 <Button variant="outline" onClick={downloadTemplate} className="mb-4">
                    <Download className="w-4 h-4 mr-2" /> Baixar Modelo CSV
                </Button>
                <div {...getRootProps()} className={`p-10 border-2 border-dashed rounded-lg text-center cursor-pointer ${isDragActive ? 'border-blue-500 bg-blue-50' : 'border-slate-300'}`}>
                    <input {...getInputProps()} />
                    <Upload className="w-12 h-12 mx-auto text-slate-400 mb-4" />
                    {isDragActive ? (
                        <p>Solte o arquivo aqui...</p>
                    ) : (
                        <p>Arraste e solte o arquivo CSV aqui, ou clique para selecionar.</p>
                    )}
                </div>
            </div>
        )}

        {/* Step 2: Mapping */}
        {step === 2 && (
          <div>
            <h3 className="font-semibold mb-4">Mapeie as colunas da sua planilha para os campos do sistema.</h3>
            <Alert className="mb-4">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Campos Obrigatórios</AlertTitle>
                <AlertDescription>Certifique-se de mapear os seguintes campos: {config.requiredFields.join(', ')}.</AlertDescription>
            </Alert>
            <div className="space-y-4">
              {headers.map(header => (
                <div key={header} className="grid grid-cols-2 gap-4 items-center">
                  <span className="font-medium text-slate-700">{header}</span>
                  <Select onValueChange={(value) => handleMappingChange(header, value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione um campo do sistema" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>Ignorar esta coluna</SelectItem>
                      {systemFields.map(field => (
                        <SelectItem key={field} value={field}>{field}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ))}
            </div>
            <div className="mt-6 flex justify-end">
              <Button onClick={handleNextToPreview}>
                Visualizar Importação <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        )}

        {/* Step 3: Preview */}
        {step === 3 && (
            <div>
                <h3 className="font-semibold mb-4">Pré-visualização dos dados</h3>
                <p className="text-sm text-slate-600 mb-4">Revise os primeiros 5 registros para garantir que o mapeamento está correto.</p>
                <div className="overflow-x-auto rounded-lg border">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                {Object.values(mapping).filter(v => v).map(field => <TableHead key={field}>{field}</TableHead>)}
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {data.slice(0, 5).map((row, rowIndex) => (
                                <TableRow key={rowIndex}>
                                    {headers.map(header => {
                                        const systemField = mapping[header];
                                        if (systemField) {
                                            return <TableCell key={header}>{row[header]}</TableCell>;
                                        }
                                        return null;
                                    })}
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </div>
                 <div className="mt-6 flex justify-between">
                    <Button variant="outline" onClick={() => setStep(2)}><ArrowLeft className="w-4 h-4 mr-2" /> Voltar</Button>
                    <Button onClick={handleImport} disabled={isLoading}>
                        {isLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <CheckCircle className="w-4 h-4 mr-2" />}
                        Confirmar e Importar
                    </Button>
                </div>
            </div>
        )}
        
        {/* Step 4: Result */}
        {step === 4 && (
            <div className="text-center p-8">
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-slate-800 mb-2">Importação Concluída!</h3>
                <p className="text-slate-600 mb-6">Veja o resumo da sua importação abaixo.</p>
                <div className="grid grid-cols-2 gap-4 max-w-sm mx-auto">
                    <Card>
                        <CardHeader className="pb-2"><CardTitle className="text-lg">Sucesso</CardTitle></CardHeader>
                        <CardContent><p className="text-3xl font-bold text-green-600">{importResult?.success || 0}</p></CardContent>
                    </Card>
                     <Card>
                        <CardHeader className="pb-2"><CardTitle className="text-lg">Falhas</CardTitle></CardHeader>
                        <CardContent><p className="text-3xl font-bold text-red-600">{importResult?.error || 0}</p></CardContent>
                    </Card>
                </div>
                <div className="mt-8">
                    <Button onClick={onCancel}>Finalizar</Button>
                </div>
            </div>
        )}
      </CardContent>
    </Card>
  );
}