import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { BarChart3, FileText, TrendingUp, Users } from "lucide-react";

const formatCurrency = (value) => {
  return (value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
};

export default function ReportsCard({ stats, isLoading }) {
  if (isLoading) {
    return (
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Skeleton className="h-16" />
            <Skeleton className="h-16" />
          </div>
          <Skeleton className="h-10 w-full" />
        </CardContent>
      </Card>
    );
  }

  const reports = [
    {
      title: "Faturamento",
      value: formatCurrency(stats.receitasMes),
      icon: TrendingUp,
      color: "text-emerald-600"
    },
    {
      title: "Clientes",
      value: stats.totalClientes,
      icon: Users,
      color: "text-blue-600"
    },
    {
      title: "Produtos",
      value: stats.totalProdutos,
      icon: FileText,
      color: "text-purple-600"
    },
    {
      title: "Meta",
      value: `${stats.progressoMeta.toFixed(0)}%`,
      icon: BarChart3,
      color: "text-amber-600"
    }
  ];

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-lg font-bold text-slate-900">
          <FileText className="w-5 h-5 text-slate-600" />
          Relatórios Rápidos
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          {reports.map((report, index) => (
            <div key={index} className="p-3 bg-slate-50 rounded-lg">
              <div className="flex items-center gap-2 mb-1">
                <report.icon className={`w-4 h-4 ${report.color}`} />
                <span className="text-xs font-medium text-slate-600">{report.title}</span>
              </div>
              <p className="font-bold text-slate-900">{report.value}</p>
            </div>
          ))}
        </div>
        
        <Button variant="outline" className="w-full">
          <BarChart3 className="w-4 h-4 mr-2" />
          Ver Relatórios Completos
        </Button>
      </CardContent>
    </Card>
  );
}