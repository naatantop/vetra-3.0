import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calculator, Clock, User, DollarSign } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format, differenceInDays } from "date-fns";

export default function OrcamentosPendentes({ orcamentos, isLoading }) {
  const orcamentosPendentes = orcamentos.filter(orcamento => 
    orcamento.status === 'em_elaboracao' || orcamento.status === 'enviado'
  );

  const getStatusColor = (status) => {
    const colors = {
      'em_elaboracao': 'bg-amber-100 text-amber-800 border-amber-200',
      'enviado': 'bg-blue-100 text-blue-800 border-blue-200'
    };
    return colors[status] || 'bg-gray-100 text-gray-800 border-gray-200';
  };

  const getStatusIcon = (status) => {
    const icons = {
      'em_elaboracao': Clock,
      'enviado': Clock
    };
    const IconComponent = icons[status] || Clock;
    return <IconComponent className="w-3 h-3" />;
  };

  const getDiasRestantes = (dataValidade) => {
    const hoje = new Date();
    const validade = new Date(dataValidade);
    const dias = differenceInDays(validade, hoje);
    return dias;
  };

  const getUrgenciaColor = (dias) => {
    if (dias < 0) return 'text-red-600';
    if (dias <= 3) return 'text-orange-600';
    if (dias <= 7) return 'text-yellow-600';
    return 'text-slate-600';
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value || 0);
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
      <CardHeader className="pb-4">
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center gap-2 text-lg font-bold text-slate-900">
            <Calculator className="w-5 h-5 text-purple-600" />
            Orçamentos Pendentes
          </CardTitle>
          {orcamentosPendentes.length > 0 && (
            <Badge className="bg-purple-100 text-purple-800 border-purple-200">
              {orcamentosPendentes.length} pendentes
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <div key={i} className="p-4 bg-slate-50/80 rounded-xl">
                <div className="flex justify-between items-start mb-2">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-5 w-20 rounded-full" />
                </div>
                <Skeleton className="h-4 w-32 mb-2" />
                <div className="flex justify-between">
                  <Skeleton className="h-3 w-16" />
                  <Skeleton className="h-4 w-20" />
                </div>
              </div>
            ))}
          </div>
        ) : orcamentosPendentes.length === 0 ? (
          <div className="text-center py-8 text-slate-500">
            <Calculator className="w-12 h-12 mx-auto mb-4 text-emerald-300" />
            <p className="font-medium text-emerald-600">Nenhum orçamento pendente!</p>
            <p className="text-sm">Todos os orçamentos foram finalizados</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-80 overflow-y-auto">
            {orcamentosPendentes.map((orcamento) => {
              const diasRestantes = getDiasRestantes(orcamento.data_validade);
              return (
                <div key={orcamento.id} className="p-4 bg-slate-50/80 rounded-xl hover:bg-slate-100/80 transition-colors duration-200 border border-slate-200/60">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center gap-2">
                      <Calculator className="w-4 h-4 text-purple-600" />
                      <div>
                        <p className="font-semibold text-slate-900">#{orcamento.numero}</p>
                        <p className="text-sm text-slate-600">{orcamento.cliente_nome}</p>
                      </div>
                    </div>
                    <Badge className={`${getStatusColor(orcamento.status)} border flex items-center gap-1`}>
                      {getStatusIcon(orcamento.status)}
                      <span className="capitalize">{orcamento.status?.replace('_', ' ')}</span>
                    </Badge>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2 text-slate-600">
                        <User className="w-4 h-4" />
                        <span>{orcamento.vendedor}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <DollarSign className="w-4 h-4 text-green-600" />
                        <span className="font-semibold text-slate-900">
                          {formatCurrency(orcamento.valor_final)}
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-600">
                        Criado: {format(new Date(orcamento.data_orcamento), 'dd/MM/yyyy')}
                      </span>
                      <div className={`font-medium ${getUrgenciaColor(diasRestantes)}`}>
                        {diasRestantes < 0 
                          ? 'Vencido' 
                          : diasRestantes === 0
                          ? 'Vence hoje'
                          : `${diasRestantes} dias restantes`
                        }
                      </div>
                    </div>
                  </div>

                  {diasRestantes <= 3 && (
                    <div className="mt-3 p-2 bg-orange-50 rounded-lg border border-orange-200">
                      <p className="text-xs text-orange-700 font-medium">
                        ⚠️ Atenção: Orçamento próximo do vencimento
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}