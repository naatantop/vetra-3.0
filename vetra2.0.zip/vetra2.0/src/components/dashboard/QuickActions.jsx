import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Calculator, Scissors, Truck, DollarSign } from "lucide-react";

export default function QuickActions() {
  const actions = [
    {
      title: "Novo Orçamento",
      description: "Criar orçamento",
      icon: Calculator,
      color: "bg-blue-500/10 text-blue-600",
      action: () => console.log("Novo orçamento")
    },
    {
      title: "Ordem Produção",
      description: "Iniciar produção",
      icon: Scissors,
      color: "bg-emerald-500/10 text-emerald-600",
      action: () => console.log("Nova produção")
    },
    {
      title: "Agendar Entrega",
      description: "Nova entrega",
      icon: Truck,
      color: "bg-purple-500/10 text-purple-600",
      action: () => console.log("Nova entrega")
    },
    {
      title: "Lançar Receita",
      description: "Financeiro",
      icon: DollarSign,
      color: "bg-amber-500/10 text-amber-600",
      action: () => console.log("Nova receita")
    }
  ];

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-lg font-bold text-slate-900">
          <Plus className="w-5 h-5 text-blue-600" />
          Ações Rápidas
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {actions.map((action, index) => (
            <Button
              key={index}
              variant="ghost"
              className="flex items-center gap-3 p-4 h-auto justify-start hover:bg-slate-50 transition-colors"
              onClick={action.action}
            >
              <div className={`p-2 rounded-lg ${action.color}`}>
                <action.icon className="w-5 h-5" />
              </div>
              <div className="text-left">
                <p className="font-medium text-slate-900">{action.title}</p>
                <p className="text-xs text-slate-600">{action.description}</p>
              </div>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}