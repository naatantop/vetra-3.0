import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertTriangle, Package, DollarSign } from "lucide-react";

export default function PendingTasks({ lowStock, pendingFinancials, isLoading }) {
  if (isLoading) {
    return (
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent className="space-y-4">
          {[1, 2, 3].map(i => (
            <Skeleton key={i} className="h-16 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-lg font-bold text-slate-900">
          <AlertTriangle className="w-5 h-5 text-amber-600" />
          Tarefas Pendentes
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Estoque Baixo */}
          {lowStock.length > 0 && (
            <div className="p-4 bg-amber-50 rounded-lg border border-amber-200">
              <div className="flex items-center gap-2 mb-2">
                <Package className="w-4 h-4 text-amber-600" />
                <span className="font-medium text-amber-800">Estoque Baixo</span>
                <Badge className="bg-amber-100 text-amber-800">
                  {lowStock.length}
                </Badge>
              </div>
              <div className="space-y-1">
                {lowStock.slice(0, 3).map(produto => (
                  <p key={produto.id} className="text-sm text-amber-700">
                    {produto.nome} - {produto.estoque_atual || 0} {produto.unidade}
                  </p>
                ))}
                {lowStock.length > 3 && (
                  <p className="text-xs text-amber-600">
                    +{lowStock.length - 3} outros produtos
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Contas Pendentes */}
          {pendingFinancials.length > 0 && (
            <div className="p-4 bg-red-50 rounded-lg border border-red-200">
              <div className="flex items-center gap-2 mb-2">
                <DollarSign className="w-4 h-4 text-red-600" />
                <span className="font-medium text-red-800">Contas Pendentes</span>
                <Badge className="bg-red-100 text-red-800">
                  {pendingFinancials.length}
                </Badge>
              </div>
              <div className="space-y-1">
                {pendingFinancials.slice(0, 3).map(conta => (
                  <p key={conta.id} className="text-sm text-red-700">
                    {conta.descricao} - R$ {conta.valor.toFixed(2)}
                  </p>
                ))}
                {pendingFinancials.length > 3 && (
                  <p className="text-xs text-red-600">
                    +{pendingFinancials.length - 3} outras contas
                  </p>
                )}
              </div>
            </div>
          )}

          {lowStock.length === 0 && pendingFinancials.length === 0 && (
            <p className="text-slate-500 text-center py-8">Nenhuma tarefa pendente</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}