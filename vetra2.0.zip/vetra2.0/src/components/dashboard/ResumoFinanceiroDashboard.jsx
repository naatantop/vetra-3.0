import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DollarSign, TrendingUp, TrendingDown, AlertCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { isPast, isToday, isWithinInterval, subDays } from "date-fns";

const formatCurrency = (value) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(value || 0);
};

export default function ResumoFinanceiroDashboard({ lancamentos, isLoading }) {
  if (isLoading) {
    return (
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Skeleton className="h-20" />
            <Skeleton className="h-20" />
          </div>
          <Skeleton className="h-16" />
        </CardContent>
      </Card>
    );
  }

  const receitas = lancamentos.filter(l => l.tipo === 'receita');
  const despesas = lancamentos.filter(l => l.tipo === 'despesa');

  // Contas a receber pendentes
  const receitasPendentes = receitas.filter(r => r.status === 'pendente' || r.status === 'atrasado');
  const totalReceber = receitasPendentes.reduce((acc, curr) => acc + curr.valor, 0);

  // Contas a pagar pendentes
  const despesasPendentes = despesas.filter(d => d.status === 'pendente' || d.status === 'atrasado');
  const totalPagar = despesasPendentes.reduce((acc, curr) => acc + curr.valor, 0);

  // Fluxo de caixa (saldo)
  const saldoFluxo = totalReceber - totalPagar;

  // Contas vencidas
  const contasVencidas = [...receitasPendentes, ...despesasPendentes].filter(conta => 
    isPast(new Date(conta.data_vencimento)) && !isToday(new Date(conta.data_vencimento))
  );

  // Contas que vencem nos próximos 7 dias
  const hoje = new Date();
  const seteDiasFrente = new Date();
  seteDiasFrente.setDate(hoje.getDate() + 7);
  
  const contasProximoVencimento = [...receitasPendentes, ...despesasPendentes].filter(conta =>
    isWithinInterval(new Date(conta.data_vencimento), { start: hoje, end: seteDiasFrente })
  );

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-lg font-bold text-slate-900">
          <DollarSign className="w-5 h-5 text-emerald-600" />
          Resumo Financeiro
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Cards de Resumo */}
        <div className="grid grid-cols-2 gap-4">
          <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-4 h-4 text-emerald-600" />
              <span className="text-sm font-medium text-emerald-700">A Receber</span>
            </div>
            <p className="text-xl font-bold text-emerald-800">{formatCurrency(totalReceber)}</p>
            <p className="text-xs text-emerald-600">{receitasPendentes.length} contas</p>
          </div>

          <div className="p-4 bg-red-50 rounded-xl border border-red-200">
            <div className="flex items-center gap-2 mb-2">
              <TrendingDown className="w-4 h-4 text-red-600" />
              <span className="text-sm font-medium text-red-700">A Pagar</span>
            </div>
            <p className="text-xl font-bold text-red-800">{formatCurrency(totalPagar)}</p>
            <p className="text-xs text-red-600">{despesasPendentes.length} contas</p>
          </div>
        </div>

        {/* Saldo do Fluxo */}
        <div className={`p-4 rounded-xl border ${
          saldoFluxo >= 0 
            ? 'bg-blue-50 border-blue-200' 
            : 'bg-orange-50 border-orange-200'
        }`}>
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium text-slate-700">Saldo Projetado</span>
            <span className={`text-lg font-bold ${
              saldoFluxo >= 0 ? 'text-blue-800' : 'text-orange-800'
            }`}>
              {formatCurrency(saldoFluxo)}
            </span>
          </div>
        </div>

        {/* Alertas */}
        <div className="space-y-2">
          {contasVencidas.length > 0 && (
            <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg border border-red-200">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-600" />
                <span className="text-sm font-medium text-red-700">Contas Vencidas</span>
              </div>
              <Badge className="bg-red-100 text-red-800 border-red-200">
                {contasVencidas.length}
              </Badge>
            </div>
          )}

          {contasProximoVencimento.length > 0 && (
            <div className="flex items-center justify-between p-3 bg-amber-50 rounded-lg border border-amber-200">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-amber-600" />
                <span className="text-sm font-medium text-amber-700">Vencimento em 7 dias</span>
              </div>
              <Badge className="bg-amber-100 text-amber-800 border-amber-200">
                {contasProximoVencimento.length}
              </Badge>
            </div>
          )}
        </div>

        {/* Próximas Movimentações */}
        <div className="pt-2 border-t border-slate-200">
          <h4 className="text-sm font-semibold text-slate-700 mb-2">Próximas Movimentações</h4>
          <div className="space-y-2 max-h-32 overflow-y-auto">
            {[...receitasPendentes, ...despesasPendentes]
              .sort((a, b) => new Date(a.data_vencimento) - new Date(b.data_vencimento))
              .slice(0, 4)
              .map((conta) => (
                <div key={conta.id} className="flex justify-between items-center text-sm">
                  <div className="flex items-center gap-2">
                    {conta.tipo === 'receita' ? (
                      <TrendingUp className="w-3 h-3 text-emerald-500" />
                    ) : (
                      <TrendingDown className="w-3 h-3 text-red-500" />
                    )}
                    <span className="text-slate-600 truncate max-w-32">
                      {conta.descricao}
                    </span>
                  </div>
                  <span className={`font-medium ${
                    conta.tipo === 'receita' ? 'text-emerald-600' : 'text-red-600'
                  }`}>
                    {formatCurrency(conta.valor)}
                  </span>
                </div>
              ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}