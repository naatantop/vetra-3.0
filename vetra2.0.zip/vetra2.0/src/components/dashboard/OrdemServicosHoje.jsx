import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, MapPin, User, AlertCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function OrdemServicosHoje({ ordensServico, isLoading }) {
  const getPrioridadeColor = (prioridade) => {
    const colors = {
      'baixa': 'bg-gray-100 text-gray-800 border-gray-200',
      'media': 'bg-blue-100 text-blue-800 border-blue-200',
      'alta': 'bg-orange-100 text-orange-800 border-orange-200',
      'urgente': 'bg-red-100 text-red-800 border-red-200'
    };
    return colors[prioridade] || 'bg-gray-100 text-gray-800 border-gray-200';
  };

  const getTipoServicoIcon = (tipo) => {
    const icons = {
      'instalacao': '🔧',
      'manutencao': '⚙️',
      'medicao': '📏',
      'orcamento': '📋'
    };
    return icons[tipo] || '📋';
  };

  const getPrioridadeIcon = (prioridade) => {
    if (prioridade === 'urgente' || prioridade === 'alta') {
      return <AlertCircle className="w-3 h-3" />;
    }
    return null;
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-lg font-bold text-slate-900">
          <Clock className="w-5 h-5 text-blue-600" />
          Ordens de Serviço - Hoje
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <div key={i} className="p-4 bg-slate-50/80 rounded-xl">
                <div className="flex justify-between items-start mb-2">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-5 w-16 rounded-full" />
                </div>
                <Skeleton className="h-4 w-32 mb-2" />
                <Skeleton className="h-3 w-40" />
              </div>
            ))}
          </div>
        ) : ordensServico.length === 0 ? (
          <div className="text-center py-8 text-slate-500">
            <Clock className="w-12 h-12 mx-auto mb-4 text-slate-300" />
            <p className="font-medium">Nenhuma ordem de serviço para hoje</p>
            <p className="text-sm">Todas as atividades do dia foram concluídas</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-80 overflow-y-auto">
            {ordensServico.map((ordem) => (
              <div key={ordem.id} className="p-4 bg-slate-50/80 rounded-xl hover:bg-slate-100/80 transition-colors duration-200 border border-slate-200/60">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{getTipoServicoIcon(ordem.tipo_servico)}</span>
                    <div>
                      <p className="font-semibold text-slate-900">#{ordem.numero}</p>
                      <p className="text-sm text-slate-600">{ordem.cliente_nome}</p>
                    </div>
                  </div>
                  <Badge className={`${getPrioridadeColor(ordem.prioridade)} border flex items-center gap-1`}>
                    {getPrioridadeIcon(ordem.prioridade)}
                    <span className="capitalize">{ordem.prioridade}</span>
                  </Badge>
                </div>
                
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2 text-slate-600">
                    <Clock className="w-4 h-4" />
                    <span>{ordem.hora_agendada}</span>
                    <span className="mx-1">•</span>
                    <span className="capitalize">{ordem.tipo_servico}</span>
                  </div>
                  
                  {ordem.tecnico_responsavel && (
                    <div className="flex items-center gap-2 text-slate-600">
                      <User className="w-4 h-4" />
                      <span>{ordem.tecnico_responsavel}</span>
                    </div>
                  )}
                  
                  {ordem.endereco_servico && (
                    <div className="flex items-center gap-2 text-slate-600">
                      <MapPin className="w-4 h-4" />
                      <span className="truncate">
                        {ordem.endereco_servico.logradouro}, {ordem.endereco_servico.numero} - {ordem.endereco_servico.bairro}
                      </span>
                    </div>
                  )}
                </div>
                
                {ordem.observacoes && (
                  <div className="mt-3 p-2 bg-blue-50 rounded-lg">
                    <p className="text-xs text-slate-600">{ordem.observacoes}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}