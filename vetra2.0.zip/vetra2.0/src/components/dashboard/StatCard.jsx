import React from 'react';
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";

export default function StatCard({ 
  title, 
  value, 
  icon: Icon, 
  color = "blue", 
  trend, 
  isLoading, 
  progress,
  onDelete
}) {
  if (isLoading) {
    return (
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
        <CardHeader className="pb-3">
          <Skeleton className="h-4 w-24" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-8 w-16 mb-2" />
          <Skeleton className="h-3 w-32" />
        </CardContent>
      </Card>
    );
  }

  const colorClasses = {
    blue: "from-blue-500 to-indigo-500 text-blue-600",
    green: "from-emerald-500 to-teal-500 text-emerald-600",
    purple: "from-violet-500 to-purple-500 text-violet-600",
    orange: "from-amber-500 to-orange-500 text-amber-600",
    red: "from-red-500 to-rose-500 text-red-600",
    yellow: "from-yellow-500 to-amber-500 text-yellow-600"
  };

  const bgColorClasses = {
    blue: "bg-blue-500/10",
    green: "bg-emerald-500/10",
    purple: "bg-violet-500/10",
    orange: "bg-amber-500/10",
    red: "bg-red-500/10",
    yellow: "bg-yellow-500/10"
  };

  return (
    <Card className="relative overflow-hidden bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg hover:shadow-xl transition-all duration-300">
      <div className={`absolute top-0 right-0 w-20 h-20 transform translate-x-6 -translate-y-6 bg-gradient-to-br ${colorClasses[color]} rounded-full opacity-10`} />
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <h3 className="text-sm font-medium text-slate-600">{title}</h3>
            <div className="text-2xl font-bold text-slate-900 mt-2">{value}</div>
            {trend && (
              <p className="text-xs text-slate-500 mt-1">{trend}</p>
            )}
          </div>
          <div className="flex items-center gap-2">
            <div className={`p-3 ${bgColorClasses[color]} rounded-xl`}>
              <Icon className={`w-5 h-5 ${colorClasses[color].split(' ')[2]}`} />
            </div>
            {onDelete && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onDelete}
                className="text-red-500 hover:text-red-700 hover:bg-red-50 p-2"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      {progress !== undefined && (
        <CardContent className="pt-0">
          <div className="w-full bg-slate-200 rounded-full h-2">
            <div 
              className={`bg-gradient-to-r ${colorClasses[color].split(' ').slice(0, 2).join(' ')} h-2 rounded-full transition-all duration-500`}
              style={{ width: `${Math.min(progress, 100)}%` }}
            ></div>
          </div>
        </CardContent>
      )}
    </Card>
  );
}