import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { DollarSign, TrendingUp, TrendingDown } from "lucide-react";

const formatCurrency = (value) => {
  return (value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
};

export default function FinancialOverview({ receitas, despesas, isLoading }) {
  if (isLoading) {
    return (
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Skeleton className="h-20" />
            <Skeleton className="h-20" />
          </div>
          <Skeleton className="h-16" />
        </CardContent>
      </Card>
    );
  }

  const saldo = receitas - despesas;
  const margemLucro = receitas > 0 ? ((saldo / receitas) * 100) : 0;

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-lg font-bold text-slate-900">
          <DollarSign className="w-5 h-5 text-emerald-600" />
          Visão Financeira
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-4 h-4 text-emerald-600" />
              <span className="text-sm font-medium text-emerald-700">Receitas</span>
            </div>
            <p className="text-xl font-bold text-emerald-800">{formatCurrency(receitas)}</p>
          </div>

          <div className="p-4 bg-red-50 rounded-xl border border-red-200">
            <div className="flex items-center gap-2 mb-2">
              <TrendingDown className="w-4 h-4 text-red-600" />
              <span className="text-sm font-medium text-red-700">Despesas</span>
            </div>
            <p className="text-xl font-bold text-red-800">{formatCurrency(despesas)}</p>
          </div>
        </div>

        <div className={`p-4 rounded-xl border ${
          saldo >= 0 
            ? 'bg-blue-50 border-blue-200' 
            : 'bg-orange-50 border-orange-200'
        }`}>
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-slate-700">Saldo do Mês</span>
            <span className="text-xs text-slate-600">
              Margem: {margemLucro.toFixed(1)}%
            </span>
          </div>
          <p className={`text-2xl font-bold ${
            saldo >= 0 ? 'text-blue-800' : 'text-orange-800'
          }`}>
            {formatCurrency(saldo)}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}