import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Package } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";

export default function AlertaEstoqueBaixo({ produtos, isLoading }) {
  const produtosEstoqueBaixo = produtos.filter(produto => 
    (produto.estoque_atual || 0) <= (produto.estoque_minimo || 0)
  );

  const getCategoriaColor = (categoria) => {
    const colors = {
      'vidro_temperado': 'bg-blue-100 text-blue-800 border-blue-200',
      'vidro_laminado': 'bg-purple-100 text-purple-800 border-purple-200',
      'vidro_comum': 'bg-gray-100 text-gray-800 border-gray-200',
      'esquadria_aluminio': 'bg-cyan-100 text-cyan-800 border-cyan-200',
      'esquadria_ferro': 'bg-orange-100 text-orange-800 border-orange-200',
      'acessorios': 'bg-green-100 text-green-800 border-green-200',
      'ferragens': 'bg-yellow-100 text-yellow-800 border-yellow-200',
      'silicone': 'bg-pink-100 text-pink-800 border-pink-200',
      'outros': 'bg-slate-100 text-slate-800 border-slate-200'
    };
    return colors[categoria] || 'bg-gray-100 text-gray-800 border-gray-200';
  };

  const getNivelCriticidade = (atual, minimo) => {
    const percentual = (atual / minimo) * 100;
    if (percentual === 0) return { nivel: 'Esgotado', color: 'text-red-600' };
    if (percentual <= 25) return { nivel: 'Crítico', color: 'text-red-500' };
    if (percentual <= 50) return { nivel: 'Baixo', color: 'text-orange-500' };
    return { nivel: 'Atenção', color: 'text-yellow-600' };
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg">
      <CardHeader className="pb-4">
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center gap-2 text-lg font-bold text-slate-900">
            <AlertTriangle className="w-5 h-5 text-orange-600" />
            Alerta de Estoque Baixo
          </CardTitle>
          {produtosEstoqueBaixo.length > 0 && (
            <Badge className="bg-red-100 text-red-800 border-red-200">
              {produtosEstoqueBaixo.length} produtos
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <div key={i} className="p-4 bg-slate-50/80 rounded-xl">
                <div className="flex justify-between items-start mb-2">
                  <div className="flex-1">
                    <Skeleton className="h-4 w-32 mb-2" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                  <Skeleton className="h-5 w-16 rounded-full" />
                </div>
                <div className="flex justify-between items-center">
                  <Skeleton className="h-3 w-20" />
                  <Skeleton className="h-3 w-16" />
                </div>
              </div>
            ))}
          </div>
        ) : produtosEstoqueBaixo.length === 0 ? (
          <div className="text-center py-8 text-slate-500">
            <Package className="w-12 h-12 mx-auto mb-4 text-emerald-300" />
            <p className="font-medium text-emerald-600">Estoque em dia!</p>
            <p className="text-sm">Todos os produtos estão com estoque adequado</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-80 overflow-y-auto">
            {produtosEstoqueBaixo.map((produto) => {
              const criticidade = getNivelCriticidade(produto.estoque_atual, produto.estoque_minimo);
              return (
                <div key={produto.id} className="p-4 bg-slate-50/80 rounded-xl hover:bg-slate-100/80 transition-colors duration-200 border border-slate-200/60">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <AlertTriangle className="w-4 h-4 text-orange-500" />
                        <p className="font-semibold text-slate-900">{produto.nome}</p>
                      </div>
                      <p className="text-sm text-slate-600">#{produto.codigo}</p>
                    </div>
                    <Badge className={`${getCategoriaColor(produto.categoria)} border text-xs`}>
                      {produto.categoria?.replace('_', ' ')}
                    </Badge>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div className="text-sm">
                      <span className="text-slate-600">Estoque: </span>
                      <span className={`font-semibold ${criticidade.color}`}>
                        {produto.estoque_atual || 0} {produto.unidade}
                      </span>
                      <span className="text-slate-500 ml-1">
                        / mín: {produto.estoque_minimo || 0}
                      </span>
                    </div>
                    <div className={`text-xs font-medium ${criticidade.color}`}>
                      {criticidade.nivel}
                    </div>
                  </div>

                  {produto.fornecedor_principal && (
                    <div className="mt-2 text-xs text-slate-500">
                      Fornecedor: {produto.fornecedor_principal}
                    </div>
                  )}
                </div>
              );
            })}
            
            <div className="pt-2 border-t border-slate-200">
              <Button variant="outline" size="sm" className="w-full">
                Ver Relatório Completo
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}