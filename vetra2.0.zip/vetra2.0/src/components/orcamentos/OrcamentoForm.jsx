
import React, { useState, useEffect } from 'react';
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Trash2, Calculator } from "lucide-react";
import { Produto } from "@/api/entities";

const tiposMedida = [
    { value: 'unitario', label: 'Unitário', unidade: 'pç' },
    { value: 'm2', label: 'Metros Quadrados (m²)', unidade: 'm²' },
    { value: 'metro_linear', label: 'Metro Linear', unidade: 'ml' },
    { value: 'kit', label: 'Kit de Produtos', unidade: 'kit' },
];

export default function OrcamentoForm({ orcamentoInicial, clientes, currentUser, onSubmit, onCancel, loading = false }) {
  const orcamento = orcamentoInicial || {};
  const [produtos, setProdutos] = useState([]);
  
  const [form, setForm] = useState({
    numero: orcamento.numero || '',
    cliente_id: orcamento.cliente_id || '',
    cliente_nome: orcamento.cliente_nome || '',
    vendedor: orcamento.vendedor || currentUser?.full_name || '',
    status: orcamento.status || 'em_elaboracao',
    data_orcamento: orcamento.data_orcamento || new Date().toISOString().split('T')[0],
    data_validade: orcamento.data_validade || '',
    itens: orcamento.itens || [{ 
      produto_id: '', produto_nome: '', 
      quantidade: 1, preco_unitario: 0, subtotal: 0, 
      observacoes: '', tipo_medida: 'unitario',
      largura_mm: '', altura_mm: '', comprimento_mm: ''
    }],
    valor_total: orcamento.valor_total || 0,
    desconto_percentual: orcamento.desconto_percentual !== undefined && orcamento.desconto_percentual !== null ? orcamento.desconto_percentual : '',
    desconto_valor: orcamento.desconto_valor !== undefined && orcamento.desconto_valor !== null ? orcamento.desconto_valor : '',
    valor_final: orcamento.valor_final || 0,
    observacoes_gerais: orcamento.observacoes_gerais || '',
    condicoes_pagamento: orcamento.condicoes_pagamento || '',
    prazo_entrega: orcamento.prazo_entrega || '',
    endereco_instalacao: orcamento.endereco_instalacao || { 
      logradouro: '', numero: '', complemento: '', bairro: '', cidade: '', uf: '', cep: '' 
    }
  });

  useEffect(() => {
    loadProdutos();
  }, []);

  useEffect(() => {
    calcularTotais();
  }, [form.itens, form.desconto_percentual, form.desconto_valor]);

  const loadProdutos = async () => {
    try {
      const data = await Produto.filter({ ativo: true });
      setProdutos(data || []);
    } catch (error) {
      console.error("Erro ao carregar produtos:", error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    
    if (name === 'cliente_id') {
      const clienteSelecionado = clientes.find(c => c.id === value);
      setForm(prev => ({
        ...prev,
        cliente_id: value,
        cliente_nome: clienteSelecionado?.nome || ''
      }));
    } else if (name === 'desconto_percentual') {
      // If user enters a percentage, clear the fixed value discount
      setForm(prev => ({ ...prev, desconto_percentual: value, desconto_valor: '' }));
    } else if (name === 'desconto_valor') {
      // If user enters a fixed value, clear the percentage discount
      setForm(prev => ({ ...prev, desconto_valor: value, desconto_percentual: '' }));
    } else {
      setForm(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleEnderecoChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({
      ...prev,
      endereco_instalacao: { ...prev.endereco_instalacao, [name]: value }
    }));
  };

  const handleItemChange = (index, campo, valor) => {
    const novosItens = [...form.itens];
    novosItens[index] = { ...novosItens[index], [campo]: valor };
    
    if (campo === 'produto_id') {
      const produtoSelecionado = produtos.find(p => p.id === valor);
      if (produtoSelecionado) {
        novosItens[index].produto_nome = produtoSelecionado.nome;
        novosItens[index].preco_unitario = produtoSelecionado.preco_venda || 0;
        novosItens[index].tipo_medida = produtoSelecionado.tipo_medida || 'unitario';
        // Reset dimensions when product changes, or if changing to a non-dimensional type
        novosItens[index].largura_mm = '';
        novosItens[index].altura_mm = '';
        novosItens[index].comprimento_mm = '';
      }
    }
    
    // Recalcular quantidade e subtotal ao mudar qualquer campo relevante
    recalcularItem(novosItens, index);
    
    setForm(prev => ({ ...prev, itens: novosItens }));
  };
  
  const recalcularItem = (itens, index) => {
    const item = itens[index];
    let quantidadeBase = parseFloat(item.quantidade) || 1;
    let quantidadeCalculada = quantidadeBase;
  
    switch (item.tipo_medida) {
      case 'm2':
        const largura_mm = parseFloat(item.largura_mm) || 0;
        const altura_mm = parseFloat(item.altura_mm) || 0;
        if (largura_mm > 0 && altura_mm > 0) {
          quantidadeCalculada = (largura_mm * altura_mm * quantidadeBase) / 1_000_000; // mm*mm to m2
        } else {
          quantidadeCalculada = 0; // If dimensions are not set, calculated quantity is 0
        }
        break;
      case 'metro_linear':
        const comprimento_mm = parseFloat(item.comprimento_mm) || 0;
        if (comprimento_mm > 0) {
          quantidadeCalculada = (comprimento_mm * quantidadeBase) / 1000; // mm to m
        } else {
          quantidadeCalculada = 0; // If length is not set, calculated quantity is 0
        }
        break;
      default:
        // For 'unitario', 'kit', or other types, quantity is simply the base 'quantidade'
        break;
    }
    
    itens[index].subtotal = quantidadeCalculada * (item.preco_unitario || 0);
  };

  const adicionarItem = () => {
    setForm(prev => ({
      ...prev,
      itens: [...prev.itens, { 
        produto_id: '', produto_nome: '', 
        quantidade: 1, preco_unitario: 0, subtotal: 0, 
        observacoes: '', tipo_medida: 'unitario',
        largura_mm: '', altura_mm: '', comprimento_mm: ''
      }]
    }));
  };

  const removerItem = (index) => {
    if (form.itens.length > 1) {
      const novosItens = form.itens.filter((_, i) => i !== index);
      setForm(prev => ({ ...prev, itens: novosItens }));
    }
  };

  const calcularTotais = () => {
    const valorTotalItens = form.itens.reduce((sum, item) => sum + (item.subtotal || 0), 0);
    
    let descontoAplicado = 0;
    const percentual = parseFloat(form.desconto_percentual);
    const valorFixo = parseFloat(form.desconto_valor);

    if (!isNaN(percentual) && percentual > 0) {
      descontoAplicado = (valorTotalItens * percentual) / 100;
    } else if (!isNaN(valorFixo) && valorFixo > 0) {
      descontoAplicado = valorFixo;
    }
    
    // Ensure discount does not make total negative
    descontoAplicado = Math.min(descontoAplicado, valorTotalItens);
      
    const valorFinalCalculado = valorTotalItens - descontoAplicado;
    
    setForm(prev => ({
      ...prev,
      valor_total: valorTotalItens,
      // We do not update desconto_valor or desconto_percentual here,
      // as they reflect user input, not the calculated value.
      valor_final: valorFinalCalculado
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.cliente_id || !form.vendedor || form.itens.length === 0) {
      alert("Cliente, vendedor e pelo menos um item são obrigatórios.");
      return;
    }

    const dataToSubmit = {
      ...form,
      desconto_percentual: parseFloat(form.desconto_percentual) || 0,
      desconto_valor: parseFloat(form.desconto_valor) || 0,
    };
    
    onSubmit(dataToSubmit);
  };

  const formatCurrency = (value) => {
    return (value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  const valorTotalBruto = form.valor_total || 0;
  // Calculate the actual discount applied for display purposes
  const descontoExibido = (valorTotalBruto - form.valor_final) > 0 ? (valorTotalBruto - form.valor_final) : 0;

  return (
    <form onSubmit={handleSubmit} className="space-y-6 max-h-[80vh] overflow-y-auto">
      {/* Dados Básicos */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Dados do Orçamento</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Número</label>
              <Input
                name="numero"
                value={form.numero}
                onChange={handleChange}
                placeholder="Auto-gerado se vazio"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Data do Orçamento <span className="text-red-500">*</span></label>
              <Input
                type="date"
                name="data_orcamento"
                value={form.data_orcamento}
                onChange={handleChange}
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Data de Validade</label>
              <Input
                type="date"
                name="data_validade"
                value={form.data_validade}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Cliente <span className="text-red-500">*</span></label>
              <select
                name="cliente_id"
                value={form.cliente_id}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
              >
                <option value="">Selecione um cliente</option>
                {clientes.filter(c => c.ativo !== false).map(cliente => (
                  <option key={cliente.id} value={cliente.id}>{cliente.nome}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Vendedor <span className="text-red-500">*</span></label>
              <Input
                name="vendedor"
                value={form.vendedor}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Status</label>
              <select
                name="status"
                value={form.status}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
              >
                <option value="em_elaboracao">Em Elaboração</option>
                <option value="enviado">Enviado</option>
                <option value="aprovado">Aprovado</option>
                <option value="rejeitado">Rejeitado</option>
                <option value="vencido">Vencido</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Prazo de Entrega</label>
              <Input
                name="prazo_entrega"
                value={form.prazo_entrega}
                onChange={handleChange}
                placeholder="Ex: 15 dias úteis"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Itens do Orçamento */}
      <Card>
        <CardHeader className="flex flex-row justify-between items-center">
          <CardTitle className="text-lg">Itens do Orçamento</CardTitle>
          <Button type="button" onClick={adicionarItem} size="sm">
            <Plus className="w-4 h-4 mr-2" />
            Adicionar Item
          </Button>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {form.itens.map((item, index) => {
              const produtoSelecionado = produtos.find(p => p.id === item.produto_id);
              // Ensure tipo_medida is always present, defaulting to 'unitario'
              const tipoMedida = produtoSelecionado?.tipo_medida || item.tipo_medida || 'unitario'; 
              const unidade = tiposMedida.find(t => t.value === tipoMedida)?.unidade || 'pç';

              return (
              <div key={index} className="p-4 border border-slate-200 rounded-lg bg-slate-50">
                <div className="grid grid-cols-1 md:grid-cols-6 gap-4 items-end">
                  {/* Produto */}
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-slate-700 mb-2">Produto</label>
                    <select
                      value={item.produto_id}
                      onChange={(e) => handleItemChange(index, 'produto_id', e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-sm"
                    >
                      <option value="">Selecione um produto</option>
                      {produtos.map(produto => (
                        <option key={produto.id} value={produto.id}>{produto.nome}</option>
                      ))}
                    </select>
                  </div>
                  {/* Quantidade */}
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Qtd</label>
                    <Input
                      type="number"
                      value={item.quantidade}
                      onChange={(e) => handleItemChange(index, 'quantidade', parseFloat(e.target.value) || 0)}
                      min="1"
                      step="1"
                      className="text-sm"
                    />
                  </div>
                  {/* Preço Unit. */}
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Preço Unit. ({unidade})</label>
                    <Input
                      type="number"
                      value={item.preco_unitario}
                      onChange={(e) => handleItemChange(index, 'preco_unitario', parseFloat(e.target.value) || 0)}
                      min="0"
                      step="0.01"
                      className="text-sm"
                    />
                  </div>
                  {/* Subtotal */}
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Subtotal</label>
                    <div className="px-3 py-2 bg-slate-100 border border-slate-300 rounded-lg text-sm font-medium">
                      {formatCurrency(item.subtotal)}
                    </div>
                  </div>
                  {/* Botão Remover */}
                  <div>
                    {form.itens.length > 1 && (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => removerItem(index)}
                        className="text-red-600 border-red-300 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>

                {/* Campos de Medida Condicionais */}
                {tipoMedida === 'm2' && (
                  <div className="grid grid-cols-2 gap-4 mt-3 pt-3 border-t">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Largura (mm)</label>
                      <Input
                        type="number"
                        value={item.largura_mm}
                        onChange={(e) => handleItemChange(index, 'largura_mm', e.target.value)}
                        placeholder="Ex: 1000"
                        className="text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Altura (mm)</label>
                      <Input
                        type="number"
                        value={item.altura_mm}
                        onChange={(e) => handleItemChange(index, 'altura_mm', e.target.value)}
                        placeholder="Ex: 800"
                        className="text-sm"
                      />
                    </div>
                  </div>
                )}
                
                {tipoMedida === 'metro_linear' && (
                  <div className="grid grid-cols-2 gap-4 mt-3 pt-3 border-t">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Comprimento (mm)</label>
                      <Input
                        type="number"
                        value={item.comprimento_mm}
                        onChange={(e) => handleItemChange(index, 'comprimento_mm', e.target.value)}
                        placeholder="Ex: 6000"
                        className="text-sm"
                      />
                    </div>
                  </div>
                )}

                <div className="mt-3">
                  <label className="block text-sm font-medium text-slate-700 mb-2">Observações do Item</label>
                  <Input
                    value={item.observacoes}
                    onChange={(e) => handleItemChange(index, 'observacoes', e.target.value)}
                    placeholder="Observações específicas deste item..."
                    className="text-sm"
                  />
                </div>
              </div>
            )})}
          </div>
        </CardContent>
      </Card>

      {/* Totais e Desconto */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Calculator className="w-5 h-5" />
            Resumo Financeiro
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Desconto (%)</label>
                <Input
                  type="number"
                  name="desconto_percentual"
                  value={form.desconto_percentual}
                  onChange={handleChange}
                  min="0"
                  step="any"
                  placeholder="Ex: 5"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Desconto (R$)</label>
                <Input
                  type="number"
                  name="desconto_valor"
                  value={form.desconto_valor}
                  onChange={handleChange}
                  min="0"
                  step="any"
                  placeholder="Ex: 50.00"
                />
              </div>
            </div>
            <div className="space-y-3 bg-slate-50 p-4 rounded-lg">
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600">Subtotal:</span>
                <span className="font-medium">{formatCurrency(valorTotalBruto)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600">Desconto:</span>
                <span className="font-medium text-red-600">-{formatCurrency(descontoExibido)}</span>
              </div>
              <div className="border-t pt-2">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-semibold">Total:</span>
                  <span className="text-xl font-bold text-blue-600">{formatCurrency(form.valor_final)}</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Informações Adicionais */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Informações Adicionais</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Condições de Pagamento</label>
            <Textarea
              name="condicoes_pagamento"
              value={form.condicoes_pagamento}
              onChange={handleChange}
              rows={2}
              placeholder="Ex: 30% de entrada, saldo em 2x nos cartões..."
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Observações Gerais</label>
            <Textarea
              name="observacoes_gerais"
              value={form.observacoes_gerais}
              onChange={handleChange}
              rows={3}
              placeholder="Observações gerais do orçamento..."
            />
          </div>
        </CardContent>
      </Card>

      {/* Endereço de Instalação */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Endereço de Instalação</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-2">CEP</label>
              <Input
                name="cep"
                value={form.endereco_instalacao.cep}
                onChange={handleEnderecoChange}
              />
            </div>
            <div className="md:col-span-4">
              <label className="block text-sm font-medium text-slate-700 mb-2">Logradouro</label>
              <Input
                name="logradouro"
                value={form.endereco_instalacao.logradouro}
                onChange={handleEnderecoChange}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Número</label>
              <Input
                name="numero"
                value={form.endereco_instalacao.numero}
                onChange={handleEnderecoChange}
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-2">Complemento</label>
              <Input
                name="complemento"
                value={form.endereco_instalacao.complemento}
                onChange={handleEnderecoChange}
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-2">Bairro</label>
              <Input
                name="bairro"
                value={form.endereco_instalacao.bairro}
                onChange={handleEnderecoChange}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">UF</label>
              <Input
                name="uf"
                value={form.endereco_instalacao.uf}
                onChange={handleEnderecoChange}
                maxLength={2}
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-2">Cidade</label>
              <Input
                name="cidade"
                value={form.endereco_instalacao.cidade}
                onChange={handleEnderecoChange}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Botões */}
      <div className="flex justify-end gap-3 pt-4 border-t">
        <Button type="button" variant="outline" onClick={onCancel} disabled={loading}>
          Cancelar
        </Button>
        <Button type="submit" disabled={loading} className="bg-blue-600 hover:bg-blue-700">
          {loading ? 'Salvando...' : (orcamentoInicial ? 'Atualizar Orçamento' : 'Criar Orçamento')}
        </Button>
      </div>
    </form>
  );
}
