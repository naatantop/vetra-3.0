// Categorias padrão do sistema
const categoriasDefault = [
  { value: 'vidro_temperado', label: 'Vidro Temperado' },
  { value: 'vidro_comum', label: 'Vidro Comum' },
  { value: 'esquadria', label: 'Esquadria' },
  { value: 'acessorio', label: 'Acessório' },
  { value: 'espelhos', label: 'Espelhos' },
  { value: 'acm', label: 'ACM' },
  { value: 'forro_pvc', label: 'Forro PVC' },
];

// Acabamentos padrão por categoria
const acabamentosDefaultPorCategoria = {
  vidro_temperado: ['Liso', 'Jateado', 'Serigrafado', 'Acidado'],
  vidro_comum: ['Liso', 'Fantasia', 'Canelado', 'Pontilhado'],
  esquadria: ['Liso', 'Texturizado', 'Anodizado', 'Eletrostático'],
  acessorio: ['Polido', 'Escovado', 'Anodizado', 'Cromado'],
  espelhos: ['Liso', 'Bisotê', 'Lapidado', 'Jateado'],
  acm: ['Liso', 'Escovado', 'Espelhado', 'Wood'],
  forro_pvc: ['Simples', 'Style', 'Colonial']
};

// Função para obter todas as categorias (padrão + personalizadas)
export const getAllCategorias = () => {
  const customCategories = getCustomCategories();
  return [...categoriasDefault, ...customCategories];
};

// Função para obter apenas categorias personalizadas
export const getCustomCategories = () => {
  const saved = localStorage.getItem('custom_categories');
  if (saved) {
    try {
      const parsed = JSON.parse(saved);
      return Array.isArray(parsed) ? parsed : [];
    } catch (error) {
      console.error('Erro ao carregar categorias personalizadas:', error);
      return [];
    }
  }
  return [];
};

// Função para salvar categorias personalizadas
export const saveCustomCategories = (categories) => {
  localStorage.setItem('custom_categories', JSON.stringify(categories));
};

// Função para obter acabamentos personalizados
export const getCustomAcabamentos = () => {
  const saved = localStorage.getItem('custom_acabamentos');
  if (saved) {
    try {
      const parsed = JSON.parse(saved);
      return typeof parsed === 'object' && parsed !== null ? parsed : {};
    } catch (error) {
      console.error('Erro ao carregar acabamentos personalizados:', error);
      return {};
    }
  }
  return {};
};

// Função para salvar acabamentos personalizados
export const saveCustomAcabamentos = (acabamentos) => {
  localStorage.setItem('custom_acabamentos', JSON.stringify(acabamentos));
};

// Função para obter acabamentos por categoria
export const getAcabamentosPorCategoria = (categoria) => {
  // Primeiro, verificar acabamentos personalizados
  const customAcabamentos = getCustomAcabamentos();
  if (customAcabamentos[categoria]) {
    return customAcabamentos[categoria];
  }
  
  // Se não houver personalizados, usar os padrão
  return acabamentosDefaultPorCategoria[categoria] || ['Liso', 'Padrão'];
};

// Função para obter label de uma categoria pelo valor
export const getCategoriaLabel = (categoriaValue) => {
  const todasCategorias = getAllCategorias();
  const categoria = todasCategorias.find(cat => cat.value === categoriaValue);
  return categoria ? categoria.label : categoriaValue;
};

export default {
  getAllCategorias,
  getCustomCategories,
  saveCustomCategories,
  getCustomAcabamentos,
  saveCustomAcabamentos,
  getAcabamentosPorCategoria,
  getCategoriaLabel
};