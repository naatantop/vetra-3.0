// Utilitários de validação para segurança de dados
export const ValidationUtils = {
  // Validação de CPF
  validateCPF: (cpf) => {
    if (!cpf) return { isValid: true, message: "" }; // CPF é opcional
    
    const cleanCPF = cpf.replace(/[^\d]/g, '');
    
    if (cleanCPF.length !== 11) {
      return { isValid: false, message: "CPF deve ter 11 dígitos" };
    }
    
    // Verifica se todos os dígitos são iguais
    if (/^(\d)\1{10}$/.test(cleanCPF)) {
      return { isValid: false, message: "CPF inválido" };
    }
    
    // Validação dos dígitos verificadores
    let sum = 0;
    for (let i = 0; i < 9; i++) {
      sum += parseInt(cleanCPF[i]) * (10 - i);
    }
    let digit1 = 11 - (sum % 11);
    if (digit1 > 9) digit1 = 0;
    
    if (parseInt(cleanCPF[9]) !== digit1) {
      return { isValid: false, message: "CPF inválido" };
    }
    
    sum = 0;
    for (let i = 0; i < 10; i++) {
      sum += parseInt(cleanCPF[i]) * (11 - i);
    }
    let digit2 = 11 - (sum % 11);
    if (digit2 > 9) digit2 = 0;
    
    if (parseInt(cleanCPF[10]) !== digit2) {
      return { isValid: false, message: "CPF inválido" };
    }
    
    return { isValid: true, message: "" };
  },

  // Validação de CNPJ
  validateCNPJ: (cnpj) => {
    if (!cnpj) return { isValid: true, message: "" }; // CNPJ é opcional
    
    const cleanCNPJ = cnpj.replace(/[^\d]/g, '');
    
    if (cleanCNPJ.length !== 14) {
      return { isValid: false, message: "CNPJ deve ter 14 dígitos" };
    }
    
    // Verifica se todos os dígitos são iguais
    if (/^(\d)\1{13}$/.test(cleanCNPJ)) {
      return { isValid: false, message: "CNPJ inválido" };
    }
    
    // Validação dos dígitos verificadores
    const weights1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
    const weights2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
    
    let sum = 0;
    for (let i = 0; i < 12; i++) {
      sum += parseInt(cleanCNPJ[i]) * weights1[i];
    }
    let digit1 = sum % 11 < 2 ? 0 : 11 - (sum % 11);
    
    if (parseInt(cleanCNPJ[12]) !== digit1) {
      return { isValid: false, message: "CNPJ inválido" };
    }
    
    sum = 0;
    for (let i = 0; i < 13; i++) {
      sum += parseInt(cleanCNPJ[i]) * weights2[i];
    }
    let digit2 = sum % 11 < 2 ? 0 : 11 - (sum % 11);
    
    if (parseInt(cleanCNPJ[13]) !== digit2) {
      return { isValid: false, message: "CNPJ inválido" };
    }
    
    return { isValid: true, message: "" };
  },

  // Validação de email
  validateEmail: (email) => {
    if (!email) return { isValid: true, message: "" }; // Email é opcional
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return { isValid: false, message: "Email inválido" };
    }
    
    return { isValid: true, message: "" };
  },

  // Validação de telefone
  validatePhone: (phone) => {
    if (!phone) return { isValid: true, message: "" }; // Telefone é opcional
    
    const cleanPhone = phone.replace(/[^\d]/g, '');
    
    if (cleanPhone.length < 10 || cleanPhone.length > 11) {
      return { isValid: false, message: "Telefone deve ter 10 ou 11 dígitos" };
    }
    
    return { isValid: true, message: "" };
  },

  // Sanitização de strings para prevenir XSS
  sanitizeString: (str) => {
    if (!str) return str;
    return str
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;')
      .replace(/&/g, '&amp;');
  },

  // Validação de valores monetários
  validateCurrency: (value) => {
    const numValue = parseFloat(value);
    
    if (isNaN(numValue)) {
      return { isValid: false, message: "Valor deve ser um número válido" };
    }
    
    if (numValue < 0) {
      return { isValid: false, message: "Valor não pode ser negativo" };
    }
    
    if (numValue > 999999999) {
      return { isValid: false, message: "Valor muito alto" };
    }
    
    return { isValid: true, message: "" };
  },

  // Validação de estoque
  validateStock: (value) => {
    const numValue = parseFloat(value);
    
    if (isNaN(numValue)) {
      return { isValid: false, message: "Estoque deve ser um número válido" };
    }
    
    if (numValue < 0) {
      return { isValid: false, message: "Estoque não pode ser negativo" };
    }
    
    if (numValue > 999999) {
      return { isValid: false, message: "Valor de estoque muito alto" };
    }
    
    return { isValid: true, message: "" };
  },

  // Validação de CEP
  validateCEP: (cep) => {
    if (!cep) return { isValid: true, message: "" }; // CEP é opcional
    
    const cleanCEP = cep.replace(/[^\d]/g, '');
    
    if (cleanCEP.length !== 8) {
      return { isValid: false, message: "CEP deve ter 8 dígitos" };
    }
    
    return { isValid: true, message: "" };
  },

  // Validação de datas
  validateDate: (date) => {
    if (!date) return { isValid: true, message: "" }; // Data é opcional
    
    const dateObj = new Date(date);
    
    if (isNaN(dateObj.getTime())) {
      return { isValid: false, message: "Data inválida" };
    }
    
    const today = new Date();
    const hundredYearsAgo = new Date(today.getFullYear() - 100, today.getMonth(), today.getDate());
    const tenYearsFromNow = new Date(today.getFullYear() + 10, today.getMonth(), today.getDate());
    
    if (dateObj < hundredYearsAgo || dateObj > tenYearsFromNow) {
      return { isValid: false, message: "Data fora do intervalo válido" };
    }
    
    return { isValid: true, message: "" };
  }
};