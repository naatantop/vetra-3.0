import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

export default function ClienteForm({ clienteInicial, onSubmit, onCancel, loading }) {
  const [formData, setFormData] = useState({
    nome: '',
    tipo: 'pessoa_fisica',
    documento: '',
    email: '',
    telefone: '',
    telefone_secundario: '',
    endereco: { logradouro: '', numero: '', complemento: '', bairro: '', cidade: '', uf: '', cep: '' },
    ativo: true,
    observacoes: ''
  });

  useEffect(() => {
    if (clienteInicial) {
      setFormData({
        nome: clienteInicial.nome || '',
        tipo: clienteInicial.tipo || 'pessoa_fisica',
        documento: clienteInicial.documento || '',
        email: clienteInicial.email || '',
        telefone: clienteInicial.telefone || '',
        telefone_secundario: clienteInicial.telefone_secundario || '',
        endereco: clienteInicial.endereco || { logradouro: '', numero: '', complemento: '', bairro: '', cidade: '', uf: '', cep: '' },
        ativo: clienteInicial.ativo !== false,
        observacoes: clienteInicial.observacoes || ''
      });
    }
  }, [clienteInicial]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleEnderecoChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      endereco: {
        ...prev.endereco,
        [name]: value
      }
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="nome">Nome / Razão Social</Label>
          <Input id="nome" name="nome" value={formData.nome} onChange={handleChange} required />
        </div>
        <div>
          <Label htmlFor="tipo">Tipo</Label>
          <select id="tipo" name="tipo" value={formData.tipo} onChange={handleChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white">
            <option value="pessoa_fisica">Pessoa Física</option>
            <option value="pessoa_juridica">Pessoa Jurídica</option>
          </select>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="documento">CPF / CNPJ</Label>
          <Input id="documento" name="documento" value={formData.documento} onChange={handleChange} />
        </div>
        <div>
          <Label htmlFor="email">Email</Label>
          <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="telefone">Telefone Principal</Label>
          <Input id="telefone" name="telefone" value={formData.telefone} onChange={handleChange} />
        </div>
        <div>
          <Label htmlFor="telefone_secundario">Telefone Secundário</Label>
          <Input id="telefone_secundario" name="telefone_secundario" value={formData.telefone_secundario} onChange={handleChange} />
        </div>
      </div>

      <div className="space-y-2 p-4 border rounded-lg">
        <h3 className="font-medium">Endereço</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-2">
            <Label htmlFor="logradouro">Logradouro</Label>
            <Input id="logradouro" name="logradouro" value={formData.endereco.logradouro} onChange={handleEnderecoChange} />
          </div>
          <div>
            <Label htmlFor="numero">Número</Label>
            <Input id="numero" name="numero" value={formData.endereco.numero} onChange={handleEnderecoChange} />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="bairro">Bairro</Label>
            <Input id="bairro" name="bairro" value={formData.endereco.bairro} onChange={handleEnderecoChange} />
          </div>
          <div>
            <Label htmlFor="complemento">Complemento</Label>
            <Input id="complemento" name="complemento" value={formData.endereco.complemento} onChange={handleEnderecoChange} />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <Label htmlFor="cidade">Cidade</Label>
            <Input id="cidade" name="cidade" value={formData.endereco.cidade} onChange={handleEnderecoChange} />
          </div>
          <div>
            <Label htmlFor="uf">UF</Label>
            <Input id="uf" name="uf" value={formData.endereco.uf} onChange={handleEnderecoChange} />
          </div>
          <div>
            <Label htmlFor="cep">CEP</Label>
            <Input id="cep" name="cep" value={formData.endereco.cep} onChange={handleEnderecoChange} />
          </div>
        </div>
      </div>

      <div>
        <Label htmlFor="observacoes">Observações</Label>
        <Textarea id="observacoes" name="observacoes" value={formData.observacoes} onChange={handleChange} />
      </div>

      <div className="flex items-center space-x-2">
        <input type="checkbox" id="ativo" name="ativo" checked={formData.ativo} onChange={handleChange} className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"/>
        <Label htmlFor="ativo">Cliente Ativo</Label>
      </div>

      <div className="flex justify-end gap-3 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} disabled={loading}>
          Cancelar
        </Button>
        <Button type="submit" disabled={loading}>
          {loading ? 'Salvando...' : 'Salvar Cliente'}
        </Button>
      </div>
    </form>
  );
}