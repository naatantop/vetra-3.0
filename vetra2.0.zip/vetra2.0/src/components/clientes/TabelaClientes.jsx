import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import Button from "../ui/Button";
import { Edit, Trash2, Power, PowerOff } from "lucide-react";

export default function TabelaClientes({ clientes, onEditar, onExcluir, onToggleAtivo, loading, currentUser }) {
    
    const hasEditPermission = currentUser?.role === 'admin' || currentUser?.permissions?.includes('clientes_edit');
    const hasDeletePermission = currentUser?.role === 'admin' || currentUser?.permissions?.includes('clientes_delete');

    if (loading) {
        return <div className="p-6 text-center">Carregando clientes...</div>;
    }

    if (!clientes || clientes.length === 0) {
        return <div className="p-6 text-center text-slate-500">Nenhum cliente encontrado.</div>;
    }

    return (
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Nome</TableHead>
                        <TableHead>Contato</TableHead>
                        <TableHead>Documento</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {clientes.map((cliente) => (
                        <TableRow key={cliente.id}>
                            <TableCell className="font-medium">{cliente.nome}</TableCell>
                            <TableCell>
                                <div>{cliente.email}</div>
                                <div>{cliente.telefone}</div>
                            </TableCell>
                            <TableCell>{cliente.documento}</TableCell>
                            <TableCell>
                                <Badge variant={cliente.ativo !== false ? "default" : "destructive"}>
                                    {cliente.ativo !== false ? 'Ativo' : 'Inativo'}
                                </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                                <div className="flex gap-2 justify-end">
                                    {hasEditPermission && (
                                        <>
                                            <Button variant="ghost" size="sm" onClick={() => onToggleAtivo(cliente)}>
                                                {cliente.ativo !== false ? <PowerOff size={16} className="text-red-500" /> : <Power size={16} className="text-green-500" />}
                                            </Button>
                                            <Button variant="ghost" size="sm" onClick={() => onEditar(cliente)}>
                                                <Edit size={16} />
                                            </Button>
                                        </>
                                    )}
                                    {hasDeletePermission && (
                                        <Button variant="ghost" size="sm" onClick={() => onExcluir(cliente)}>
                                            <Trash2 size={16} className="text-red-500" />
                                        </Button>
                                    )}
                                </div>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </div>
    );
}