import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { format, isPast, isToday } from 'date-fns';

const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value || 0);
};

export default function DespesaEspecificaCard({ title, icon: Icon, lancamentos, categoria, isLoading }) {
  const lancamentoRecente = lancamentos
    .filter(l => l.categoria === categoria && (l.status === 'pendente' || l.status === 'pago'))
    .sort((a, b) => new Date(b.data_vencimento) - new Date(a.data_vencimento))[0];
  
  if (isLoading) {
    return <Skeleton className="h-24 w-full rounded-xl" />;
  }

  const vencido = lancamentoRecente && lancamentoRecente.status === 'pendente' && isPast(new Date(lancamentoRecente.data_vencimento)) && !isToday(new Date(lancamentoRecente.data_vencimento));
  
  return (
    <Card className={`relative overflow-hidden bg-white/80 backdrop-blur-sm border-slate-200/60 shadow-lg hover:shadow-xl transition-all duration-300 ${vencido ? 'border-red-400' : ''}`}>
      <CardContent className="p-4">
        <div className="flex items-center gap-4">
          <div className={`p-3 rounded-xl bg-slate-500/10`}>
            <Icon className="w-6 h-6 text-slate-600" />
          </div>
          <div>
            <p className="font-semibold text-slate-800">{title}</p>
            {lancamentoRecente ? (
              <>
                <p className="text-lg font-bold text-slate-900">{formatCurrency(lancamentoRecente.valor)}</p>
                <p className={`text-xs ${vencido ? 'text-red-600 font-bold' : 'text-slate-500'}`}>
                  Venc. {format(new Date(lancamentoRecente.data_vencimento), 'dd/MM/yyyy')}
                  {lancamentoRecente.status === 'pago' && <span className="text-emerald-600 ml-1">(Pago)</span>}
                </p>
              </>
            ) : (
              <p className="text-sm text-slate-500">Nenhum lançamento</p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}