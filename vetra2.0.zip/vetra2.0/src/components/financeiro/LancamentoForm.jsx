import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

const categorias = {
  receita: [
    { value: 'venda_produto', label: 'Venda de Produtos' },
    { value: 'servico_instalacao', label: 'Serviços de Instalação' },
    { value: 'outros', label: 'Outras Receitas' }
  ],
  despesa: [
    { value: 'salarios_folha', label: 'Salários e Folha' },
    { value: 'fornecedores', label: 'Fornecedores' },
    { value: 'aluguel', label: 'Aluguel' },
    { value: 'energia', label: 'Energia Elétrica' },
    { value: 'agua', label: 'Água' },
    { value: 'internet_telefone', label: 'Internet e Telefone' },
    { value: 'impostos', label: 'Impostos' },
    { value: 'marketing', label: 'Marketing' },
    { value: 'transporte_combustivel', label: 'Transporte e Combustível' },
    { value: 'manutencao_equipamentos', label: 'Manutenção de Equipamentos' },
    { value: 'material_escritorio', label: 'Material de Escritório' },
    { value: 'outros', label: 'Outras Despesas' }
  ]
};

export default function LancamentoForm({ lancamentoInicial, onSubmit, onCancel, loading }) {
  const [formData, setFormData] = useState({
    descricao: '',
    tipo: 'receita',
    categoria: 'venda_produto',
    valor: '',
    status: 'pendente',
    data_vencimento: new Date().toISOString().split('T')[0],
    data_pagamento: '',
    cliente_fornecedor: '',
    observacoes: ''
  });

  useEffect(() => {
    if (lancamentoInicial) {
      setFormData({
        descricao: lancamentoInicial.descricao || '',
        tipo: lancamentoInicial.tipo || 'receita',
        categoria: lancamentoInicial.categoria || 'venda_produto',
        valor: lancamentoInicial.valor?.toString() || '',
        status: lancamentoInicial.status || 'pendente',
        data_vencimento: lancamentoInicial.data_vencimento || new Date().toISOString().split('T')[0],
        data_pagamento: lancamentoInicial.data_pagamento || '',
        cliente_fornecedor: lancamentoInicial.cliente_fornecedor || '',
        observacoes: lancamentoInicial.observacoes || ''
      });
    }
  }, [lancamentoInicial]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleTipoChange = (e) => {
    const tipo = e.target.value;
    setFormData(prev => ({
      ...prev,
      tipo,
      categoria: categorias[tipo][0]?.value || 'outros'
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const dataToSubmit = {
      ...formData,
      valor: parseFloat(formData.valor) || 0
    };
    onSubmit(dataToSubmit);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="descricao">Descrição</Label>
        <Input 
          id="descricao" 
          name="descricao" 
          value={formData.descricao} 
          onChange={handleChange} 
          placeholder="Ex: Venda de vidro temperado"
          required 
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="tipo">Tipo</Label>
          <select 
            id="tipo" 
            name="tipo" 
            value={formData.tipo} 
            onChange={handleTipoChange}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
          >
            <option value="receita">Receita</option>
            <option value="despesa">Despesa</option>
          </select>
        </div>
        <div>
          <Label htmlFor="categoria">Categoria</Label>
          <select 
            id="categoria" 
            name="categoria" 
            value={formData.categoria} 
            onChange={handleChange}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
          >
            {categorias[formData.tipo]?.map(cat => (
              <option key={cat.value} value={cat.value}>{cat.label}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="valor">Valor</Label>
          <Input 
            id="valor" 
            name="valor" 
            type="number" 
            step="0.01" 
            value={formData.valor} 
            onChange={handleChange} 
            placeholder="0,00"
            required 
          />
        </div>
        <div>
          <Label htmlFor="cliente_fornecedor">Cliente/Fornecedor</Label>
          <Input 
            id="cliente_fornecedor" 
            name="cliente_fornecedor" 
            value={formData.cliente_fornecedor} 
            onChange={handleChange} 
            placeholder="Nome do cliente ou fornecedor"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="data_vencimento">Data de Vencimento</Label>
          <Input 
            id="data_vencimento" 
            name="data_vencimento" 
            type="date" 
            value={formData.data_vencimento} 
            onChange={handleChange} 
            required 
          />
        </div>
        <div>
          <Label htmlFor="status">Status</Label>
          <select 
            id="status" 
            name="status" 
            value={formData.status} 
            onChange={handleChange}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
          >
            <option value="pendente">Pendente</option>
            <option value="pago">Pago</option>
            <option value="cancelado">Cancelado</option>
          </select>
        </div>
      </div>

      {formData.status === 'pago' && (
        <div>
          <Label htmlFor="data_pagamento">Data de Pagamento</Label>
          <Input 
            id="data_pagamento" 
            name="data_pagamento" 
            type="date" 
            value={formData.data_pagamento} 
            onChange={handleChange} 
          />
        </div>
      )}

      <div>
        <Label htmlFor="observacoes">Observações</Label>
        <Textarea 
          id="observacoes" 
          name="observacoes" 
          value={formData.observacoes} 
          onChange={handleChange} 
          placeholder="Informações adicionais..."
        />
      </div>

      <div className="flex justify-end gap-3 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} disabled={loading}>
          Cancelar
        </Button>
        <Button type="submit" disabled={loading}>
          {loading ? 'Salvando...' : 'Salvar'}
        </Button>
      </div>
    </form>
  );
}