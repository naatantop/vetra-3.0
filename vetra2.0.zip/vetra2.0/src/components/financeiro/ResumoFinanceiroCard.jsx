import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowUpCircle, ArrowDownCircle } from "lucide-react";
import { format, isPast, isToday } from "date-fns";

const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value || 0);
};

export default function ResumoFinanceiroCard({ title, lancamentos, tipo, isLoading }) {
  const lancamentosFiltrados = lancamentos.filter(l => l.status === 'pendente' || l.status === 'atrasado');
  const totalPendente = lancamentosFiltrados.reduce((acc, curr) => acc + curr.valor, 0);
  const lancamentosAtrasados = lancamentosFiltrados.filter(l => isPast(new Date(l.data_vencimento)) && !isToday(new Date(l.data_vencimento)));
  const totalAtrasado = lancamentosAtrasados.reduce((acc, curr) => acc + curr.valor, 0);

  const isReceita = tipo === 'receita';
  const Icon = isReceita ? ArrowUpCircle : ArrowDownCircle;
  const colorClass = isReceita ? 'text-emerald-600' : 'text-red-600';
  const bgColorClass = isReceita ? 'bg-emerald-500/10' : 'bg-red-500/10';
  const gradientClass = isReceita 
    ? 'bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-200/60' 
    : 'bg-gradient-to-br from-red-50 to-rose-50 border-red-200/60';

  if (isLoading) {
    return <Skeleton className="h-56 w-full rounded-xl" />;
  }
  
  return (
    <Card className={`shadow-lg hover:shadow-xl transition-all duration-300 ${gradientClass}`}>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className={`flex items-center gap-2 font-bold ${colorClass}`}>
            <Icon className="w-6 h-6" />
            {title}
          </CardTitle>
          <Badge className={isReceita ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}>
            {lancamentosFiltrados.length} pendentes
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-center">
          <p className="text-sm text-slate-600">Total Pendente</p>
          <p className={`text-4xl font-bold ${colorClass}`}>{formatCurrency(totalPendente)}</p>
        </div>
        {totalAtrasado > 0 && (
            <div className="bg-red-100/50 p-3 rounded-lg text-center">
                <p className="text-sm font-semibold text-red-700">Atrasado</p>
                <p className="font-bold text-red-700">{formatCurrency(totalAtrasado)}</p>
                <p className="text-xs text-red-600">{lancamentosAtrasados.length} lançamentos</p>
            </div>
        )}
        <div className="space-y-2 text-sm pt-2 border-t border-dashed">
            <h4 className="font-semibold text-slate-700 text-center mb-2">Próximos Vencimentos</h4>
            {lancamentosFiltrados.slice(0, 3).map(l => (
                <div key={l.id} className="flex justify-between items-center">
                    <span className="text-slate-600 truncate pr-2">{l.descricao}</span>
                    <span className="font-medium text-slate-800">{formatCurrency(l.valor)}</span>
                </div>
            ))}
        </div>
      </CardContent>
    </Card>
  );
}