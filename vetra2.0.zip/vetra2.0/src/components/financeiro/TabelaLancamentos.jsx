import React from 'react';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Edit, Trash2, Check, ArrowUp, ArrowDown } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

const formatCurrency = (value) => {
  return (value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
};

const formatDate = (dateString) => {
  if (!dateString) return 'N/A';
  try {
    return format(new Date(dateString), "dd/MM/yyyy", { locale: ptBR });
  } catch {
    return 'N/A';
  }
};

const getStatusColor = (status, dataVencimento) => {
  if (status === 'pago') return 'bg-green-100 text-green-800 border-green-200';
  if (status === 'cancelado') return 'bg-gray-100 text-gray-800 border-gray-200';
  
  const hoje = new Date();
  const vencimento = new Date(dataVencimento);
  if (vencimento < hoje) return 'bg-red-100 text-red-800 border-red-200';
  
  return 'bg-yellow-100 text-yellow-800 border-yellow-200';
};

const getStatusLabel = (status, dataVencimento) => {
  if (status === 'pago') return 'Pago';
  if (status === 'cancelado') return 'Cancelado';
  
  const hoje = new Date();
  const vencimento = new Date(dataVencimento);
  if (vencimento < hoje) return 'Em Atraso';
  
  return 'Pendente';
};

export default function TabelaLancamentos({ lancamentos, loading, onEditar, onExcluir, onConciliar }) {
  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-8">
        <div className="animate-pulse space-y-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="flex items-center space-x-4">
              <div className="h-4 bg-slate-200 rounded w-1/4"></div>
              <div className="h-4 bg-slate-200 rounded w-1/4"></div>
              <div className="h-4 bg-slate-200 rounded w-1/4"></div>
              <div className="h-4 bg-slate-200 rounded w-1/4"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (lancamentos.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-12 text-center">
        <h3 className="text-lg font-medium text-slate-900 mb-2">Nenhum lançamento encontrado</h3>
        <p className="text-slate-500">Tente ajustar os filtros ou crie um novo lançamento.</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-6 py-3 text-left font-medium text-slate-600">Descrição</th>
              <th className="px-6 py-3 text-left font-medium text-slate-600">Tipo</th>
              <th className="px-6 py-3 text-left font-medium text-slate-600">Valor</th>
              <th className="px-6 py-3 text-left font-medium text-slate-600">Vencimento</th>
              <th className="px-6 py-3 text-center font-medium text-slate-600">Status</th>
              <th className="px-6 py-3 text-right font-medium text-slate-600">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {lancamentos.map(lancamento => (
              <tr key={lancamento.id} className="hover:bg-slate-50">
                <td className="px-6 py-4">
                  <div className="font-medium text-slate-900">{lancamento.descricao}</div>
                  {lancamento.cliente_fornecedor && (
                    <div className="text-sm text-slate-500">{lancamento.cliente_fornecedor}</div>
                  )}
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    {lancamento.tipo === 'receita' ? (
                      <ArrowUp className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <ArrowDown className="w-4 h-4 text-red-600" />
                    )}
                    <span className={lancamento.tipo === 'receita' ? 'text-emerald-700' : 'text-red-700'}>
                      {lancamento.tipo === 'receita' ? 'Receita' : 'Despesa'}
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className={`font-medium ${lancamento.tipo === 'receita' ? 'text-emerald-700' : 'text-red-700'}`}>
                    {formatCurrency(lancamento.valor)}
                  </span>
                </td>
                <td className="px-6 py-4 text-slate-900">
                  {formatDate(lancamento.data_vencimento)}
                  {lancamento.data_pagamento && (
                    <div className="text-sm text-slate-500">
                      Pago em: {formatDate(lancamento.data_pagamento)}
                    </div>
                  )}
                </td>
                <td className="px-6 py-4 text-center">
                  <Badge className={`border ${getStatusColor(lancamento.status, lancamento.data_vencimento)}`}>
                    {getStatusLabel(lancamento.status, lancamento.data_vencimento)}
                  </Badge>
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex justify-end gap-2">
                    {lancamento.status === 'pendente' && (
                      <Button variant="ghost" size="sm" onClick={() => onConciliar(lancamento)}>
                        <Check className="w-4 h-4 text-green-500" />
                      </Button>
                    )}
                    <Button variant="ghost" size="sm" onClick={() => onEditar(lancamento)}>
                      <Edit className="w-4 h-4 text-blue-500" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => onExcluir(lancamento)}>
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}