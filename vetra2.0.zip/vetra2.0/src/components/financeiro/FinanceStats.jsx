import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, TrendingUp, TrendingDown, AlertTriangle } from "lucide-react";

const formatCurrency = (value) => {
  return (value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
};

export default function FinanceStats({ lancamentos, isLoading }) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[1, 2, 3, 4].map(i => (
          <Card key={i} className="bg-white/80 backdrop-blur-sm shadow-lg">
            <CardContent className="p-6">
              <div className="animate-pulse">
                <div className="h-4 bg-slate-200 rounded w-3/4 mb-4"></div>
                <div className="h-6 bg-slate-200 rounded w-1/2"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const receitas = lancamentos.filter(l => l.tipo === 'receita');
  const despesas = lancamentos.filter(l => l.tipo === 'despesa');
  const pendentes = lancamentos.filter(l => l.status === 'pendente');
  const atrasados = lancamentos.filter(l => {
    if (l.status !== 'pendente') return false;
    const vencimento = new Date(l.data_vencimento);
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);
    return vencimento < hoje;
  });

  const totalReceitas = receitas.reduce((sum, l) => sum + l.valor, 0);
  const totalDespesas = despesas.reduce((sum, l) => sum + l.valor, 0);
  const totalPendentes = pendentes.reduce((sum, l) => sum + l.valor, 0);
  const totalAtrasados = atrasados.reduce((sum, l) => sum + l.valor, 0);

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
      <Card className="bg-white/80 backdrop-blur-sm shadow-lg">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-emerald-600">
            <TrendingUp className="w-5 h-5" />
            Receitas
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-2xl font-bold text-emerald-700">{formatCurrency(totalReceitas)}</p>
          <p className="text-sm text-slate-500">{receitas.length} lançamentos</p>
        </CardContent>
      </Card>

      <Card className="bg-white/80 backdrop-blur-sm shadow-lg">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-red-600">
            <TrendingDown className="w-5 h-5" />
            Despesas
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-2xl font-bold text-red-700">{formatCurrency(totalDespesas)}</p>
          <p className="text-sm text-slate-500">{despesas.length} lançamentos</p>
        </CardContent>
      </Card>

      <Card className="bg-white/80 backdrop-blur-sm shadow-lg">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-blue-600">
            <DollarSign className="w-5 h-5" />
            Saldo
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className={`text-2xl font-bold ${totalReceitas - totalDespesas >= 0 ? 'text-emerald-700' : 'text-red-700'}`}>
            {formatCurrency(totalReceitas - totalDespesas)}
          </p>
          <p className="text-sm text-slate-500">Período filtrado</p>
        </CardContent>
      </Card>

      <Card className="bg-white/80 backdrop-blur-sm shadow-lg">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-amber-600">
            <AlertTriangle className="w-5 h-5" />
            Em Atraso
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-2xl font-bold text-amber-700">{formatCurrency(totalAtrasados)}</p>
          <p className="text-sm text-slate-500">{atrasados.length} lançamentos</p>
        </CardContent>
      </Card>
    </div>
  );
}