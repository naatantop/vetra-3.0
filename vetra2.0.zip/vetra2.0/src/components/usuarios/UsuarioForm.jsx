
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Save, Loader2 } from 'lucide-react';

const availablePermissions = {
  "Geral": [
    { id: "dashboard_view", label: "Ver Dashboard" },
  ],
  "Produtos": [
    { id: "produtos_view", label: "Ver Produtos" },
    { id: "produtos_create", label: "Criar Produtos" },
    { id: "produtos_edit", label: "Editar Produtos" },
    { id: "produtos_delete", label: "Excluir Produtos" },
  ],
  "Clientes": [
    { id: "clientes_view", label: "Ver Clientes" },
    { id: "clientes_create", label: "Criar Clientes" },
    { id: "clientes_edit", label: "Editar Clientes" },
    { id: "clientes_delete", label: "Excluir Clientes" },
  ],
  "Vendas": [
    { id: "vendas_view", label: "Ver Vendas & Orçamentos" },
    { id: "vendas_create", label: "Criar Orçamentos" },
    { id: "vendas_edit", label: "Editar Vendas & Orçamentos" },
    { id: "vendas_delete", label: "Excluir Vendas & Orçamentos" },
  ],
  "Produção": [
    { id: "producao_view", label: "Ver Produção" },
    { id: "producao_edit", label: "Editar Status da Produção" },
  ],
  "Financeiro": [
    { id: "financeiro_view", label: "Ver Financeiro" },
    { id: "financeiro_create", label: "Criar Lançamentos" },
    { id: "financeiro_edit", label: "Editar Lançamentos" },
    { id: "financeiro_delete", label: "Excluir Lançamentos" },
  ],
  "Relatórios": [
    { id: "relatorios_view", label: "Ver Relatórios" },
  ],
  "Configurações": [
    { id: "configuracoes_view", label: "Ver Configurações" },
    { id: "configuracoes_edit", label: "Editar Configurações" },
  ],
  "Administração": [
    { id: "usuarios_view", label: "Ver Usuários" },
    { id: "usuarios_edit", label: "Editar Usuários" },
  ]
};

const UsuarioForm = ({ user, onSubmit, onCancel, loading }) => {
  const [role, setRole] = useState(user.role);
  const [permissions, setPermissions] = useState(user.permissions || []);

  const handlePermissionChange = (permissionId, isChecked) => {
    if (isChecked) {
      setPermissions(prev => [...prev, permissionId]);
    } else {
      setPermissions(prev => prev.filter(p => p !== permissionId));
    }
  };
  
  const handleSelectAllCategory = (category, isChecked) => {
    const categoryPermissions = availablePermissions[category].map(p => p.id);
    if (isChecked) {
        setPermissions(prev => [...new Set([...prev, ...categoryPermissions])]);
    } else {
        setPermissions(prev => prev.filter(p => !categoryPermissions.includes(p)));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ id: user.id, role, permissions });
  };
  
  if (!user) return null;

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="role" className="block text-sm font-medium text-slate-700 mb-2">
          Função (Role)
        </label>
        <select
          id="role"
          value={role}
          onChange={(e) => setRole(e.target.value)}
          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
        >
          <option value="user">Usuário</option>
          <option value="admin">Administrador</option>
        </select>
        {role === 'admin' && (
            <p className="text-sm text-amber-700 mt-2 bg-amber-50 p-2 rounded-md">Administradores têm acesso a todas as funcionalidades, independentemente das permissões abaixo.</p>
        )}
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-medium text-slate-900">Permissões Específicas</h3>
        {Object.entries(availablePermissions).map(([category, perms]) => {
            const allInCategorySelected = perms.every(p => permissions.includes(p.id));
            return (
              <div key={category} className="p-4 border rounded-lg bg-slate-50/50">
                <div className="flex items-center justify-between mb-2 pb-2 border-b">
                    <h4 className="font-semibold text-slate-800">{category}</h4>
                    <div className="flex items-center space-x-2">
                        <Checkbox
                            id={`select-all-${category}`}
                            checked={allInCategorySelected}
                            onCheckedChange={(checked) => handleSelectAllCategory(category, checked)}
                        />
                        <label htmlFor={`select-all-${category}`} className="text-sm font-medium">Selecionar Tudo</label>
                    </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {perms.map((perm) => (
                    <div key={perm.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={perm.id}
                        checked={permissions.includes(perm.id)}
                        onCheckedChange={(checked) => handlePermissionChange(perm.id, checked)}
                      />
                      <label htmlFor={perm.id} className="text-sm font-normal text-slate-700">
                        {perm.label}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            );
        })}
      </div>

      <div className="flex justify-end gap-4 pt-6 border-t">
        <Button type="button" variant="outline" onClick={onCancel} disabled={loading}>
          Cancelar
        </Button>
        <Button type="submit" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Salvando...
            </>
          ) : (
            <>
              <Save className="w-4 h-4 mr-2" /> Salvar Permissões
            </>
          )}
        </Button>
      </div>
    </form>
  );
};

export default UsuarioForm;
