
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { FileText, Loader2, Send, XCircle, CheckCircle, AlertTriangle } from "lucide-react";
import { emitirNfe } from "@/api/functions";
import { Produto } from "@/api/entities";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function NfeFormModal({ venda, onClose, onSuccess }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null);
  const [produtosCompletos, setProdutosCompletos] = useState([]);
  const [checkingData, setCheckingData] = useState(true);

  useEffect(() => {
    checkFiscalData();
  }, [venda]);

  const checkFiscalData = async () => {
    setCheckingData(true);
    const objectIdRegex = /^[0-9a-fA-F]{24}$/;
    
    const validProdutoIds = venda.itens
      .map(item => item.produto_id)
      .filter(id => id && objectIdRegex.test(id));

    if (validProdutoIds.length === 0 && venda.itens.length > 0) {
        // If there are items but no valid product IDs (e.g., product_id is null or invalid format)
        // We still need to populate produtosCompletos to show which items have missing data.
        // In this case, NCM/CFOP will be undefined, triggering the missingFiscalData check.
        setProdutosCompletos(venda.itens.map(item => ({
            ...item,
            ncm: undefined, // Explicitly set to undefined as we can't fetch them
            cfop: undefined, // Explicitly set to undefined as we can't fetch them
        })));
        setCheckingData(false);
        return;
    }

    const produtosData = validProdutoIds.length > 0 
      ? await Produto.filter({ id: { $in: validProdutoIds } }) 
      : [];

    const produtosMap = new Map(produtosData.map(p => [p.id, p]));
    
    const produtosItens = venda.itens.map(item => ({
      ...item,
      ncm: produtosMap.get(item.produto_id)?.ncm,
      cfop: produtosMap.get(item.produto_id)?.cfop,
    }));
    setProdutosCompletos(produtosItens);
    setCheckingData(false);
  };

  const handleEmitirNfe = async () => {
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await emitirNfe({ orcamentoId: venda.id });
      setResult(response.data);
      if (response.data.status === 'aprovado' || response.data.status === 'processando_autorizacao') {
        onSuccess();
      } else {
        setError(response.data.motivo_rejeicao || response.data.erros?.map(e => e.mensagem).join(', ') || 'Erro desconhecido');
      }
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.error || err.message || "Ocorreu um erro ao emitir a NF-e.");
    } finally {
      setLoading(false);
    }
  };

  const missingFiscalData = produtosCompletos.some(p => !p.ncm || !p.cfop);

  const renderContent = () => {
    if (result) {
      return (
        <div className="text-center">
          {result.status === 'aprovado' ? (
            <>
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
              <h3 className="text-xl font-bold">NF-e Aprovada!</h3>
              <p className="text-slate-600 mt-2">A nota fiscal foi emitida e autorizada com sucesso.</p>
              <div className="mt-6 flex justify-center gap-3">
                <a href={result.caminho_danfe} target="_blank" rel="noopener noreferrer">
                  <Button variant="outline">Ver DANFE (PDF)</Button>
                </a>
                <a href={result.caminho_xml_nota_fiscal} target="_blank" rel="noopener noreferrer">
                  <Button variant="outline">Baixar XML</Button>
                </a>
              </div>
            </>
          ) : result.status === 'processando_autorizacao' ? (
            <>
              <Loader2 className="w-16 h-16 text-blue-500 mx-auto mb-4 animate-spin" />
              <h3 className="text-xl font-bold">NF-e em Processamento</h3>
              <p className="text-slate-600 mt-2">A nota foi enviada e está aguardando autorização da SEFAZ. O status será atualizado em breve.</p>
            </>
          ) : (
            <>
              <XCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
              <h3 className="text-xl font-bold">NF-e Rejeitada</h3>
              <p className="text-slate-600 mt-2">Motivo: {result.motivo_rejeicao}</p>
            </>
          )}
           <Button onClick={onClose} className="mt-6 w-full">Fechar</Button>
        </div>
      );
    }

    if (checkingData) {
      return (
        <div className="flex items-center justify-center h-48">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
          <p className="ml-3">Verificando dados fiscais...</p>
        </div>
      );
    }
    
    if (missingFiscalData) {
      return (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Dados Fiscais Incompletos</AlertTitle>
          <AlertDescription>
            <p>Um ou mais produtos nesta venda não possuem NCM ou CFOP cadastrados. Por favor, atualize os dados fiscais dos produtos antes de emitir a NF-e.</p>
            <ul className="mt-2 list-disc list-inside">
              {produtosCompletos.filter(p => !p.ncm || !p.cfop).map(p => (
                <li key={p.produto_id}>{p.produto_nome}</li>
              ))}
            </ul>
            <Link to={createPageUrl("Produtos")}>
                <Button variant="link" className="p-0 h-auto mt-2">Ir para a página de Produtos</Button>
            </Link>
          </AlertDescription>
        </Alert>
      )
    }

    return (
      <div className="space-y-4">
        <Alert>
          <FileText className="h-4 w-4" />
          <AlertTitle>Confirmar Emissão de NF-e</AlertTitle>
          <AlertDescription>
            Você está prestes a emitir uma nota fiscal para a venda #{venda.numero}. Verifique os itens abaixo. Esta ação enviará os dados para a SEFAZ.
          </AlertDescription>
        </Alert>
        <Card>
          <CardContent className="p-4">
            <h4 className="font-semibold mb-2">Itens da Nota</h4>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Produto</TableHead>
                  <TableHead className="text-right">Qtd.</TableHead>
                  <TableHead className="text-right">Valor</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {venda.itens.map((item, index) => (
                  <TableRow key={index}>
                    <TableCell>{item.produto_nome}</TableCell>
                    <TableCell className="text-right">{item.quantidade}</TableCell>
                    <TableCell className="text-right">R$ {item.subtotal.toFixed(2)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <div className="text-right mt-4 font-bold text-lg">
              Total: R$ {venda.valor_final.toFixed(2)}
            </div>
          </CardContent>
        </Card>
        {error && <Alert variant="destructive"><AlertTriangle className="h-4 w-4" /><AlertDescription>{error}</AlertDescription></Alert>}
        <Button onClick={handleEmitirNfe} disabled={loading} className="w-full bg-blue-600 hover:bg-blue-700">
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Emitindo...
            </>
          ) : (
            <>
              <Send className="mr-2 h-4 w-4" />
              Confirmar e Emitir NF-e
            </>
          )}
        </Button>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl bg-white">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Emissão de Nota Fiscal</CardTitle>
          <Button variant="ghost" size="icon" onClick={onClose} disabled={loading}>
            <XCircle className="w-6 h-6" />
          </Button>
        </CardHeader>
        <CardContent>
          {renderContent()}
        </CardContent>
      </Card>
    </div>
  );
}
