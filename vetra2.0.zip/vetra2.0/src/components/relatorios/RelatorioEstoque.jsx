import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Produto } from '@/api/entities';
import { Skeleton } from "@/components/ui/skeleton";
import { Package, Archive, AlertTriangle } from 'lucide-react';

const formatCurrency = (value) => value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

const RelatorioEstoque = ({ dateRange }) => {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadData();
    }, [dateRange]); // Recalcula se o dateRange mudar, embora estoque não seja por data

    const loadData = async () => {
        setLoading(true);
        try {
            const produtos = await Produto.list();
            const produtosAtivos = produtos.filter(p => p.ativo !== false);
            
            const valorTotalEstoque = produtosAtivos.reduce((sum, p) => sum + (p.preco_custo || 0) * (p.estoque_atual || 0), 0);
            const totalItensEstoque = produtosAtivos.reduce((sum, p) => sum + (p.estoque_atual || 0), 0);
            const produtosEstoqueBaixo = produtosAtivos.filter(p => p.estoque_atual <= p.estoque_minimo);

            setData({
                valorTotalEstoque,
                totalItensEstoque,
                produtosEstoqueBaixo,
            });
        } catch (error) {
            console.error("Erro ao carregar relatório de estoque:", error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6"><Skeleton className="h-24" /><Skeleton className="h-24" /><Skeleton className="h-24" /><Skeleton className="h-80 col-span-3" /></div>;
    }

    return (
        <div className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <StatCard icon={Package} title="Valor Total do Estoque" value={formatCurrency(data.valorTotalEstoque)} color="blue" />
                <StatCard icon={Archive} title="Total de Itens em Estoque" value={data.totalItensEstoque.toLocaleString('pt-BR')} color="purple" />
                <StatCard icon={AlertTriangle} title="Produtos com Estoque Baixo" value={data.produtosEstoqueBaixo.length} color="red" />
            </div>

            <Card className="bg-white/80 backdrop-blur-sm shadow-lg">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                        <AlertTriangle className="w-5 h-5 text-red-500" />
                        Lista de Produtos com Estoque Baixo
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left text-slate-500">
                            <thead className="text-xs text-slate-700 uppercase bg-slate-100">
                                <tr>
                                    <th scope="col" className="px-6 py-3">Produto</th>
                                    <th scope="col" className="px-6 py-3">Estoque Atual</th>
                                    <th scope="col" className="px-6 py-3">Estoque Mínimo</th>
                                </tr>
                            </thead>
                            <tbody>
                                {data.produtosEstoqueBaixo.map(produto => (
                                    <tr key={produto.id} className="bg-white border-b hover:bg-slate-50">
                                        <td className="px-6 py-4 font-medium text-slate-900">{produto.nome}</td>
                                        <td className="px-6 py-4 text-red-600 font-bold">{produto.estoque_atual}</td>
                                        <td className="px-6 py-4">{produto.estoque_minimo}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
};

const StatCard = ({ icon: Icon, title, value, color }) => (
    <Card className="bg-white/80 backdrop-blur-sm shadow-lg">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{title}</CardTitle>
            <Icon className={`h-5 w-5 text-${color}-500`} />
        </CardHeader>
        <CardContent>
            <div className="text-2xl font-bold">{value}</div>
        </CardContent>
    </Card>
);

export default RelatorioEstoque;