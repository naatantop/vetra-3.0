import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Cliente } from '@/api/entities';
import { Orcamento } from '@/api/entities';
import { Skeleton } from "@/components/ui/skeleton";
import { Users, UserPlus, Award } from 'lucide-react';

const formatCurrency = (value) => value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

const RelatorioClientes = ({ dateRange }) => {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (dateRange?.from && dateRange?.to) {
            loadData();
        }
    }, [dateRange]);

    const loadData = async () => {
        setLoading(true);
        try {
            const [clientes, orcamentos] = await Promise.all([
                Cliente.list(),
                Orcamento.filter({ status: 'aprovado' })
            ]);

            const clientesNovos = clientes.filter(c => {
                const dataCadastro = new Date(c.created_date);
                return dataCadastro >= dateRange.from && dataCadastro <= dateRange.to;
            });

            const orcamentosNoPeriodo = orcamentos.filter(o => {
                const dataOrcamento = new Date(o.data_orcamento);
                return dataOrcamento >= dateRange.from && dataOrcamento <= dateRange.to;
            });

            const topClientes = orcamentosNoPeriodo.reduce((acc, o) => {
                acc[o.cliente_nome] = (acc[o.cliente_nome] || 0) + (o.valor_final || 0);
                return acc;
            }, {});

            setData({
                totalClientes: clientes.length,
                clientesNovos: clientesNovos.length,
                topClientes: Object.entries(topClientes).map(([name, value]) => ({ name, value })).sort((a,b) => b.value - a.value).slice(0, 5),
            });
        } catch (error) {
            console.error("Erro ao carregar relatório de clientes:", error);
        } finally {
            setLoading(false);
        }
    };
    
    if (loading) {
        return <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6"><Skeleton className="h-24" /><Skeleton className="h-24" /><Skeleton className="h-24" /><Skeleton className="h-80 col-span-3" /></div>;
    }

    return (
        <div className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <StatCard icon={Users} title="Total de Clientes Cadastrados" value={data.totalClientes} color="blue" />
                <StatCard icon={UserPlus} title="Novos Clientes no Período" value={data.clientesNovos} color="green" />
            </div>

            <Card className="bg-white/80 backdrop-blur-sm shadow-lg">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                        <Award className="w-5 h-5 text-amber-500" />
                        Top 5 Clientes por Valor de Compra
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left text-slate-500">
                            <thead className="text-xs text-slate-700 uppercase bg-slate-100">
                                <tr>
                                    <th scope="col" className="px-6 py-3">Cliente</th>
                                    <th scope="col" className="px-6 py-3">Valor Total Comprado</th>
                                </tr>
                            </thead>
                            <tbody>
                                {data.topClientes.map(cliente => (
                                    <tr key={cliente.name} className="bg-white border-b hover:bg-slate-50">
                                        <td className="px-6 py-4 font-medium text-slate-900">{cliente.name}</td>
                                        <td className="px-6 py-4 font-bold text-green-600">{formatCurrency(cliente.value)}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
};

const StatCard = ({ icon: Icon, title, value, color }) => (
    <Card className="bg-white/80 backdrop-blur-sm shadow-lg">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{title}</CardTitle>
            <Icon className={`h-5 w-5 text-${color}-500`} />
        </CardHeader>
        <CardContent>
            <div className="text-2xl font-bold">{value}</div>
        </CardContent>
    </Card>
);

export default RelatorioClientes;