import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Orcamento } from '@/api/entities';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Skeleton } from "@/components/ui/skeleton";
import { TrendingUp, DollarSign, ShoppingCart, Users, Package } from 'lucide-react';

const formatCurrency = (value) => value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

const RelatorioVendas = ({ dateRange }) => {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (dateRange?.from && dateRange?.to) {
            loadData();
        }
    }, [dateRange]);

    const loadData = async () => {
        setLoading(true);
        try {
            const orcamentos = await Orcamento.filter({ status: 'aprovado' });
            const filtered = orcamentos.filter(o => {
                const dataOrcamento = new Date(o.data_orcamento);
                return dataOrcamento >= dateRange.from && dataOrcamento <= dateRange.to;
            });

            const totalVendas = filtered.reduce((sum, o) => sum + (o.valor_final || 0), 0);
            const numeroVendas = filtered.length;
            const ticketMedio = numeroVendas > 0 ? totalVendas / numeroVendas : 0;

            const vendasPorVendedor = filtered.reduce((acc, o) => {
                acc[o.vendedor] = (acc[o.vendedor] || 0) + (o.valor_final || 0);
                return acc;
            }, {});

            const produtosVendidos = filtered.flatMap(o => o.itens).reduce((acc, item) => {
                acc[item.produto_nome] = (acc[item.produto_nome] || 0) + item.quantidade;
                return acc;
            }, {});

            setData({
                totalVendas,
                numeroVendas,
                ticketMedio,
                vendasPorVendedor: Object.entries(vendasPorVendedor).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value),
                topProdutos: Object.entries(produtosVendidos).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value).slice(0, 5),
            });
        } catch (error) {
            console.error("Erro ao carregar relatório de vendas:", error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6"><Skeleton className="h-24" /><Skeleton className="h-24" /><Skeleton className="h-24" /><Skeleton className="h-80 col-span-3" /></div>;
    }

    return (
        <div className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <StatCard icon={DollarSign} title="Valor Total em Vendas" value={formatCurrency(data.totalVendas)} color="green" />
                <StatCard icon={ShoppingCart} title="Número de Vendas" value={data.numeroVendas} color="blue" />
                <StatCard icon={TrendingUp} title="Ticket Médio" value={formatCurrency(data.ticketMedio)} color="purple" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <ChartCard title="Vendas por Vendedor" icon={Users}>
                    <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={data.vendasPorVendedor} layout="vertical">
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis type="number" tickFormatter={formatCurrency} />
                            <YAxis type="category" dataKey="name" width={80} />
                            <Tooltip formatter={(value) => formatCurrency(value)} />
                            <Bar dataKey="value" fill="#3b82f6" />
                        </BarChart>
                    </ResponsiveContainer>
                </ChartCard>

                <ChartCard title="Top 5 Produtos Vendidos" icon={Package}>
                     <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={data.topProdutos}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" />
                            <YAxis />
                            <Tooltip />
                            <Bar dataKey="value" fill="#8b5cf6" name="Quantidade" />
                        </BarChart>
                    </ResponsiveContainer>
                </ChartCard>
            </div>
        </div>
    );
};

const StatCard = ({ icon: Icon, title, value, color }) => (
    <Card className="bg-white/80 backdrop-blur-sm shadow-lg">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{title}</CardTitle>
            <Icon className={`h-5 w-5 text-${color}-500`} />
        </CardHeader>
        <CardContent>
            <div className="text-2xl font-bold">{value}</div>
        </CardContent>
    </Card>
);

const ChartCard = ({ title, icon: Icon, children }) => (
    <Card className="bg-white/80 backdrop-blur-sm shadow-lg">
        <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
                <Icon className="w-5 h-5 text-slate-600" />
                {title}
            </CardTitle>
        </CardHeader>
        <CardContent>
            {children}
        </CardContent>
    </Card>
);

export default RelatorioVendas;