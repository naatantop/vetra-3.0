import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LancamentoFinanceiro } from '@/api/entities';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Skeleton } from "@/components/ui/skeleton";
import { DollarSign, TrendingUp, TrendingDown, ClipboardList } from 'lucide-react';

const formatCurrency = (value) => value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#ff4d4d'];

const RelatorioFinanceiro = ({ dateRange }) => {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (dateRange?.from && dateRange?.to) {
            loadData();
        }
    }, [dateRange]);

    const loadData = async () => {
        setLoading(true);
        try {
            const lancamentos = await LancamentoFinanceiro.list();
            const filtered = lancamentos.filter(l => {
                const dataLancamento = new Date(l.data_vencimento);
                return dataLancamento >= dateRange.from && dataLancamento <= dateRange.to;
            });

            const receitas = filtered.filter(l => l.tipo === 'receita').reduce((sum, l) => sum + l.valor, 0);
            const despesas = filtered.filter(l => l.tipo === 'despesa').reduce((sum, l) => sum + l.valor, 0);
            const saldo = receitas - despesas;
            
            const despesasPorCategoria = filtered.filter(l => l.tipo === 'despesa').reduce((acc, l) => {
                acc[l.categoria] = (acc[l.categoria] || 0) + l.valor;
                return acc;
            }, {});

            setData({
                receitas,
                despesas,
                saldo,
                despesasPorCategoria: Object.entries(despesasPorCategoria).map(([name, value]) => ({ name, value })).sort((a,b) => b.value - a.value),
            });
        } catch (error) {
            console.error("Erro ao carregar relatório financeiro:", error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6"><Skeleton className="h-24" /><Skeleton className="h-24" /><Skeleton className="h-24" /><Skeleton className="h-80 col-span-3" /></div>;
    }

    return (
        <div className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <StatCard icon={TrendingUp} title="Total de Receitas" value={formatCurrency(data.receitas)} color="green" />
                <StatCard icon={TrendingDown} title="Total de Despesas" value={formatCurrency(data.despesas)} color="red" />
                <StatCard icon={DollarSign} title="Saldo" value={formatCurrency(data.saldo)} color={data.saldo >= 0 ? "blue" : "red"} />
            </div>

            <ChartCard title="Despesas por Categoria" icon={ClipboardList}>
                <ResponsiveContainer width="100%" height={350}>
                    <PieChart>
                        <Pie
                            data={data.despesasPorCategoria}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={120}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        >
                            {data.despesasPorCategoria.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                        </Pie>
                        <Tooltip formatter={(value) => formatCurrency(value)} />
                        <Legend />
                    </PieChart>
                </ResponsiveContainer>
            </ChartCard>
        </div>
    );
};

const StatCard = ({ icon: Icon, title, value, color }) => (
    <Card className="bg-white/80 backdrop-blur-sm shadow-lg">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{title}</CardTitle>
            <Icon className={`h-5 w-5 text-${color}-500`} />
        </CardHeader>
        <CardContent>
            <div className="text-2xl font-bold">{value}</div>
        </CardContent>
    </Card>
);

const ChartCard = ({ title, icon: Icon, children }) => (
    <Card className="bg-white/80 backdrop-blur-sm shadow-lg">
        <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
                <Icon className="w-5 h-5 text-slate-600" />
                {title}
            </CardTitle>
        </CardHeader>
        <CardContent>
            {children}
        </CardContent>
    </Card>
);

export default RelatorioFinanceiro;