import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  Edit, 
  Trash2, 
  Search, 
  AlertTriangle,
  Package,
  Eye
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

const formatCurrency = (value) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(value || 0);
};

const getCategoriaColor = (categoria) => {
  const colors = {
    'vidro_temperado': 'bg-blue-100 text-blue-800 border-blue-200',
    'vidro_laminado': 'bg-purple-100 text-purple-800 border-purple-200',
    'vidro_comum': 'bg-gray-100 text-gray-800 border-gray-200',
    'esquadria_aluminio': 'bg-cyan-100 text-cyan-800 border-cyan-200',
    'esquadria_ferro': 'bg-orange-100 text-orange-800 border-orange-200',
    'acessorios': 'bg-green-100 text-green-800 border-green-200',
    'ferragens': 'bg-yellow-100 text-yellow-800 border-yellow-200',
    'silicone': 'bg-pink-100 text-pink-800 border-pink-200',
    'outros': 'bg-slate-100 text-slate-800 border-slate-200'
  };
  return colors[categoria] || 'bg-gray-100 text-gray-800 border-gray-200';
};

const getCategoriaLabel = (categoria) => {
  const labels = {
    'vidro_temperado': 'Vidro Temperado',
    'vidro_laminado': 'Vidro Laminado',
    'vidro_comum': 'Vidro Comum',
    'esquadria_aluminio': 'Esquadria',
    'esquadria_ferro': 'Esquadria',
    'acessorios': 'Acessório',
    'ferragens': 'Ferragem',
    'silicone': 'Silicone',
    'outros': 'Outros'
  };
  return labels[categoria] || categoria;
};

const getStatusColor = (status) => {
  if (status === 'ativo') return 'bg-green-100 text-green-800';
  if (status === 'inativo') return 'bg-red-100 text-red-800';
  return 'bg-gray-100 text-gray-800';
};

export default function ListaProdutos({ 
  produtos, 
  isLoading, 
  onEdit, 
  onDelete, 
  onView,
  filtros,
  onFiltroChange 
}) {
  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex gap-4">
          <Skeleton className="h-10 flex-1" />
          <Skeleton className="h-10 w-48" />
        </div>
        <div className="grid grid-cols-3 gap-6 mb-6">
          {[1,2,3].map(i => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
        <Card>
          <CardContent className="p-0">
            <div className="space-y-3 p-6">
              {[1,2,3,4,5].map(i => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const produtosFiltrados = produtos.filter(produto => {
    const matchNome = !filtros.busca || 
      produto.nome.toLowerCase().includes(filtros.busca.toLowerCase()) ||
      produto.codigo.toLowerCase().includes(filtros.busca.toLowerCase());
    
    const matchCategoria = !filtros.categoria || produto.categoria === filtros.categoria;
    const matchStatus = !filtros.status || produto.status === filtros.status;
    
    return matchNome && matchCategoria && matchStatus;
  });

  const produtosAtivos = produtos.filter(p => p.status === 'ativo').length;
  const produtosEstoqueBaixo = produtos.filter(p => 
    (p.estoque_atual || 0) <= (p.estoque_minimo || 0)
  ).length;

  return (
    <div className="space-y-4">
      {/* Filtros */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Buscar por nome..."
            value={filtros.busca}
            onChange={(e) => onFiltroChange('busca', e.target.value)}
            className="pl-10 bg-white border-gray-300"
          />
        </div>
        <Select value={filtros.categoria} onValueChange={(value) => onFiltroChange('categoria', value === 'todas' ? '' : value)}>
          <SelectTrigger className="w-48 bg-white border-gray-300">
            <SelectValue placeholder="Todas as Categorias" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todas">Todas as Categorias</SelectItem>
            <SelectItem value="vidro_temperado">Vidro Temperado</SelectItem>
            <SelectItem value="vidro_comum">Vidro Comum</SelectItem>
            <SelectItem value="esquadria_aluminio">Esquadria</SelectItem>
            <SelectItem value="acessorios">Acessório</SelectItem>
            <SelectItem value="ferragens">Espelhos</SelectItem>
            <SelectItem value="outros">ACM</SelectItem>
            <SelectItem value="silicone">Ferro PVC</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Cards de Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-white">
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">{produtos.length}</div>
            <p className="text-gray-600 text-sm">Total de Produtos</p>
          </CardContent>
        </Card>
        <Card className="bg-white">
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-green-600 mb-2">{produtosAtivos}</div>
            <p className="text-gray-600 text-sm">Produtos Ativos</p>
          </CardContent>
        </Card>
        <Card className="bg-white">
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-red-600 mb-2">{produtosEstoqueBaixo}</div>
            <p className="text-gray-600 text-sm">Estoque Baixo</p>
          </CardContent>
        </Card>
      </div>

      {/* Tabela */}
      <Card className="bg-white">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-b">
                <TableHead className="text-gray-600 font-medium py-4 px-6">NOME</TableHead>
                <TableHead className="text-gray-600 font-medium py-4 px-6">PREÇO</TableHead>
                <TableHead className="text-gray-600 font-medium py-4 px-6">ESTOQUE</TableHead>
                <TableHead className="text-gray-600 font-medium py-4 px-6">CATEGORIA</TableHead>
                <TableHead className="text-gray-600 font-medium py-4 px-6">STATUS</TableHead>
                <TableHead className="text-gray-600 font-medium py-4 px-6 text-right">AÇÕES</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {produtosFiltrados.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-12">
                    <Package className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p className="text-gray-500">Nenhum produto encontrado</p>
                  </TableCell>
                </TableRow>
              ) : (
                produtosFiltrados.map((produto) => {
                  const estoqueBaixo = (produto.estoque_atual || 0) <= (produto.estoque_minimo || 0);
                  
                  return (
                    <TableRow key={produto.id} className="border-b hover:bg-gray-50">
                      <TableCell className="py-4 px-6">
                        <div>
                          <p className="font-medium text-gray-900">{produto.nome}</p>
                          <p className="text-sm text-gray-500">#{produto.codigo}</p>
                        </div>
                      </TableCell>
                      <TableCell className="py-4 px-6">
                        <div className="font-medium text-gray-900">{formatCurrency(produto.preco_venda)}</div>
                      </TableCell>
                      <TableCell className="py-4 px-6">
                        <div className="flex items-center gap-2">
                          <span className={`font-medium ${estoqueBaixo ? 'text-red-600' : 'text-gray-900'}`}>
                            {produto.estoque_atual || 0} {produto.unidade}
                          </span>
                          {estoqueBaixo && <AlertTriangle className="w-4 h-4 text-red-500" />}
                        </div>
                      </TableCell>
                      <TableCell className="py-4 px-6">
                        <Badge className={`${getCategoriaColor(produto.categoria)} border-0 rounded-full px-3 py-1`}>
                          {getCategoriaLabel(produto.categoria)}
                        </Badge>
                      </TableCell>
                      <TableCell className="py-4 px-6">
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${produto.status === 'ativo' ? 'bg-green-500' : 'bg-red-500'}`}></div>
                          <Badge className={`${getStatusColor(produto.status)} border-0 rounded-full px-3 py-1`}>
                            {produto.status === 'ativo' ? 'Ativo' : 'Inativo'}
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell className="py-4 px-6 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => onView(produto)}
                            className="h-8 w-8 text-gray-400 hover:text-gray-600"
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => onEdit(produto)}
                            className="h-8 w-8 text-blue-500 hover:text-blue-700"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => onDelete(produto)}
                            className="h-8 w-8 text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}