
import React from 'react';
import { Edit, Trash2, Power, PowerOff, AlertTriangle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { getAllCategorias, getCategoriaLabel } from '../utils/CategoriaUtils';

export default function TabelaProdutos({ produtos, onEditar, onExcluir, onToggleAtivo, loading = false, userRole }) {
  const getStatusBadge = (ativo) => {
    return ativo !== false
      ? <Badge className="bg-green-100 text-green-800 border-green-200">Ativo</Badge> 
      : <Badge className="bg-red-100 text-red-800 border-red-200">Inativo</Badge>;
  };

  const getCategoryBadge = (categoria) => {
    // categoryColors moved here as per instructions
    const categoryColors = {
      vidro_temperado: 'bg-blue-100 text-blue-800 border-blue-200',
      vidro_comum: 'bg-sky-100 text-sky-800 border-sky-200',
      esquadria: 'bg-slate-200 text-slate-800 border-slate-300',
      acessorio: 'bg-purple-100 text-purple-800 border-purple-200',
      espelhos: 'bg-teal-100 text-teal-800 border-teal-200',
      acm: 'bg-orange-100 text-orange-800 border-orange-200',
      forro_pvc: 'bg-green-100 text-green-800 border-green-200',
    };
    
    const colorClass = categoryColors[categoria] || 'bg-gray-100 text-gray-800';
    return (
      <Badge className={colorClass}>
        {getCategoriaLabel(categoria)}
      </Badge>
    );
  };

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-8 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="text-slate-500 mt-4">Carregando produtos...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-slate-200">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                Nome
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                Preço
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                Estoque
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                Categoria
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                Ações
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-slate-200">
            {produtos.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-6 py-8 text-center text-slate-500">
                  Nenhum produto encontrado
                </td>
              </tr>
            ) : (
              produtos.map(produto => {
                const estoque = produto.estoque_atual || produto.estoque || 0;
                const preco = produto.preco_venda || produto.preco || 0;
                const isLowStock = estoque > 0 && estoque <= (produto.estoque_minimo || 0);

                return (
                  <tr key={produto.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">
                      <div>
                        <p className="font-medium">{produto.nome}</p>
                        {produto.codigo && (
                          <p className="text-xs text-slate-500">{produto.codigo}</p>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-900">
                      {preco.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-900">
                      <div className={`flex items-center gap-2 ${isLowStock ? 'text-orange-600 font-semibold' : ''} ${estoque === 0 ? 'text-red-600 font-semibold' : ''}`}>
                        {produto.tipo_medida === 'kit' ? (
                           <Badge variant="secondary" className="bg-indigo-100 text-indigo-800">Kit com {produto.componentes_kit?.length || 0} itens</Badge>
                        ) : (
                          <>
                            <span>{estoque}</span>
                            {produto.unidade && (
                              <span className="text-xs text-slate-500">{produto.unidade}</span>
                            )}
                            {isLowStock && <AlertTriangle className="w-4 h-4" title="Estoque baixo!" />}
                          </>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-900">
                      {getCategoryBadge(produto.categoria)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-900">
                      <div className="flex items-center gap-2">
                        {getStatusBadge(produto.ativo)}
                        <button
                          onClick={() => onToggleAtivo(produto)}
                          className={`p-1 rounded-md transition-colors ${
                            produto.ativo !== false
                              ? 'hover:bg-red-100 text-red-600' 
                              : 'hover:bg-green-100 text-green-600'
                          }`}
                          title={produto.ativo !== false ? "Desativar produto" : "Ativar produto"}
                        >
                          {produto.ativo !== false ? (
                            <PowerOff className="w-4 h-4" />
                          ) : (
                            <Power className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-900">
                      <div className="flex gap-2">
                        <button
                          onClick={() => onEditar(produto)}
                          className="p-2 hover:bg-blue-100 rounded-lg transition-colors"
                          title="Editar Produto"
                        >
                          <Edit className="w-4 h-4 text-blue-600" />
                        </button>
                        {userRole === 'admin' && (
                          <button
                            onClick={() => onExcluir(produto)}
                            className="p-2 hover:bg-red-100 rounded-lg transition-colors"
                            title="Excluir Produto"
                          >
                            <Trash2 className="w-4 h-4 text-red-600" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
