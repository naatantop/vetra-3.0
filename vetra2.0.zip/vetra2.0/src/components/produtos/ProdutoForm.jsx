import React, { useState, useEffect } from 'react';
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import Button from "../ui/Button";
import { PlusSquare, Trash2, FileText, Zap, Search, AlertCircle } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Produto } from '@/api/entities';
import { getAllCategorias } from '../utils/CategoriaUtils';

const tiposMedida = [
    { value: 'unidade', label: 'Unidade', unidade: 'und' },
    { value: 'm2', label: 'M² (m²)', unidade: 'm²' },
    { value: 'metro', label: 'Metro', unidade: 'ml' },
    { value: 'kit', label: 'Kit de Produtos', unidade: 'kit' },
];

const getUnidadeAutomatica = (tipoMedida) => {
  switch (tipoMedida) {
    case 'm2': return 'm²';
    case 'metro': return 'ml';
    case 'kit': return 'kit';
    case 'unidade':
    default: return 'und';
  }
};

export default function ProdutoForm({ produtoInicial, onSubmitSuccess, onCancel, allProdutos = [] }) {
  const produto = produtoInicial || {};
  const [produtoSelecionado, setProdutoSelecionado] = useState(null); // New state for selected product to update
  const [loading, setLoading] = useState(false); // Internal loading state

  // Get dynamic categories
  const categorias = getAllCategorias();

  const [form, setForm] = useState(() => {
    let initialTipoMedidaForUI = 'unidade';
    if (produto.tipo_medida === 'unitario') {
      initialTipoMedidaForUI = 'unidade';
    } else if (produto.tipo_medida === 'metro_linear') {
      initialTipoMedidaForUI = 'metro';
    } else if (produto.tipo_medida) {
      initialTipoMedidaForUI = produto.tipo_medida;
    }
    
    return {
      nome: produto.nome || '',
      descricao: produto.descricao || '',
      codigo: produto.codigo || '',
      preco_venda: produto.preco_venda || produto.preco || '',
      preco_custo: produto.preco_custo || '',
      estoque_atual: produto.estoque_atual || produto.estoque || 0,
      estoque_minimo: produto.estoque_minimo || 0,
      categoria: produto.categoria || '',
      unidade: produto.unidade || getUnidadeAutomatica(initialTipoMedidaForUI),
      largura_mm: produto.largura_mm || '',
      altura_mm: produto.altura_mm || '',
      comprimento_mm: produto.comprimento_mm || '',
      quantidade: produto.quantidade || 1,
      tipo_medida: initialTipoMedidaForUI,
      componentes_kit: produto.componentes_kit || [],
      ativo: produto.ativo ?? true,
      ncm: produto.ncm || '',
      cfop: produto.cfop || '',
    };
  });
  
  const [novoComponente, setNovoComponente] = useState({ produtoId: '', quantidade: 1 });
  const [searchExisting, setSearchExisting] = useState('');

  useEffect(() => {
    setForm(prev => ({ ...prev, unidade: getUnidadeAutomatica(prev.tipo_medida) }));
  }, [form.tipo_medida]);

  function handleChange(e) {
    const { name, value, type, checked } = e.target;
    setForm({ ...form, [name]: type === 'checkbox' ? checked : value });
  }
  
  const handleSelectExistingProduct = (p) => {
    setProdutoSelecionado(p); // Guarda o produto selecionado para a lógica de atualização

    let tipoMedidaForUI = 'unidade';
    if (p.tipo_medida === 'unitario') tipoMedidaForUI = 'unidade';
    else if (p.tipo_medida === 'metro_linear') tipoMedidaForUI = 'metro';
    else if (p.tipo_medida) tipoMedidaForUI = p.tipo_medida;

    setForm({
        // Manter a definição do produto
        nome: p.nome || '',
        descricao: p.descricao || '',
        codigo: p.codigo || '',
        categoria: p.categoria || '',
        unidade: p.unidade || getUnidadeAutomatica(tipoMedidaForUI),
        largura_mm: p.largura_mm || '',
        altura_mm: p.altura_mm || '',
        comprimento_mm: p.comprimento_mm || '',
        tipo_medida: tipoMedidaForUI,
        componentes_kit: p.componentes_kit || [],
        ativo: p.ativo ?? true,
        ncm: p.ncm || '',
        cfop: p.cfop || '',
        estoque_minimo: p.estoque_minimo || 0,

        // Resetar para novos valores
        preco_venda: '',
        preco_custo: '',
        estoque_atual: 0, // Campo agora representa "quantidade a adicionar"
        quantidade: 1, 
    });
  };

  const calcularQuantidadeParaAdicionar = () => {
    const quantidade = parseFloat(form.quantidade) || 1;
    
    switch (form.tipo_medida) {
      case 'm2':
        if (form.largura_mm && form.altura_mm) {
          return (parseFloat(form.largura_mm) * parseFloat(form.altura_mm) * quantidade) / 1_000_000;
        }
        break;
      case 'metro':
        if (form.comprimento_mm) {
          return (parseFloat(form.comprimento_mm) * quantidade) / 1000;
        }
        break;
      case 'unidade':
      case 'kit':
      default:
        return quantidade;
    }
    return 0;
  };

  const handleAdicionarEstoque = () => {
    const quantidadeCalculada = calcularQuantidadeParaAdicionar();
    
    if (quantidadeCalculada <= 0) {
      alert("Preencha os campos necessários para o cálculo.");
      return;
    }

    const estoqueAtual = parseFloat(form.estoque_atual) || 0;
    const novoEstoque = estoqueAtual + quantidadeCalculada;
    
    setForm(prevForm => ({
      ...prevForm,
      estoque_atual: novoEstoque.toFixed(3),
    }));
  };

  const getPreview = () => {
    const quantidade = parseFloat(form.quantidade) || 1;
    
    switch (form.tipo_medida) {
      case 'm2':
        if (form.largura_mm && form.altura_mm) {
          const areaPorPeca = (parseFloat(form.largura_mm) * parseFloat(form.altura_mm)) / 1_000_000;
          const areaTotal = areaPorPeca * quantidade;
          return {
            porPeca: `${areaPorPeca.toFixed(3)} m²`,
            total: `${areaTotal.toFixed(3)} m²`,
            calculo: `${form.largura_mm}mm × ${form.altura_mm}mm × ${quantidade} peças`
          };
        }
        break;
      case 'metro':
        if (form.comprimento_mm) {
          const metroPorPeca = parseFloat(form.comprimento_mm) / 1000;
          const metroTotal = metroPorPeca * quantidade;
          return {
            porPeca: `${metroPorPeca.toFixed(3)} ml`,
            total: `${metroTotal.toFixed(3)} ml`,
            calculo: `${form.comprimento_mm}mm × ${quantidade} peças`
          };
        }
        break;
      case 'unidade':
        return {
          porPeca: '1 peça',
          total: `${quantidade} peças`,
          calculo: `${quantidade} unidades`
        };
      case 'kit':
        const totalComponentes = form.componentes_kit.reduce((sum, comp) => sum + comp.quantidade, 0);
        return {
          porPeca: `${totalComponentes} itens por kit`,
          total: `${totalComponentes * quantidade} itens total`,
          calculo: `${quantidade} kits × ${totalComponentes} itens cada`
        };
    }
    return null;
  };

  const handleAddComponente = () => {
    if (!novoComponente.produtoId || novoComponente.quantidade <= 0) {
        alert("Selecione um produto e uma quantidade válida.");
        return;
    }
    const produtoSelecionadoForKit = allProdutos.find(p => p.id === novoComponente.produtoId);
    if (!produtoSelecionadoForKit) return;

    if (form.componentes_kit.some(c => c.produtoId === produtoSelecionadoForKit.id)) {
        alert("Este componente já foi adicionado ao kit.");
        return;
    }

    const componenteParaAdicionar = {
        produtoId: produtoSelecionadoForKit.id,
        nome: produtoSelecionadoForKit.nome,
        quantidade: parseInt(novoComponente.quantidade)
    };

    setForm(prev => ({ ...prev, componentes_kit: [...prev.componentes_kit, componenteParaAdicionar] }));
    setNovoComponente({ produtoId: '', quantidade: 1 });
  };

  const handleRemoveComponente = (produtoIdToRemove) => {
    setForm(prev => ({ ...prev, componentes_kit: prev.componentes_kit.filter(c => c.produtoId !== produtoIdToRemove) }));
  };

  const prepareProductDataForSubmission = (formData, isUpdate, originalProduct = {}) => {
    const data = { ...formData };
  
    // Convert numeric fields
    const numericFields = ['preco_venda', 'preco_custo', 'estoque_atual', 'largura_mm', 'altura_mm', 'comprimento_mm'];
    numericFields.forEach(key => {
      data[key] = parseFloat(data[key]) || 0;
    });
  
    const intFields = ['estoque_minimo', 'quantidade'];
    intFields.forEach(key => {
      data[key] = parseInt(data[key], 10) || 0;
    });
  
    // Handle stock addition for update mode (when selecting from card)
    if (isUpdate) {
      const quantidadeAdicionar = data.estoque_atual; // estoque_atual from form is now "quantity to add"
      const estoqueExistente = parseFloat(originalProduct.estoque_atual || originalProduct.estoque || 0);
      data.estoque_atual = estoqueExistente + quantidadeAdicionar;
  
      // For update mode, if price/cost fields are empty in form, keep original values
      data.preco_venda = data.preco_venda || parseFloat(originalProduct.preco_venda || originalProduct.preco || 0);
      data.preco_custo = data.preco_custo || parseFloat(originalProduct.preco_custo || 0);
    }
  
    // Alias preco_venda to preco, estoque_atual to estoque for API consistency
    data.preco = data.preco_venda;
    data.estoque = data.estoque_atual;
  
    // Convert tipo_medida for backend
    if (data.tipo_medida === 'unidade') {
      data.tipo_medida = 'unitario';
    } else if (data.tipo_medida === 'metro') {
      data.tipo_medida = 'metro_linear';
    }
  
    return data;
  };

  async function handleSubmit(e) {
    e.preventDefault();
    if (!form.nome || !form.categoria) {
      return alert("Nome e Categoria são obrigatórios.");
    }
    
    setLoading(true);

    // MODO ATUALIZAÇÃO: Quando um produto existente é selecionado no card (não é produtoInicial)
    const isUpdateMode = !!produtoSelecionado && !produtoInicial;
    if (isUpdateMode) {
      const dataToUpdate = prepareProductDataForSubmission(form, true, produtoSelecionado);
      
      try {
        await Produto.update(produtoSelecionado.id, dataToUpdate);
        onSubmitSuccess();
      } catch(error) {
        console.error("Erro ao atualizar produto:", error);
        alert("Falha ao atualizar o produto.");
      } finally {
        setLoading(false);
      }
      return;
    }

    // MODO EDIÇÃO/CRIAÇÃO: Quando editando da tabela (produtoInicial existe) ou criando do zero
    const dataToSubmit = prepareProductDataForSubmission(form, false, produtoInicial);
    
    try {
      if (produto.id) { // Editando
        dataToSubmit.id = produto.id; // Ensure ID is present for update
        await Produto.update(produto.id, dataToSubmit);
      } else { // Criando
        await Produto.create(dataToSubmit);
      }
      onSubmitSuccess();
    } catch(error) {
        console.error("Erro ao salvar produto:", error);
        alert("Falha ao salvar produto.");
    } finally {
        setLoading(false);
    }
  }

  const productsAvailableForKit = allProdutos.filter(p => p.id !== (produto.id || null) && p.tipo_medida !== 'kit');
  const preview = getPreview();
  
  // Filtrar produtos por categoria selecionada e busca
  const filteredExistingProducts = allProdutos.filter(p => {
    // Se há uma categoria selecionada, mostrar apenas produtos dessa categoria
    const categoriaMatch = !form.categoria || p.categoria === form.categoria;
    
    // Filtro de busca por nome ou código
    const searchMatch = !searchExisting || 
      p.nome.toLowerCase().includes(searchExisting.toLowerCase()) ||
      (p.codigo && p.codigo.toLowerCase().includes(searchExisting.toLowerCase()));
    
    return categoriaMatch && searchMatch;
  });
  
  const isUpdateMode = !!produtoSelecionado && !produtoInicial;

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Coluna da Esquerda: Campos principais */}
        <div className="space-y-6">
          <div>
            <label htmlFor="categoria" className="block text-sm font-medium text-slate-700 mb-2">Categoria <span className="text-red-500">*</span></label>
            <select 
              id="categoria" 
              name="categoria" 
              value={form.categoria} 
              onChange={handleChange} 
              required 
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
            >
              <option value="">Selecione uma categoria...</option>
              {categorias.map((cat) => <option key={cat.value} value={cat.value}>{cat.label}</option>)}
            </select>
          </div>
          <div>
            <label htmlFor="nome" className="block text-sm font-medium text-slate-700 mb-2">Nome do Produto <span className="text-red-500">*</span></label>
            <Input id="nome" name="nome" value={form.nome} onChange={handleChange} placeholder="Ex: Vidro Temperado 8mm" required />
          </div>
          <div>
            <label htmlFor="descricao" className="block text-sm font-medium text-slate-700 mb-2">Descrição</label>
            <Textarea id="descricao" name="descricao" value={form.descricao} onChange={handleChange} placeholder="Detalhes do produto..." rows={3} />
          </div>
        </div>

        {/* Coluna da Direita: Card "Produtos" */}
        <div>
          {!produtoInicial && (
            <Card className="bg-slate-50 border-slate-200 h-full">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-base">
                        <Zap className="w-5 h-5 text-blue-600" />
                        Produtos
                    </CardTitle>
                     <p className="text-sm text-slate-500 pt-1">
                        {form.categoria 
                          ? `Produtos da categoria: ${categorias.find(c => c.value === form.categoria)?.label || form.categoria}`
                          : 'Selecione uma categoria para ver os produtos disponíveis'
                        }
                    </p>
                </CardHeader>
                <CardContent>
                    <div className="relative mb-3">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                        <Input 
                            placeholder="Buscar por nome ou código..."
                            value={searchExisting}
                            onChange={(e) => setSearchExisting(e.target.value)}
                            className="pl-10"
                        />
                    </div>
                    <div className="max-h-48 overflow-y-auto space-y-2 pr-2">
                        {filteredExistingProducts.length > 0 ? filteredExistingProducts.map(p => (
                            <div 
                                key={p.id}
                                onClick={() => handleSelectExistingProduct(p)}
                                className="p-3 bg-white rounded-lg border border-slate-200 hover:bg-blue-50 hover:border-blue-300 cursor-pointer transition-colors"
                            >
                                <p className="font-semibold text-slate-800">{p.nome}</p>
                                <p className="text-xs text-slate-500">{p.codigo || 'Sem código'}</p>
                                <p className="text-xs text-slate-400">{categorias.find(c => c.value === p.categoria)?.label}</p>
                            </div>
                        )) : (
                            <div className="text-center text-sm text-slate-500 py-4">
                                {form.categoria 
                                  ? 'Nenhum produto encontrado nesta categoria.' 
                                  : 'Selecione uma categoria primeiro.'
                                }
                            </div>
                        )}
                    </div>
                </CardContent>
            </Card>
          )}
        </div>
      </div>
      
      {isUpdateMode && (
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-blue-600"/>
              <div>
                <p className="font-semibold text-blue-800">Atualizando Preço e Estoque</p>
                <p className="text-sm text-blue-700">
                    Você está atualizando o produto: <span className="font-bold">{produtoSelecionado.nome}</span>. 
                    O valor em "Quantidade a Adicionar" será somado ao estoque atual de <span className="font-bold">{produtoSelecionado.estoque_atual}</span>.
                </p>
              </div>
          </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div>
          <label htmlFor="codigo" className="block text-sm font-medium text-slate-700 mb-2">Código</label>
          <Input id="codigo" name="codigo" value={form.codigo} onChange={handleChange} placeholder="Ex: VT-8MM" />
        </div>

        <div>
          <label htmlFor="tipo_medida" className="block text-sm font-medium text-slate-700 mb-2">Tipo de Medida</label>
          <select id="tipo_medida" name="tipo_medida" value={form.tipo_medida} onChange={handleChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white">
            {tiposMedida.map((tipo) => <option key={tipo.value} value={tipo.value}>{tipo.label}</option>)}
          </select>
        </div>

        <div>
          <label htmlFor="preco_custo" className="block text-sm font-medium text-slate-700 mb-2">Preço de Custo (R$)</label>
          <Input id="preco_custo" name="preco_custo" type="number" step="0.01" min="0" value={form.preco_custo} onChange={handleChange} placeholder={isUpdateMode ? `Atual: ${parseFloat(produtoSelecionado.preco_custo || 0).toFixed(2)}` : "0,00"} />
        </div>

        <div>
          <label htmlFor="preco_venda" className="block text-sm font-medium text-slate-700 mb-2">Preço de Venda (R$) <span className="text-red-500">*</span></label>
          <Input id="preco_venda" name="preco_venda" type="number" step="0.01" min="0" value={form.preco_venda} onChange={handleChange} placeholder={isUpdateMode ? `Atual: ${parseFloat(produtoSelecionado.preco_venda || produtoSelecionado.preco || 0).toFixed(2)}` : "0,00"} required />
        </div>

        <div>
          <label htmlFor="unidade" className="block text-sm font-medium text-slate-700 mb-2">Unidade (Automática)</label>
          <Input id="unidade" name="unidade" value={form.unidade} readOnly className="bg-slate-100 cursor-not-allowed" />
        </div>

        <div className="lg:col-span-2">
          <label htmlFor="quantidade" className="block text-sm font-medium text-slate-700 mb-2">Quantidade (para cálculo de estoque)</label>
          <Input id="quantidade" name="quantidade" type="number" min="1" step="1" value={form.quantidade} onChange={handleChange} placeholder="1" />
        </div>
      </div>

      {(form.tipo_medida === 'm2' || form.tipo_medida === 'metro') && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 bg-slate-50 rounded-lg border">
          {form.tipo_medida === 'm2' && (
            <>
              <div>
                <label htmlFor="largura_mm" className="block text-sm font-medium text-slate-700 mb-2">Largura (mm)</label>
                <Input id="largura_mm" name="largura_mm" type="number" min="0" value={form.largura_mm} onChange={handleChange} placeholder="Ex: 1000" />
              </div>
              <div>
                <label htmlFor="altura_mm" className="block text-sm font-medium text-slate-700 mb-2">Altura (mm)</label>
                <Input id="altura_mm" name="altura_mm" type="number" min="0" value={form.altura_mm} onChange={handleChange} placeholder="Ex: 800" />
              </div>
            </>
          )}

          {form.tipo_medida === 'metro' && (
            <div>
              <label htmlFor="comprimento_mm" className="block text-sm font-medium text-slate-700 mb-2">Comprimento (mm)</label>
              <Input id="comprimento_mm" name="comprimento_mm" type="number" min="0" value={form.comprimento_mm} onChange={handleChange} placeholder="Ex: 6000" />
            </div>
          )}
        </div>
      )}

      {form.tipo_medida === 'kit' && (
        <div className="space-y-4 p-4 bg-slate-50 rounded-lg border">
          <h4 className="font-semibold text-slate-800">Componentes do Kit</h4>
          <div className="space-y-2">
            {form.componentes_kit.map(comp => (
              <div key={comp.produtoId} className="flex items-center gap-2 bg-white p-2 rounded-md border">
                <span className="flex-1 text-sm">{comp.nome}</span>
                <span className="text-sm font-medium">Qtd: {comp.quantidade}</span>
                <Button type="button" variant="ghost" size="small" onClick={() => handleRemoveComponente(comp.produtoId)}><Trash2 className="w-4 h-4 text-red-500"/></Button>
              </div>
            ))}
          </div>
          <div className="flex items-end gap-2 pt-4 border-t">
            <div className="flex-1">
                <Label className="block text-sm font-medium text-slate-700 mb-1">Adicionar Produto</Label>
                <select value={novoComponente.produtoId} onChange={e => setNovoComponente({...novoComponente, produtoId: e.target.value})} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white">
                    <option value="">Selecione um produto...</option>
                    {productsAvailableForKit.map(p => <option key={p.id} value={p.id}>{p.nome}</option>)}
                </select>
            </div>
            <div>
                <Label className="block text-sm font-medium text-slate-700 mb-1">Qtd.</Label>
                <Input type="number" min="1" value={novoComponente.quantidade} onChange={e => setNovoComponente({...novoComponente, quantidade: e.target.value})} className="w-20"/>
            </div>
            <Button type="button" variant="outline" onClick={handleAddComponente}>Adicionar</Button>
          </div>
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-indigo-600" />
            Dados Fiscais
          </CardTitle>
          <p className="text-sm text-slate-500">
            Informações necessárias para a emissão de Notas Fiscais (NF-e).
          </p>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="ncm">NCM</Label>
            <Input
              id="ncm"
              name="ncm"
              value={form.ncm}
              onChange={handleChange}
              placeholder="Ex: 7007.19.00"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="cfop">CFOP</Label>
            <Input
              id="cfop"
              name="cfop"
              value={form.cfop}
              onChange={handleChange}
              placeholder="Ex: 5102"
            />
          </div>
        </CardContent>
      </Card>

      {preview && (
        <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
          <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
            <div>
              <p className="text-green-800 font-semibold mb-2">📐 Preview do Cálculo:</p>
              <p className="text-green-700 text-sm">
                Por unidade: <span className="font-bold">{preview.porPeca}</span>
              </p>
              <p className="text-green-700 text-sm">
                Total a adicionar: <span className="font-bold">{preview.total}</span>
              </p>
              <p className="text-xs text-green-600 mt-1">
                Cálculo: {preview.calculo}
              </p>
            </div>
            <Button
              type="button"
              variant="secondary"
              size="small"
              onClick={handleAdicionarEstoque}
              icon={<PlusSquare size={16} />}
            >
              Adicionar ao Estoque
            </Button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6 border-t">
        <div>
          <label htmlFor="estoque_atual" className="block text-sm font-medium text-slate-700 mb-2">
            {isUpdateMode ? 'Quantidade a Adicionar' : `Estoque Atual (${form.unidade})`}
          </label>
          <Input id="estoque_atual" name="estoque_atual" type="number" min="0" step="any" value={form.estoque_atual} onChange={handleChange} placeholder="0" />
        </div>
        <div>
          <label htmlFor="estoque_minimo" className="block text-sm font-medium text-slate-700 mb-2">Estoque Mínimo ({form.unidade})</label>
          <Input id="estoque_minimo" name="estoque_minimo" type="number" min="0" step="1" value={form.estoque_minimo} onChange={handleChange} placeholder="0" />
        </div>
        <div className="flex items-center">
          <label htmlFor="ativo-toggle" className="relative inline-flex items-center cursor-pointer">
            <input id="ativo-toggle" name="ativo" type="checkbox" checked={form.ativo} onChange={handleChange} className="sr-only peer"/>
            <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            <span className="ml-3 text-sm font-medium text-slate-700">Produto Ativo</span>
          </label>
        </div>
      </div>

      <div className="flex justify-end gap-4 pt-6 border-t border-slate-200">
        <Button type="button" variant="outline" onClick={onCancel} disabled={loading}>Cancelar</Button>
        <Button type="submit" disabled={loading} loading={loading}>
          {loading ? 'Salvando...' : (produtoInicial || isUpdateMode) ? 'Atualizar Produto' : 'Salvar Produto'}
        </Button>
      </div>
    </form>
  );
}