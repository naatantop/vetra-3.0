
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { X, Edit, AlertTriangle, Package, DollarSign, Layers } from "lucide-react";

const formatCurrency = (value) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(value || 0);
};

const getCategoriaColor = (categoria) => {
  const colors = {
    'vidro_temperado': 'bg-blue-100 text-blue-800 border-blue-200',
    'vidro_laminado': 'bg-purple-100 text-purple-800 border-purple-200',
    'vidro_comum': 'bg-gray-100 text-gray-800 border-gray-200',
    'esquadria_aluminio': 'bg-cyan-100 text-cyan-800 border-cyan-200',
    'esquadria_ferro': 'bg-orange-100 text-orange-800 border-orange-200',
    'acessorios': 'bg-green-100 text-green-800 border-green-200',
    'ferragens': 'bg-yellow-100 text-yellow-800 border-yellow-200',
    'silicone': 'bg-pink-100 text-pink-800 border-pink-200',
    'outros': 'bg-slate-100 text-slate-800 border-slate-200'
  };
  return colors[categoria] || 'bg-gray-100 text-gray-800 border-gray-200';
};

export default function DetalheProduto({ produto, onClose, onEdit }) {
  if (!produto) return null;

  const estoquebaixo = (produto.estoque_atual || 0) <= (produto.estoque_minimo || 0);
  const lucroUnitario = (produto.preco_venda || 0) - (produto.preco_custo || 0);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <Card className="bg-white max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <CardHeader className="pb-4 border-b">
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-xl font-bold text-slate-900 mb-2">
                {produto.nome}
              </CardTitle>
              <div className="flex items-center gap-2">
                <Badge className={`${getCategoriaColor(produto.categoria)} border`}>
                  {produto.categoria?.replace('_', ' ')}
                </Badge>
                <Badge variant="outline">#{produto.codigo}</Badge>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        
        <CardContent className="p-6 space-y-6">
          {/* Informações Gerais */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-slate-50">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-500/10 rounded-lg">
                    <Package className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Estoque Atual</p>
                    <p className={`text-lg font-bold ${estoquebaixo ? 'text-red-600' : 'text-slate-900'}`}>
                      {produto.estoque_atual || 0} {produto.unidade}
                    </p>
                    {estoquebaixo && (
                      <p className="text-xs text-red-600 flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" />
                        Estoque baixo
                      </p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-50">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-emerald-500/10 rounded-lg">
                    <DollarSign className="w-5 h-5 text-emerald-600" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Preço de Venda</p>
                    <p className="text-lg font-bold text-slate-900">
                      {formatCurrency(produto.preco_venda)}
                    </p>
                    <p className="text-xs text-slate-500">
                      Margem: {(produto.margem_lucro || 0).toFixed(1)}%
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-50">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-purple-500/10 rounded-lg">
                    <Layers className="w-5 h-5 text-purple-600" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Lucro Unitário</p>
                    <p className={`text-lg font-bold ${
                      lucroUnitario > 0 ? 'text-emerald-600' : 'text-red-600'
                    }`}>
                      {formatCurrency(lucroUnitario)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Detalhes Financeiros */}
          <div className="bg-slate-50 p-4 rounded-xl">
            <h3 className="font-semibold text-slate-800 mb-4">Informações Financeiras</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <p className="text-slate-600">Preço de Custo</p>
                <p className="font-semibold text-slate-900">{formatCurrency(produto.preco_custo)}</p>
              </div>
              <div>
                <p className="text-slate-600">Preço de Venda</p>
                <p className="font-semibold text-slate-900">{formatCurrency(produto.preco_venda)}</p>
              </div>
              <div>
                <p className="text-slate-600">Margem de Lucro</p>
                <p className="font-semibold text-slate-900">{(produto.margem_lucro || 0).toFixed(1)}%</p>
              </div>
              <div>
                <p className="text-slate-600">Lucro por Unidade</p>
                <p className="font-semibold text-slate-900">{formatCurrency(lucroUnitario)}</p>
              </div>
            </div>
          </div>

          {/* Controle de Estoque */}
          <div className="bg-slate-50 p-4 rounded-xl">
            <h3 className="font-semibold text-slate-800 mb-4">Controle de Estoque</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
              <div>
                <p className="text-slate-600">Estoque Atual</p>
                <p className="font-semibold text-slate-900">
                  {produto.estoque_atual || 0} {produto.unidade}
                </p>
              </div>
              <div>
                <p className="text-slate-600">Estoque Mínimo</p>
                <p className="font-semibold text-slate-900">
                  {produto.estoque_minimo || 0} {produto.unidade}
                </p>
              </div>
              <div>
                <p className="text-slate-600">Status</p>
                <Badge className={
                  produto.status === 'ativo' ? 'bg-emerald-100 text-emerald-800' :
                  produto.status === 'inativo' ? 'bg-red-100 text-red-800' :
                  'bg-gray-100 text-gray-800'
                }>
                  {produto.status}
                </Badge>
              </div>
            </div>
          </div>

          {/* Especificações Técnicas */}
          {produto.especificacoes && Object.values(produto.especificacoes).some(v => v) && (
            <div className="bg-slate-50 p-4 rounded-xl">
              <h3 className="font-semibold text-slate-800 mb-4">Especificações Técnicas</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                {produto.especificacoes.espessura && (
                  <div>
                    <p className="text-slate-600">Espessura</p>
                    <p className="font-semibold text-slate-900">{produto.especificacoes.espessura}</p>
                  </div>
                )}
                {produto.especificacoes.cor && (
                  <div>
                    <p className="text-slate-600">Cor</p>
                    <p className="font-semibold text-slate-900">{produto.especificacoes.cor}</p>
                  </div>
                )}
                {produto.especificacoes.acabamento && (
                  <div>
                    <p className="text-slate-600">Acabamento</p>
                    <p className="font-semibold text-slate-900">{produto.especificacoes.acabamento}</p>
                  </div>
                )}
                {produto.especificacoes.largura_mm && (
                  <div>
                    <p className="text-slate-600">Largura</p>
                    <p className="font-semibold text-slate-900">{produto.especificacoes.largura_mm} mm</p>
                  </div>
                )}
                {produto.especificacoes.altura_mm && (
                  <div>
                    <p className="text-slate-600">Altura</p>
                    <p className="font-semibold text-slate-900">{produto.especificacoes.altura_mm} mm</p>
                  </div>
                )}
                {produto.especificacoes.area_m2 && (
                  <div>
                    <p className="text-slate-600">Área</p>
                    <p className="font-semibold text-slate-900">{parseFloat(produto.especificacoes.area_m2).toFixed(4)} m²</p>
                  </div>
                )}
                {produto.especificacoes.peso && (
                  <div className="col-span-2 md:col-span-1">
                    <p className="text-slate-600">Peso</p>
                    <p className="font-semibold text-slate-900">{produto.especificacoes.peso}</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Outras Informações */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            {produto.subcategoria && (
              <div>
                <p className="text-slate-600">Subcategoria</p>
                <p className="font-semibold text-slate-900">{produto.subcategoria}</p>
              </div>
            )}
            {produto.fornecedor_principal && (
              <div>
                <p className="text-slate-600">Fornecedor Principal</p>
                <p className="font-semibold text-slate-900">{produto.fornecedor_principal}</p>
              </div>
            )}
          </div>

          {/* Botões */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button variant="outline" onClick={onClose}>
              Fechar
            </Button>
            <Button onClick={() => onEdit(produto)} className="bg-blue-600 hover:bg-blue-700">
              <Edit className="w-4 h-4 mr-2" />
              Editar Produto
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
