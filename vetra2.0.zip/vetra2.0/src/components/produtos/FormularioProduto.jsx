
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { X, Calculator, Plus } from "lucide-react";
import { Produto } from "@/api/entities";

const CATEGORIAS = [
  { value: "vidro_temperado", label: "Vidro Temperado" },
  { value: "vidro_laminado", label: "Vidro Laminado" },
  { value: "vidro_comum", label: "Vidro Comum" },
  { value: "esquadria_aluminio", label: "Esquadria Alumínio" },
  { value: "esquadria_ferro", label: "Esquadria Ferro" },
  { value: "acessorios", label: "Acessórios" },
  { value: "ferragens", label: "Ferragens" },
  { value: "silicone", label: "Silicone" },
  { value: "outros", label: "Outros" }
];

const UNIDADES = [
  { value: "m2", label: "Metros Quadrados" },
  { value: "ml", label: "Metro Linear" },
  { value: "pc", label: "Unidade" },
  { value: "kg", label: "Quilograma" }
];

export default function FormularioProduto({ produto, onSave, onCancel, isLoading }) {
  const [formData, setFormData] = useState(produto || {
    codigo: '',
    nome: '',
    categoria: '',
    subcategoria: '',
    unidade: 'm2',
    preco_custo: 0,
    preco_venda: 0,
    margem_lucro: 0,
    estoque_atual: 1,
    estoque_minimo: 0,
    especificacoes: {
      espessura: '',
      cor: '',
      acabamento: '',
      largura_mm: '',
      altura_mm: '',
      area_m2: '',
      peso: ''
    },
    fornecedor_principal: '',
    status: 'ativo'
  });

  const [showCalculoArea, setShowCalculoArea] = useState(false);
  const [isAdicionandoEstoque, setIsAdicionandoEstoque] = useState(false);

  // Effect to calculate area_m2 for the product's own specifications
  useEffect(() => {
    const largura = parseFloat(formData.especificacoes.largura_mm) || 0;
    const altura = parseFloat(formData.especificacoes.altura_mm) || 0;

    let area = '';
    if (largura > 0 && altura > 0) {
        area = ((largura / 1000) * (altura / 1000)).toFixed(4);
    } else {
        area = ''; // Clear if dimensions are not valid
    }
    
    // Only update state if the calculated value is different, to avoid infinite loops
    // Convert to string for comparison as state might store it as string
    if (String(area) !== String(formData.especificacoes.area_m2)) {
      handleEspecificacaoChange('area_m2', area);
    }
  }, [formData.especificacoes.largura_mm, formData.especificacoes.altura_mm]);

  const handleInputChange = (field, value) => {
    setFormData(prev => {
      const newData = {
        ...prev,
        [field]: value
      };

      // Calcular preço de venda automaticamente baseado no custo + margem
      if (field === 'preco_custo' || field === 'margem_lucro') {
        const custo = parseFloat(field === 'preco_custo' ? value : newData.preco_custo) || 0;
        const margem = parseFloat(field === 'margem_lucro' ? value : newData.margem_lucro) || 0;
        
        if (custo > 0 && margem >= 0) {
          const precoVenda = custo * (1 + margem / 100);
          newData.preco_venda = Math.round(precoVenda * 100) / 100;
        } else if (custo === 0) {
            newData.preco_venda = 0;
        }
      }

      // Calcular margem quando preço de venda é alterado manualmente
      if (field === 'preco_venda') {
        const custo = newData.preco_custo;
        const venda = parseFloat(value) || 0;
        
        if (custo > 0 && venda >= 0) {
          const margem = ((venda - custo) / custo) * 100;
          newData.margem_lucro = Math.round(margem * 100) / 100;
        } else if (custo === 0) {
            newData.margem_lucro = 0;
        }
      }

      return newData;
    });
  };

  const handleEspecificacaoChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      especificacoes: {
        ...prev.especificacoes,
        [field]: value
      }
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (produto?.id) {
        await Produto.update(produto.id, formData);
      } else {
        await Produto.create(formData);
      }
      onSave();
    } catch (error) {
      console.error('Erro ao salvar produto:', error);
    }
  };

  const calcularArea = () => {
    const largura = parseFloat(document.getElementById('largura_calc')?.value) || 0;
    const altura = parseFloat(document.getElementById('altura_calc')?.value) || 0;
    
    if (largura > 0 && altura > 0) {
      const area = ((largura / 1000) * (altura / 1000)).toFixed(4);
      return {
        area: area,
        larguraM: (largura / 1000).toFixed(3),
        alturaM: (altura / 1000).toFixed(3)
      };
    }
    return null;
  };

  const adicionarAoEstoque = () => {
    const calculo = calcularArea();
    if (calculo) {
      const areaCalculada = parseFloat(calculo.area);
      const qtdPecas = parseFloat(document.getElementById('qtd_pecas')?.value) || 1;
      const totalAdicionar = areaCalculada * qtdPecas;
      
      setFormData(prev => ({
        ...prev,
        estoque_atual: (parseFloat(prev.estoque_atual) || 0) + totalAdicionar
      }));
      
      setShowCalculoArea(false);
      setIsAdicionandoEstoque(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <Card className="bg-white shadow-lg">
        <CardHeader className="pb-4 border-b">
          <div className="flex justify-between items-center">
            <CardTitle className="text-xl font-bold text-gray-900">
              Novo Produto
            </CardTitle>
            <Button variant="ghost" size="icon" onClick={onCancel}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Nome do Produto */}
            <div>
              <Label htmlFor="nome" className="text-sm font-medium text-gray-700">Nome do Produto *</Label>
              <Input
                id="nome"
                value={formData.nome}
                onChange={(e) => handleInputChange('nome', e.target.value)}
                placeholder="Ex: Vidro Temperado 8mm"
                required
                className="mt-1"
              />
            </div>

            {/* Descrição */}
            <div>
              <Label htmlFor="descricao" className="text-sm font-medium text-gray-700">Descrição</Label>
              <Textarea
                id="descricao"
                value={formData.subcategoria}
                onChange={(e) => handleInputChange('subcategoria', e.target.value)}
                placeholder="Detalhes do produto..."
                className="mt-1 h-20"
              />
            </div>

            {/* Código, Categoria, Tipo de Medida */}
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="codigo" className="text-sm font-medium text-gray-700">Código</Label>
                <Input
                  id="codigo"
                  value={formData.codigo}
                  onChange={(e) => handleInputChange('codigo', e.target.value)}
                  placeholder="Ex: VT-8MM"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="categoria" className="text-sm font-medium text-gray-700">Categoria *</Label>
                <Select value={formData.categoria} onValueChange={(value) => handleInputChange('categoria', value)}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Selecione..." />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIAS.map(cat => (
                      <SelectItem key={cat.value} value={cat.value}>
                        {cat.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="unidade" className="text-sm font-medium text-gray-700">Tipo de Medida</Label>
                <Select value={formData.unidade} onValueChange={(value) => handleInputChange('unidade', value)}>
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {UNIDADES.map(un => (
                      <SelectItem key={un.value} value={un.value}>
                        {un.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Preços */}
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="preco_custo" className="text-sm font-medium text-gray-700">Preço de Custo (R$)</Label>
                <Input
                  id="preco_custo"
                  type="number"
                  step="0.01"
                  value={formData.preco_custo}
                  onChange={(e) => handleInputChange('preco_custo', e.target.value)}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="preco_venda" className="text-sm font-medium text-gray-700">Preço de Venda (R$)</Label>
                <Input
                  id="preco_venda"
                  type="number"
                  step="0.01"
                  value={formData.preco_venda}
                  onChange={(e) => handleInputChange('preco_venda', e.target.value)}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="margem" className="text-sm font-medium text-gray-700">Unidade (Automático)</Label>
                <div className="mt-1 px-3 py-2 bg-gray-50 border border-gray-300 rounded-md text-sm text-gray-700">
                  {formData.unidade}
                </div>
              </div>
            </div>

            {/* Dimensões para cálculo automático */}
            {formData.unidade === 'm2' && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="largura_mm" className="text-sm font-medium text-gray-700">Largura (mm)</Label>
                    <Input
                      id="largura_mm"
                      type="number"
                      value={formData.especificacoes.largura_mm}
                      onChange={(e) => handleEspecificacaoChange('largura_mm', e.target.value)}
                      placeholder="1000"
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="altura_mm" className="text-sm font-medium text-gray-700">Altura (mm)</Label>
                    <Input
                      id="altura_mm"
                      type="number"
                      value={formData.especificacoes.altura_mm}
                      onChange={(e) => handleEspecificacaoChange('altura_mm', e.target.value)}
                      placeholder="1000"
                      className="mt-1"
                    />
                  </div>
                </div>

                {/* Preview do Cálculo */}
                {formData.especificacoes.largura_mm && formData.especificacoes.altura_mm && (
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-green-800">Preview do Cálculo:</p>
                        <p className="text-sm text-green-700">
                          Para adicionar: <strong>1 peça</strong>
                        </p>
                        <p className="text-sm text-green-700">
                          Cálculo: {(formData.especificacoes.largura_mm/1000).toFixed(3)}m × {(formData.especificacoes.altura_mm/1000).toFixed(3)}m = <strong>{formData.especificacoes.area_m2} m²</strong>
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </>
            )}

            {/* Quantidade */}
            <div>
              <Label htmlFor="quantidade" className="text-sm font-medium text-gray-700">Quantidade</Label>
              <Input
                id="quantidade"
                type="number"
                step="0.0001"
                value={formData.estoque_atual}
                onChange={(e) => handleInputChange('estoque_atual', e.target.value)}
                className="mt-1"
              />
            </div>

            {/* Botão Adicionar ao Estoque */}
            {formData.unidade === 'm2' && (
              <div className="border-t pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowCalculoArea(!showCalculoArea)}
                  className="w-full"
                >
                  <Calculator className="w-4 h-4 mr-2" />
                  Adicionar ao Estoque
                </Button>

                {/* Modal/Seção de Adicionar ao Estoque */}
                {showCalculoArea && (
                  <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-medium text-blue-800 mb-3">Adicionar ao Estoque por Dimensões</h4>
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div>
                        <Label htmlFor="largura_calc" className="text-sm font-medium text-gray-700">Largura (mm)</Label>
                        <Input
                          id="largura_calc"
                          type="number"
                          placeholder="1000"
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="altura_calc" className="text-sm font-medium text-gray-700">Altura (mm)</Label>
                        <Input
                          id="altura_calc"
                          type="number"
                          placeholder="1000"
                          className="mt-1"
                        />
                      </div>
                    </div>
                    <div className="mb-4">
                      <Label htmlFor="qtd_pecas" className="text-sm font-medium text-gray-700">Quantidade de Peças</Label>
                      <Input
                        id="qtd_pecas"
                        type="number"
                        defaultValue="1"
                        className="mt-1"
                      />
                    </div>
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setShowCalculoArea(false)}
                      >
                        Cancelar
                      </Button>
                      <Button
                        type="button"
                        size="sm"
                        onClick={adicionarAoEstoque}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        Adicionar
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Estoque Mínimo */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="estoque_minimo" className="text-sm font-medium text-gray-700">Estoque Mínimo (m²)</Label>
                <Input
                  id="estoque_minimo"
                  type="number"
                  step="0.0001"
                  value={formData.estoque_minimo}
                  onChange={(e) => handleInputChange('estoque_minimo', e.target.value)}
                  className="mt-1"
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="produto_ativo" className="text-sm font-medium text-gray-700">Produto Ativo</Label>
                <Switch
                  id="produto_ativo"
                  checked={formData.status === 'ativo'}
                  onCheckedChange={(checked) => handleInputChange('status', checked ? 'ativo' : 'inativo')}
                />
              </div>
            </div>

            {/* Botões */}
            <div className="flex justify-end gap-3 pt-6 border-t">
              <Button type="button" variant="outline" onClick={onCancel}>
                Cancelar
              </Button>
              <Button 
                type="submit" 
                disabled={isLoading} 
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                {isLoading ? 'Salvando...' : 'Salvar Produto'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
