import { base44 } from './base44Client';


export const emitirNfe = base44.functions.emitirNfe;

