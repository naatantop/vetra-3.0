import { base44 } from './base44Client';


export const Cliente = base44.entities.Cliente;

export const Produto = base44.entities.Produto;

export const Orcamento = base44.entities.Orcamento;

export const OrdemServico = base44.entities.OrdemServico;

export const LancamentoFinanceiro = base44.entities.LancamentoFinanceiro;

export const Financeiro = base44.entities.Financeiro;

export const ConfiguracaoEmpresa = base44.entities.ConfiguracaoEmpresa;



// auth sdk:
export const User = base44.auth;